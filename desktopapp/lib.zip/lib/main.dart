// ignore_for_file: deprecated_member_use, library_private_types_in_public_api

import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'routes/routes.dart';
import 'view/splash_screen.dart';
import 'view_models/providers/settings_provider.dart';
import 'view_models/services/database/database_services.dart';
import 'view_models/services/theme/theme_services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive with directory management
  final hiveService = HiveService();
  await hiveService.init();

  runApp(ProviderScope(child: MyApp()));
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        final settingsState = ref.watch(settingsProvider);
        final appBarElevation = settingsState.appBarElevation;
        final cardElevation = settingsState.cardElevation;
        final themeMode = settingsState.themeMode;
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'My App',
          theme: AppTheme.lightTheme(appBarElevation, cardElevation),
          darkTheme: AppTheme.darkTheme(appBarElevation, cardElevation),
          themeMode: themeMode,
          home: SplashScreen(),
          // home: ParallaxOnboarding(),
          // home: AdvancedSplashScreen(
          //   nextScreen: MainScrenn(),
          //   duration: Duration(seconds: 14),
          // ),
          // initialRoute: RouteName.splashScreen,
          onGenerateRoute: AppRoutes.generateRoute,
        );
      },
    );
  }
}
