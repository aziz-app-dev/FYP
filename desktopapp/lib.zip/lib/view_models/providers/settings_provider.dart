import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/database/database_services.dart';

// Print format options
enum PrintFormat {
  thermal,
  a4,
}

class SettingsState {
  final bool isPrintEnabled; // Master switch for printing
  final PrintFormat printFormat; // Thermal or A4
  final bool isPDFSave;
  final bool isPaid;
  final bool isAutoPrintOnSale; // Auto-print bills after sale completion
  final String directoryPath;
  final bool isShowTagLine;
  final bool isTagLineInsteadOfCEOName;
  final bool isShowUserCard;
  final double cardElevation;
  final double appBarElevation;
  final double productCardElevation;
  final bool isAppLockEnabled;
  final ThemeMode themeMode;
  final bool useMultiCart; // Multi-cart option

  // Home Page Section Settings
  final bool showBannerSection;
  final List<String> bannerImagePaths;
  final bool bannerAutoScroll;
  final int bannerScrollDuration; // in seconds
  final bool showBrandsSection;
  final bool showCategoriesSection;
  final bool showTopSellingSection;
  final bool showLatestItemsSection;
  final bool showLatestServicesSection;
  final bool showLowStockSection;
  final int productsPerSection; // Default for all
  final int topSellingProductsCount;
  final int latestItemsCount;
  final int latestServicesCount;
  final int lowStockItemsCount;
  final List<String> sectionOrder;

  SettingsState({
    this.isPrintEnabled = false,
    this.printFormat = PrintFormat.thermal, // Default to thermal
    this.isPDFSave = false,
    this.isPaid = false,
    this.isAutoPrintOnSale = false, // Auto-print disabled by default
    this.directoryPath = '',
    this.isShowTagLine = true,
    this.isTagLineInsteadOfCEOName = false,
    this.isShowUserCard = true,
    this.cardElevation = 4.0,
    this.appBarElevation = 4.0,
    this.productCardElevation = 4.0,
    this.isAppLockEnabled = false,
    this.themeMode = ThemeMode.light,
    this.useMultiCart = false, // Default to single cart
    this.showBannerSection = true,
    this.bannerImagePaths = const [],
    this.bannerAutoScroll = true,
    this.bannerScrollDuration = 5, // 5 seconds default
    this.showBrandsSection = true,
    this.showCategoriesSection = true,
    this.showTopSellingSection = true,
    this.showLatestItemsSection = true,
    this.showLatestServicesSection = true,
    this.showLowStockSection = true,
    this.productsPerSection = 6,
    this.topSellingProductsCount = 6,
    this.latestItemsCount = 6,
    this.latestServicesCount = 6,
    this.lowStockItemsCount = 6,
    this.sectionOrder = const [
      'banner',
      'brands',
      'categories',
      'topSelling',
      'latestItems',
      'latestServices',
      'lowStock',
    ],
  });

  SettingsState copyWith({
    bool? isPrintEnabled,
    PrintFormat? printFormat,
    bool? isPDFSave,
    bool? isPaid,
    bool? isAutoPrintOnSale,
    String? directoryPath,
    bool? isShowTagLine,
    bool? isTagLineInsteadOfCEOName,
    bool? isShowUserCard,
    double? cardElevation,
    double? appBarElevation,
    double? productCardElevation,
    bool? isAppLockEnabled,
    ThemeMode? themeMode,
    bool? useMultiCart,
    bool? showBannerSection,
    List<String>? bannerImagePaths,
    bool? bannerAutoScroll,
    int? bannerScrollDuration,
    bool? showBrandsSection,
    bool? showCategoriesSection,
    bool? showTopSellingSection,
    bool? showLatestItemsSection,
    bool? showLatestServicesSection,
    bool? showLowStockSection,
    int? productsPerSection,
    int? topSellingProductsCount,
    int? latestItemsCount,
    int? latestServicesCount,
    int? lowStockItemsCount,
    List<String>? sectionOrder,
  }) {
    return SettingsState(
      isPrintEnabled: isPrintEnabled ?? this.isPrintEnabled,
      printFormat: printFormat ?? this.printFormat,
      isPDFSave: isPDFSave ?? this.isPDFSave,
      isPaid: isPaid ?? this.isPaid,
      isAutoPrintOnSale: isAutoPrintOnSale ?? this.isAutoPrintOnSale,
      directoryPath: directoryPath ?? this.directoryPath,
      isShowTagLine: isShowTagLine ?? this.isShowTagLine,
      isTagLineInsteadOfCEOName:
          isTagLineInsteadOfCEOName ?? this.isTagLineInsteadOfCEOName,
      isShowUserCard: isShowUserCard ?? this.isShowUserCard,
      cardElevation: cardElevation ?? this.cardElevation,
      appBarElevation: appBarElevation ?? this.appBarElevation,
      productCardElevation: productCardElevation ?? this.productCardElevation,
      isAppLockEnabled: isAppLockEnabled ?? this.isAppLockEnabled,
      themeMode: themeMode ?? this.themeMode,
      useMultiCart: useMultiCart ?? this.useMultiCart,
      showBannerSection: showBannerSection ?? this.showBannerSection,
      bannerImagePaths: bannerImagePaths ?? this.bannerImagePaths,
      bannerAutoScroll: bannerAutoScroll ?? this.bannerAutoScroll,
      bannerScrollDuration: bannerScrollDuration ?? this.bannerScrollDuration,
      showBrandsSection: showBrandsSection ?? this.showBrandsSection,
      showCategoriesSection: showCategoriesSection ?? this.showCategoriesSection,
      showTopSellingSection: showTopSellingSection ?? this.showTopSellingSection,
      showLatestItemsSection: showLatestItemsSection ?? this.showLatestItemsSection,
      showLatestServicesSection: showLatestServicesSection ?? this.showLatestServicesSection,
      showLowStockSection: showLowStockSection ?? this.showLowStockSection,
      productsPerSection: productsPerSection ?? this.productsPerSection,
      topSellingProductsCount: topSellingProductsCount ?? this.topSellingProductsCount,
      latestItemsCount: latestItemsCount ?? this.latestItemsCount,
      latestServicesCount: latestServicesCount ?? this.latestServicesCount,
      lowStockItemsCount: lowStockItemsCount ?? this.lowStockItemsCount,
      sectionOrder: sectionOrder ?? this.sectionOrder,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'isPrintEnabled': isPrintEnabled,
      'printFormat': printFormat.name, // Save enum as string
      'isPDFSave': isPDFSave,
      'isPaid': isPaid,
      'isAutoPrintOnSale': isAutoPrintOnSale,
      'directoryPath': directoryPath,
      'isShowTagLine': isShowTagLine,
      'isTagLineInsteadOfCEOName': isTagLineInsteadOfCEOName,
      'isShowUserCard': isShowUserCard,
      'cardElevation': cardElevation,
      'appBarElevation': appBarElevation,
      'productCardElevation': productCardElevation,
      'isAppLockEnabled': isAppLockEnabled,
      'themeMode': themeMode.toString(),
      'useMultiCart': useMultiCart,
      'showBannerSection': showBannerSection,
      'bannerImagePaths': bannerImagePaths,
      'bannerAutoScroll': bannerAutoScroll,
      'bannerScrollDuration': bannerScrollDuration,
      'showBrandsSection': showBrandsSection,
      'showCategoriesSection': showCategoriesSection,
      'showTopSellingSection': showTopSellingSection,
      'showLatestItemsSection': showLatestItemsSection,
      'showLatestServicesSection': showLatestServicesSection,
      'showLowStockSection': showLowStockSection,
      'productsPerSection': productsPerSection,
      'topSellingProductsCount': topSellingProductsCount,
      'latestItemsCount': latestItemsCount,
      'latestServicesCount': latestServicesCount,
      'lowStockItemsCount': lowStockItemsCount,
      'sectionOrder': sectionOrder,
    };
  }

  factory SettingsState.fromMap(Map<String, dynamic> map) {
    // Migrate old sectionOrder to include banner if missing
    List<String> sectionOrder;
    if (map['sectionOrder'] != null) {
      final List<String> savedOrder = List<String>.from(map['sectionOrder']);
      // Check if banner is missing and add it at the beginning
      if (!savedOrder.contains('banner')) {
        sectionOrder = ['banner', ...savedOrder];
      } else {
        sectionOrder = savedOrder;
      }
    } else {
      sectionOrder = const [
        'banner',
        'brands',
        'categories',
        'topSelling',
        'latestItems',
        'latestServices',
        'lowStock',
      ];
    }

    return SettingsState(
      isPrintEnabled: map['isPrintEnabled'] ?? map['isThermalPrint'] ?? false, // Migration support
      printFormat: map['printFormat'] != null
          ? PrintFormat.values.firstWhere(
              (e) => e.name == map['printFormat'],
              orElse: () => PrintFormat.thermal,
            )
          : (map['isA4Print'] == true ? PrintFormat.a4 : PrintFormat.thermal), // Migration support
      isPDFSave: map['isPDFSave'] ?? false,
      isPaid: map['isPaid'] ?? false,
      isAutoPrintOnSale: map['isAutoPrintOnSale'] ?? false,
      directoryPath: map['directoryPath'] ?? '',
      isShowTagLine: map['isShowTagLine'] ?? true,
      isTagLineInsteadOfCEOName: map['isTagLineInsteadOfCEOName'] ?? false,
      isShowUserCard: map['isShowUserCard'] ?? true,
      cardElevation: (map['cardElevation'] as num?)?.toDouble() ?? 4.0,
      appBarElevation: (map['appBarElevation'] as num?)?.toDouble() ?? 4.0,
      productCardElevation:
          (map['productCardElevation'] as num?)?.toDouble() ?? 4.0,
      isAppLockEnabled: map['isAppLockEnabled'] ?? false,
      themeMode:
          map['themeMode'] == 'ThemeMode.dark'
              ? ThemeMode.dark
              : map['themeMode'] == 'ThemeMode.system'
              ? ThemeMode.system
              : ThemeMode.light,
      useMultiCart: map['useMultiCart'] ?? false,
      showBannerSection: map['showBannerSection'] ?? true,
      bannerImagePaths: map['bannerImagePaths'] != null
          ? List<String>.from(map['bannerImagePaths'])
          : const [],
      bannerAutoScroll: map['bannerAutoScroll'] ?? true,
      bannerScrollDuration: map['bannerScrollDuration'] ?? 5,
      showBrandsSection: map['showBrandsSection'] ?? true,
      showCategoriesSection: map['showCategoriesSection'] ?? true,
      showTopSellingSection: map['showTopSellingSection'] ?? true,
      showLatestItemsSection: map['showLatestItemsSection'] ?? true,
      showLatestServicesSection: map['showLatestServicesSection'] ?? true,
      showLowStockSection: map['showLowStockSection'] ?? true,
      productsPerSection: map['productsPerSection'] ?? 6,
      topSellingProductsCount: map['topSellingProductsCount'] ?? 6,
      latestItemsCount: map['latestItemsCount'] ?? 6,
      latestServicesCount: map['latestServicesCount'] ?? 6,
      lowStockItemsCount: map['lowStockItemsCount'] ?? 6,
      sectionOrder: sectionOrder,
    );
  }
}

class SettingsNotifier extends StateNotifier<SettingsState> {
  final HiveService _hiveService;

  SettingsNotifier(this._hiveService) : super(SettingsState()) {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settingsBox = await _hiveService.getSettingsBox();
    final directoryPath = await _hiveService.directoryPath;
    final settingsMap =
        settingsBox.get('settings', defaultValue: {}) as Map<dynamic, dynamic>;

    // Load settings with migration
    state = SettingsState.fromMap({
      ...settingsMap,
      'directoryPath': directoryPath,
    });

    // Save migrated settings to persist banner in sectionOrder
    final savedOrder = settingsMap['sectionOrder'] as List?;
    if (savedOrder != null && !savedOrder.contains('banner')) {
      // Banner was added during migration, save it
      await _saveSettings();
    }
  }

  Future<void> _saveSettings() async {
    final settingsBox = await _hiveService.getSettingsBox();
    await settingsBox.put('settings', state.toMap());
  }

  void setPrintEnabled(bool value) {
    state = state.copyWith(isPrintEnabled: value);
    _saveSettings();
  }

  void setPrintFormat(PrintFormat format) {
    state = state.copyWith(printFormat: format);
    _saveSettings();
  }

  void setPDFSave(bool value) {
    state = state.copyWith(isPDFSave: value);
    _saveSettings();
  }

  void setIsPaid(bool value) {
    state = state.copyWith(isPaid: value);
    _saveSettings();
  }

  void setAutoPrintOnSale(bool value) {
    state = state.copyWith(isAutoPrintOnSale: value);
    _saveSettings();
  }

  void setShowTagLine(bool value) {
    state = state.copyWith(isShowTagLine: value);
    _saveSettings();
  }

  void setTagLineInsteadOfCEOName(bool value) {
    state = state.copyWith(isTagLineInsteadOfCEOName: value);
    _saveSettings();
  }

  void setShowUserCard(bool value) {
    state = state.copyWith(isShowUserCard: value);
    _saveSettings();
  }

  void setCardElevation(double value) {
    state = state.copyWith(cardElevation: value);
    _saveSettings();
  }

  void setAppBarElevation(double value) {
    state = state.copyWith(appBarElevation: value);
    _saveSettings();
  }

  void setProductCardElevation(double value) {
    state = state.copyWith(productCardElevation: value);
    _saveSettings();
  }

  Future<void> setDirectoryPath(String newPath) async {
    await _hiveService.setDirectoryPath(newPath);
    state = state.copyWith(directoryPath: newPath);
    _saveSettings();
  }

  void setAppLockEnabled(bool value) {
    state = state.copyWith(isAppLockEnabled: value);
    _saveSettings();
  }

  void setThemeMode(ThemeMode mode) {
    state = state.copyWith(themeMode: mode);
    _saveSettings();
  }

  void setUseMultiCart(bool value) {
    state = state.copyWith(useMultiCart: value);
    _saveSettings();
  }

  // Home Page Section Settings Methods
  void setShowBannerSection(bool value) {
    state = state.copyWith(showBannerSection: value);
    _saveSettings();
  }

  void addBannerImage(String imagePath) {
    final newBanners = List<String>.from(state.bannerImagePaths)..add(imagePath);
    state = state.copyWith(bannerImagePaths: newBanners);
    _saveSettings();
  }

  void removeBannerImage(String imagePath) {
    final newBanners = List<String>.from(state.bannerImagePaths)
      ..remove(imagePath);
    state = state.copyWith(bannerImagePaths: newBanners);
    _saveSettings();
  }

  void reorderBannerImages(int oldIndex, int newIndex) {
    final newBanners = List<String>.from(state.bannerImagePaths);
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }
    final item = newBanners.removeAt(oldIndex);
    newBanners.insert(newIndex, item);
    state = state.copyWith(bannerImagePaths: newBanners);
    _saveSettings();
  }

  void setBannerAutoScroll(bool value) {
    state = state.copyWith(bannerAutoScroll: value);
    _saveSettings();
  }

  void setBannerScrollDuration(int value) {
    state = state.copyWith(bannerScrollDuration: value);
    _saveSettings();
  }

  void setShowBrandsSection(bool value) {
    state = state.copyWith(showBrandsSection: value);
    _saveSettings();
  }

  void setShowCategoriesSection(bool value) {
    state = state.copyWith(showCategoriesSection: value);
    _saveSettings();
  }

  void setShowTopSellingSection(bool value) {
    state = state.copyWith(showTopSellingSection: value);
    _saveSettings();
  }

  void setShowLatestItemsSection(bool value) {
    state = state.copyWith(showLatestItemsSection: value);
    _saveSettings();
  }

  void setShowLatestServicesSection(bool value) {
    state = state.copyWith(showLatestServicesSection: value);
    _saveSettings();
  }

  void setShowLowStockSection(bool value) {
    state = state.copyWith(showLowStockSection: value);
    _saveSettings();
  }

  void setProductsPerSection(int value) {
    state = state.copyWith(productsPerSection: value);
    _saveSettings();
  }

  void setSectionOrder(List<String> order) {
    state = state.copyWith(sectionOrder: order);
    _saveSettings();
  }

  void moveSectionUp(String sectionKey) {
    final currentOrder = List<String>.from(state.sectionOrder);
    final index = currentOrder.indexOf(sectionKey);
    if (index > 0) {
      final temp = currentOrder[index - 1];
      currentOrder[index - 1] = currentOrder[index];
      currentOrder[index] = temp;
      setSectionOrder(currentOrder);
    }
  }

  void moveSectionDown(String sectionKey) {
    final currentOrder = List<String>.from(state.sectionOrder);
    final index = currentOrder.indexOf(sectionKey);
    if (index < currentOrder.length - 1) {
      final temp = currentOrder[index + 1];
      currentOrder[index + 1] = currentOrder[index];
      currentOrder[index] = temp;
      setSectionOrder(currentOrder);
    }
  }

  void setTopSellingProductsCount(int value) {
    state = state.copyWith(topSellingProductsCount: value);
    _saveSettings();
  }

  void setLatestItemsCount(int value) {
    state = state.copyWith(latestItemsCount: value);
    _saveSettings();
  }

  void setLatestServicesCount(int value) {
    state = state.copyWith(latestServicesCount: value);
    _saveSettings();
  }

  void setLowStockItemsCount(int value) {
    state = state.copyWith(lowStockItemsCount: value);
    _saveSettings();
  }
}

final hiveServiceProvider = Provider<HiveService>((ref) => HiveService());

final settingsProvider = StateNotifierProvider<SettingsNotifier, SettingsState>(
  (ref) => SettingsNotifier(ref.read(hiveServiceProvider)),
);
