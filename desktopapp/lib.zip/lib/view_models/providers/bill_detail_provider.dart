import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:thermal_printer/thermal_printer.dart';
import '../../models/bills_model.dart';
import '../../models/coustomer_model.dart';
import '../services/database/database_services.dart';
import '../states/bill_detail_state.dart';
import 'add_prduct_provider.dart'; // For databaseServiceProvider

class BillDetailNotifier extends StateNotifier<BillDetailState> {
  final DatabaseService _databaseService;
  final Bill bill;

  BillDetailNotifier(this._databaseService, this.bill)
      : super(BillDetailState());

  // Add a printer device to the list
  void addDevice(PrinterDevice device) {
    final updatedDevices = List<PrinterDevice>.from(state.devices)..add(device);
    state = state.copyWith(devices: updatedDevices);
  }

  // Clear all devices
  void clearDevices() {
    state = state.copyWith(devices: []);
  }

  // Set selected printer
  void setSelectedPrinter(PrinterDevice? printer) {
    state = state.copyWith(
      selectedPrinter: printer,
      clearSelectedPrinter: printer == null,
    );
  }

  // Set printing status
  void setPrintingStatus(bool isPrinting) {
    state = state.copyWith(isPrintingThermal: isPrinting);
  }

  // Load customer data
  Future<void> loadCustomer() async {
    if (bill.customerId == null) return;

    try {
      state = state.copyWith(isLoading: true);
      final customers = await _databaseService.getCustomers();
      final customer = customers.firstWhere(
        (c) => c.id == bill.customerId,
        orElse: () => Customer(
          id: '',
          name: bill.customerName ?? 'Unknown',
          address: '',
          phoneNumber: '',
        ),
      );
      state = state.copyWith(customer: customer, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false);
    }
  }
}

final billDetailProvider = StateNotifierProvider.family<
    BillDetailNotifier,
    BillDetailState,
    Bill
>(
  (ref, bill) => BillDetailNotifier(
    ref.read(databaseServiceProvider),
    bill,
  ),
);
