import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../states/product_search_state.dart';

class ProductSearchNotifier extends StateNotifier<ProductSearchState> {
  ProductSearchNotifier() : super(const ProductSearchState());

  // Update search query
  void updateSearchQuery(String query) {
    state = state.copyWith(searchQuery: query);
  }

  // Clear search query
  void clearSearch() {
    state = state.copyWith(searchQuery: '');
  }
}

// Provider for multi-cart product search
final multiCartProductSearchProvider =
    StateNotifierProvider.autoDispose<ProductSearchNotifier, ProductSearchState>(
  (ref) => ProductSearchNotifier(),
);

// Provider for single-cart product search
final singleCartProductSearchProvider =
    StateNotifierProvider.autoDispose<ProductSearchNotifier, ProductSearchState>(
  (ref) => ProductSearchNotifier(),
);
