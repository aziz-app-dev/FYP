import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../states/checkout_state.dart';
import '../../models/coustomer_model.dart';

class CheckoutNotifier extends StateNotifier<CheckoutState> {
  CheckoutNotifier() : super(const CheckoutState());

  // Load all customers
  void loadCustomers(List<Customer> customers) {
    state = state.copyWith(
      fullCustomers: customers,
      filteredCustomers: customers,
    );
  }

  // Filter customers by search query
  void filterCustomers(String query) {
    if (query.isEmpty) {
      state = state.copyWith(
        filteredCustomers: state.fullCustomers,
        showSuggestions: false,
      );
    } else {
      final filtered = state.fullCustomers
          .where(
            (customer) => customer.name.toLowerCase().contains(query.toLowerCase()),
          )
          .toList();
      state = state.copyWith(
        filteredCustomers: filtered,
        showSuggestions: !state.isWalkIn,
      );
    }
  }

  // Hide suggestions
  void hideSuggestions() {
    state = state.copyWith(showSuggestions: false);
  }

  // Toggle walk-in mode
  void toggleWalkIn(bool value) {
    state = state.copyWith(
      isWalkIn: value,
      showSuggestions: false,
    );
  }
}

// Provider
final checkoutProvider =
    StateNotifierProvider.autoDispose<CheckoutNotifier, CheckoutState>(
  (ref) => CheckoutNotifier(),
);
