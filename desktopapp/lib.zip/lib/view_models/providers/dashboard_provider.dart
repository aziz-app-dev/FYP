import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../states/dashboard_state.dart';

class DashboardNotifier extends StateNotifier<DashboardState> {
  DashboardNotifier() : super(const DashboardState()) {
    _generateDummyData();
  }

  // Generate dummy data for the table
  void _generateDummyData() {
    final data = List.generate(
      100,
      (index) => [
        'Item ${index + 1}',
        'Category ${index % 5 + 1}',
        '\$${(index + 1) * 10}',
        'Status ${index % 3 + 1}',
      ],
    );
    state = state.copyWith(data: data);
  }

  // Navigate to next page
  void nextPage() {
    final totalPages = (state.data.length / state.rowsPerPage).ceil();
    if (state.currentPage < totalPages - 1) {
      state = state.copyWith(currentPage: state.currentPage + 1);
    }
  }

  // Navigate to previous page
  void previousPage() {
    if (state.currentPage > 0) {
      state = state.copyWith(currentPage: state.currentPage - 1);
    }
  }

  // Set specific page
  void setPage(int page) {
    final totalPages = (state.data.length / state.rowsPerPage).ceil();
    if (page >= 0 && page < totalPages) {
      state = state.copyWith(currentPage: page);
    }
  }
}

// Provider
final dashboardProvider =
    StateNotifierProvider.autoDispose<DashboardNotifier, DashboardState>(
  (ref) => DashboardNotifier(),
);
