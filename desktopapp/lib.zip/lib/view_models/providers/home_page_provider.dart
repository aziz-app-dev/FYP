import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../states/home_page_state.dart';
import '../services/database/database_services.dart';

class HomePageNotifier extends StateNotifier<HomePageState> {
  final DatabaseService _dbService;

  HomePageNotifier(this._dbService) : super(const HomePageState()) {
    loadProducts();
    loadBrands();
    loadCategories();
  }

  // Load brands from database
  Future<void> loadBrands() async {
    try {
      final brands = await _dbService.getBrands();
      state = state.copyWith(brands: brands, brandsLoading: false);
    } catch (e) {
      state = state.copyWith(brandsLoading: false);
    }
  }

  // Load categories from database
  Future<void> loadCategories() async {
    try {
      final categories = await _dbService.getCategories();
      state = state.copyWith(categories: categories, categoriesLoading: false);
    } catch (e) {
      state = state.copyWith(categoriesLoading: false);
    }
  }

  // Load products from database
  Future<void> loadProducts() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final products = await _dbService.getProducts();
      final bills = await _dbService.getBills();

      // Calculate product sales from bills
      final Map<String, int> productSalesCount = {};
      for (final bill in bills) {
        for (final entry in bill.quantities.entries) {
          final productId = entry.key;
          final quantity = entry.value;
          productSalesCount[productId] =
              (productSalesCount[productId] ?? 0) + quantity;
        }
      }

      // Get top selling products (top 10)
      final topSelling = [...products]
        ..sort((a, b) {
          final aSales = productSalesCount[a.id] ?? 0;
          final bSales = productSalesCount[b.id] ?? 0;
          return bSales.compareTo(aSales);
        });
      final topSellingProducts = topSelling.take(10).toList();

      // Get latest items (non-services, sorted by createdAt)
      final latestItems = products
          .where((p) => !p.isService)
          .toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      final latest10Items = latestItems.take(10).toList();

      // Get latest services (sorted by createdAt)
      final latestServices = products
          .where((p) => p.isService)
          .toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      final latest10Services = latestServices.take(10).toList();

      // Get low stock items (stock < 10 and not services)
      final lowStockItems = products
          .where((p) =>
              !p.isService &&
              p.stock != null &&
              p.stock! < 10 &&
              p.stock! > 0)
          .toList()
        ..sort((a, b) => (a.stock ?? 0).compareTo(b.stock ?? 0));

      state = state.copyWith(
        products: products,
        topSellingProducts: topSellingProducts,
        latestItems: latest10Items,
        latestServices: latest10Services,
        lowStockItems: lowStockItems,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: e.toString(),
      );
    }
  }

  // Refresh products
  Future<void> refreshProducts() async {
    await loadProducts();
    await loadBrands();
    await loadCategories();
  }
}

// Provider
final homePageProvider =
    StateNotifierProvider.autoDispose<HomePageNotifier, HomePageState>(
  (ref) => HomePageNotifier(DatabaseService()),
);
