import 'package:flutter_riverpod/flutter_riverpod.dart';

// StateNotifier to manage password visibility
class PasswordVisibilityNotifier extends StateNotifier<bool> {
  PasswordVisibilityNotifier() : super(false);

  void toggleVisibility() {
    state = !state;
  }
}

// Riverpod provider using StateNotifierProvider
final passwordVisibilityProvider =
    StateNotifierProvider<PasswordVisibilityNotifier, bool>(
      (ref) => PasswordVisibilityNotifier(),
    );
