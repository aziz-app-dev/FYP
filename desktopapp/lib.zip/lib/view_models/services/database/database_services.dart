// ignore_for_file: unnecessary_null_aware_assignments

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../models/bills_model.dart';
import '../../../models/coustomer_model.dart';
import '../../../models/items_model.dart';
import '../../../models/brand_model.dart';
import '../../../models/category_model.dart';
import '../../../models/shopping_list_model.dart';
import 'package:path_provider/path_provider.dart';
import '../../../models/user/user_model.dart';

class HiveService {
  static const String _productBoxName = 'products';
  static const String _billBoxName = 'bills';
  static const String _customerBoxName = 'customers';
  static const String _userBoxName = 'users';
  static const String _settingsBoxName = 'settings';
  static const String _brandBoxName = 'brands';
  static const String _categoryBoxName = 'categories';
  static const String _shoppingListsBoxName = 'shoppingLists'; // The lists themselves
  static const String _shoppingListBoxName = 'shoppingList'; // The items
  static const String _directoryPathKey = 'directoryPath';
  static const String _fieldConfigsKey = 'fieldConfigs';
  static const String _customerFieldConfigsKey =
      'customerFieldConfigs'; // New key for customer fields

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final appDir = await getApplicationDocumentsDirectory();
    final appPath = appDir.path;

    final storedPath = prefs.getString(_directoryPathKey) ?? appPath;
    Hive.init(storedPath);

    await Hive.openBox<Map>(_productBoxName);
    await Hive.openBox<Map>(_billBoxName);
    await Hive.openBox<Map>(_customerBoxName);
    await Hive.openBox<Map>(_userBoxName);
    await Hive.openBox(_settingsBoxName);
    await Hive.openBox<Map>(_brandBoxName);
    await Hive.openBox<Map>(_categoryBoxName);
    await Hive.openBox<Map>(_shoppingListsBoxName);
    await Hive.openBox<Map>(_shoppingListBoxName);

    // Initialize default brands if brands box is empty
    await _initializeDefaultBrands();
    // Initialize default categories if categories box is empty
    await _initializeDefaultCategories();
  }

  Future<void> setDirectoryPath(String newPath) async {
    final prefs = await SharedPreferences.getInstance();
    final oldPath = await directoryPath;

    if (oldPath == newPath) return;

    final oldHiveDir = Directory(oldPath);
    final newHiveDir = Directory(newPath);

    if (!await newHiveDir.exists()) {
      await newHiveDir.create(recursive: true);
    }

    await Hive.close();

    for (var entity in oldHiveDir.listSync()) {
      if (entity is File) {
        final newFile = File(
          '${newHiveDir.path}/${entity.uri.pathSegments.last}',
        );
        await newFile.writeAsBytes(await entity.readAsBytes());
      }
    }

    Hive.init(newPath);
    await Hive.openBox<Map>(_productBoxName);
    await Hive.openBox<Map>(_billBoxName);
    await Hive.openBox<Map>(_customerBoxName);
    await Hive.openBox<Map>(_userBoxName);
    await Hive.openBox(_settingsBoxName);
    await Hive.openBox<Map>(_brandBoxName);
    await Hive.openBox<Map>(_categoryBoxName);

    await prefs.setString(_directoryPathKey, newPath);
  }

  Future<String> get directoryPath async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_directoryPathKey) ??
        (await getApplicationDocumentsDirectory()).path;
  }

  Future<Box> getSettingsBox() async {
    if (!Hive.isBoxOpen(_settingsBoxName)) {
      return await Hive.openBox(_settingsBoxName);
    }
    return Hive.box(_settingsBoxName);
  }

  static Box<Map> get _productBox => Hive.box<Map>(_productBoxName);
  static Box<Map> get _billBox => Hive.box<Map>(_billBoxName);
  static Box<Map> get _customerBox => Hive.box<Map>(_customerBoxName);
  static Box<Map> get _userBox => Hive.box<Map>(_userBoxName);
  static Box get _settingsBox => Hive.box(_settingsBoxName);
  static Box<Map> get _brandBox => Hive.box<Map>(_brandBoxName);
  static Box<Map> get _categoryBox => Hive.box<Map>(_categoryBoxName);
  static Box<Map> get _shoppingListsBox => Hive.box<Map>(_shoppingListsBoxName);
  static Box<Map> get _shoppingListBox => Hive.box<Map>(_shoppingListBoxName);

  // Product Field Configs
  Future<void> saveFieldConfigs(Map<String, FieldConfig> fieldConfigs) async {
    final settingsBox = await getSettingsBox();
    final fieldConfigsMap = fieldConfigs.map(
      (key, value) => MapEntry(key, value.toMap()),
    );
    await settingsBox.put(_fieldConfigsKey, fieldConfigsMap);
  }

  Future<Map<String, FieldConfig>> getFieldConfigs() async {
    final settingsBox = await getSettingsBox();
    final fieldConfigsMap = settingsBox.get(_fieldConfigsKey);
    if (fieldConfigsMap == null) {
      return {
        'name': FieldConfig.initial('name', WidgetType.textField),
        'price': FieldConfig.initial('price', WidgetType.textField),
        'imageFile': FieldConfig.initial('imageFile', WidgetType.imagePicker),
        'warranty': FieldConfig.initial('warranty', WidgetType.dropdown),
        'condition': FieldConfig.initial('condition', WidgetType.dropdown),
        'brand': FieldConfig.initial('brand', WidgetType.dropdown),
        'description': FieldConfig.initial('description', WidgetType.textField),
        'purchasePrice': FieldConfig.initial(
          'purchasePrice',
          WidgetType.textField,
        ),
        'stock': FieldConfig.initial('stock', WidgetType.textField),
        'isBackup': FieldConfig.initial('isBackup', WidgetType.checkbox),
      };
    }
    return (fieldConfigsMap as Map).map(
      (key, value) =>
          MapEntry(key, FieldConfig.fromMap(Map<String, dynamic>.from(value))),
    );
  }

  // Customer Field Configs
  Future<void> saveCustomerFieldConfigs(
    Map<String, FieldConfig> fieldConfigs,
  ) async {
    final settingsBox = await getSettingsBox();
    final fieldConfigsMap = fieldConfigs.map(
      (key, value) => MapEntry(key, value.toMap()),
    );
    await settingsBox.put(_customerFieldConfigsKey, fieldConfigsMap);
  }

  Future<Map<String, FieldConfig>> getCustomerFieldConfigs() async {
    final settingsBox = await getSettingsBox();
    final fieldConfigsMap = settingsBox.get(_customerFieldConfigsKey);
    if (fieldConfigsMap == null) {
      return {
        'name': FieldConfig.initial('name', WidgetType.textField),
        'address': FieldConfig.initial('address', WidgetType.textField),
        'phoneNumber': FieldConfig.initial('phoneNumber', WidgetType.textField),
        'paidAmount': FieldConfig.initial('paidAmount', WidgetType.textField),
        'paymentStatus': FieldConfig.initial(
          'paymentStatus',
          WidgetType.dropdown,
        ),
        'paymentMethod': FieldConfig.initial(
          'paymentMethod',
          WidgetType.dropdown,
        ),
        'discount': FieldConfig.initial('discount', WidgetType.textField),
      };
    }
    return (fieldConfigsMap as Map).map(
      (key, value) =>
          MapEntry(key, FieldConfig.fromMap(Map<String, dynamic>.from(value))),
    );
  }

  List<Product> getProducts() {
    return _productBox.values
        .map((e) => Product.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> addProduct(Product product) async {
    await _productBox.put(product.id, product.toMap());
  }

  Future<void> updateProduct(Product product) async {
    await _productBox.put(product.id, product.toMap());
  }

  Future<void> deleteProduct(String id) async {
    await _productBox.delete(id);
  }

  List<Bill> getBills() {
    final List<Bill> bills = [];
    for (var value in _billBox.values) {
      try {
        final billMap = Map<String, dynamic>.from(value);
        billMap['customerId'] ??= null;
        billMap['paymentMethod'] ??= null;
        bills.add(Bill.fromMap(billMap));
      } catch (e) {
        debugPrint('Error deserializing bill: $e');
      }
    }
    return bills;
  }

  Future<void> saveBill(Bill bill) async {
    await _billBox.put(bill.id, bill.toMap());
  }

  List<Customer> getCustomers() {
    return _customerBox.values
        .map((e) => Customer.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> saveCustomer(Customer customer) async {
    await _customerBox.put(customer.id, customer.toMap());
  }

  Future<void> updateCustomer(Customer customer) async {
    await _customerBox.put(customer.id, customer.toMap());
  }

  Future<void> deleteCustomer(String id) async {
    await _customerBox.delete(id);
  }

  List<User> getUsers() {
    return _userBox.values
        .map((e) => User.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> saveUser(User user) async {
    await _userBox.put(user.id, user.toMap());
  }

  Future<void> updateUser(User user) async {
    await _userBox.put(user.id, user.toMap());
  }

  Future<void> deleteUser(String id) async {
    await _userBox.delete(id);
  }

  Future<void> clearAll() async {
    await _productBox.clear();
    await _billBox.clear();
    await _customerBox.clear();
    await _userBox.clear();
    await _settingsBox.clear();
  }

  Future<void> deleteBill(String id) async {
    await _billBox.delete(id);
  }

  // Brand Management Methods
  Future<void> _initializeDefaultBrands() async {
    if (_brandBox.isEmpty) {
      final defaultBrands = [
        'HP',
        'Dell',
        'Lenovo',
        'Asus',
        'Acer',
        'Apple',
        'MSI',
        'Samsung',
        'LG',
        'Sony',
      ];

      for (final brandName in defaultBrands) {
        final brand = Brand(
          id: DateTime.now().millisecondsSinceEpoch.toString() +
              brandName.hashCode.toString(),
          name: brandName,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        await _brandBox.put(brand.id, brand.toMap());
      }
    }
  }

  Future<List<Brand>> getBrands() async {
    final brandMaps = _brandBox.values.toList();
    return brandMaps
        .map((map) => Brand.fromMap(Map<String, dynamic>.from(map)))
        .toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }

  Future<void> addBrand(Brand brand) async {
    await _brandBox.put(brand.id, brand.toMap());
  }

  Future<void> updateBrand(Brand brand) async {
    await _brandBox.put(brand.id, brand.toMap());
  }

  Future<void> deleteBrand(String id) async {
    await _brandBox.delete(id);
  }

  // Category Management Methods
  Future<void> _initializeDefaultCategories() async {
    if (_categoryBox.isEmpty) {
      final defaultCategories = [
        'Electronics',
        'Clothing',
        'Food & Beverages',
        'Home & Garden',
        'Sports & Outdoors',
        'Books',
        'Toys & Games',
        'Health & Beauty',
        'Automotive',
        'Office Supplies',
      ];

      for (final categoryName in defaultCategories) {
        final category = Category(
          id:
              categoryName.hashCode.toString(),
          name: categoryName,
          imageUrl: null,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        await _categoryBox.put(category.id, category.toMap());
      }
    }
  }

  Future<List<Category>> getCategories() async {
    final categoryMaps = _categoryBox.values.toList();
    return categoryMaps
        .map((map) => Category.fromMap(Map<String, dynamic>.from(map)))
        .toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }

  Future<void> addCategory(Category category) async {
    await _categoryBox.put(category.id, category.toMap());
  }

  Future<void> updateCategory(Category category) async {
    await _categoryBox.put(category.id, category.toMap());
  }

  Future<void> deleteCategory(String id) async {
    await _categoryBox.delete(id);
  }

  // Shopping Lists (the lists themselves) Management Methods
  Future<List<ShoppingList>> getShoppingLists() async {
    final listsMap = _shoppingListsBox.values.toList();
    return listsMap
        .map((map) => ShoppingList.fromMap(Map<String, dynamic>.from(map)))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Future<void> createShoppingList(ShoppingList list) async {
    await _shoppingListsBox.put(list.id, list.toMap());
  }

  Future<void> updateShoppingList(ShoppingList list) async {
    await _shoppingListsBox.put(list.id, list.toMap());
  }

  Future<void> deleteShoppingList(String listId) async {
    // Delete the list
    await _shoppingListsBox.delete(listId);

    // Also delete all items in this list
    final items = await getShoppingListItems(listId);
    for (final item in items) {
      await deleteShoppingListItem(item.id);
    }
  }

  Future<void> duplicateShoppingList(String listId, String newListName) async {
    final items = await getShoppingListItems(listId);
    final now = DateTime.now();

    // Create new list
    final newList = ShoppingList(
      id: now.millisecondsSinceEpoch.toString(),
      name: newListName,
      createdAt: now,
      updatedAt: now,
    );
    await createShoppingList(newList);

    // Copy all items to new list
    for (final item in items) {
      final newItem = item.copyWith(
        id: '${now.millisecondsSinceEpoch}_${item.id}',
        listId: newList.id,
        isShopped: false, // Reset shopped status
        createdAt: now,
        updatedAt: now,
      );
      await addToShoppingList(newItem);
    }
  }

  // Shopping List Items Management Methods
  Future<List<ShoppingListItem>> getShoppingListItems(String listId) async {
    final shoppingListMaps = _shoppingListBox.values.toList();
    final allItems = shoppingListMaps
        .map((map) => ShoppingListItem.fromMap(Map<String, dynamic>.from(map)))
        .toList();

    // Filter by listId
    return allItems.where((item) => item.listId == listId).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  // Keep old method for backward compatibility
  Future<List<ShoppingListItem>> getShoppingList() async {
    final shoppingListMaps = _shoppingListBox.values.toList();
    return shoppingListMaps
        .map((map) => ShoppingListItem.fromMap(Map<String, dynamic>.from(map)))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Future<void> addToShoppingList(ShoppingListItem item) async {
    await _shoppingListBox.put(item.id, item.toMap());
  }

  Future<void> updateShoppingListItem(ShoppingListItem item) async {
    await _shoppingListBox.put(item.id, item.toMap());
  }

  Future<void> deleteShoppingListItem(String id) async {
    await _shoppingListBox.delete(id);
  }

  Future<void> markItemsAsShopped(List<String> itemIds) async {
    for (final id in itemIds) {
      final itemMap = _shoppingListBox.get(id);
      if (itemMap != null) {
        final item = ShoppingListItem.fromMap(Map<String, dynamic>.from(itemMap));
        final updatedItem = item.copyWith(
          isShopped: true,
          updatedAt: DateTime.now(),
        );
        await _shoppingListBox.put(id, updatedItem.toMap());
      }
    }
  }

  Future<void> clearShoppedItems([String? listId]) async {
    final items = listId != null
        ? await getShoppingListItems(listId)
        : await getShoppingList();
    for (final item in items) {
      if (item.isShopped) {
        await _shoppingListBox.delete(item.id);
      }
    }
  }

  Future<void> close() async {
    await Hive.close();
  }
}

class DatabaseService {
  final HiveService _hiveService;

  DatabaseService() : _hiveService = HiveService();

  Future<void> initialize() async {
    await _hiveService.init();
  }

  Future<List<Product>> getProducts() async {
    return _hiveService.getProducts();
  }

  Future<void> addProduct(Product product) async {
    await _hiveService.addProduct(product);
  }

  Future<void> updateProduct(Product product) async {
    await _hiveService.updateProduct(product);
  }

  Future<void> deleteProduct(String id) async {
    await _hiveService.deleteProduct(id);
  }

  Future<void> saveBill(Bill bill) async {
    await _hiveService.saveBill(bill);
  }

  Future<List<Bill>> getBills() async {
    return _hiveService.getBills();
  }

  Future<List<Customer>> getCustomers() async {
    return _hiveService.getCustomers();
  }

  Future<void> saveCustomer(Customer customer) async {
    await _hiveService.saveCustomer(customer);
  }

  Future<void> updateCustomer(Customer customer) async {
    await _hiveService.updateCustomer(customer);
  }

  Future<void> deleteCustomer(String id) async {
    await _hiveService.deleteCustomer(id);
  }

  Future<List<User>> getUsers() async {
    return _hiveService.getUsers();
  }

  Future<void> saveUser(User user) async {
    await _hiveService.saveUser(user);
  }

  Future<void> updateUser(User user) async {
    await _hiveService.updateUser(user);
  }

  Future<void> deleteUser(String id) async {
    await _hiveService.deleteUser(id);
  }

  Future<void> clearAllData() async {
    await _hiveService.clearAll();
  }

  Future<void> setNewDirectory(String newPath) async {
    await _hiveService.setDirectoryPath(newPath);
  }

  Future<String> getCurrentHivePath() async {
    return await _hiveService.directoryPath;
  }

  Future<void> deleteBill(String id) async {
    await _hiveService.deleteBill(id);
  }

  Future<void> close() async {
    await _hiveService.close();
  }

  Future<void> saveFieldConfigs(Map<String, FieldConfig> fieldConfigs) async {
    await _hiveService.saveFieldConfigs(fieldConfigs);
  }

  Future<Map<String, FieldConfig>> getFieldConfigs() async {
    return await _hiveService.getFieldConfigs();
  }

  Future<void> saveCustomerFieldConfigs(
    Map<String, FieldConfig> fieldConfigs,
  ) async {
    await _hiveService.saveCustomerFieldConfigs(fieldConfigs);
  }

  Future<Map<String, FieldConfig>> getCustomerFieldConfigs() async {
    return await _hiveService.getCustomerFieldConfigs();
  }

  // Brand Management Methods
  Future<List<Brand>> getBrands() async {
    return await _hiveService.getBrands();
  }

  Future<void> addBrand(Brand brand) async {
    await _hiveService.addBrand(brand);
  }

  Future<void> updateBrand(Brand brand) async {
    await _hiveService.updateBrand(brand);
  }

  Future<void> deleteBrand(String id) async {
    await _hiveService.deleteBrand(id);
  }

  // Category Management Methods
  Future<List<Category>> getCategories() async {
    return await _hiveService.getCategories();
  }

  Future<void> addCategory(Category category) async {
    await _hiveService.addCategory(category);
  }

  Future<void> updateCategory(Category category) async {
    await _hiveService.updateCategory(category);
  }

  Future<void> deleteCategory(String id) async {
    await _hiveService.deleteCategory(id);
  }

  // Shopping Lists Management Methods
  Future<List<ShoppingList>> getShoppingLists() async {
    return await _hiveService.getShoppingLists();
  }

  Future<void> createShoppingList(ShoppingList list) async {
    await _hiveService.createShoppingList(list);
  }

  Future<void> updateShoppingList(ShoppingList list) async {
    await _hiveService.updateShoppingList(list);
  }

  Future<void> deleteShoppingList(String listId) async {
    await _hiveService.deleteShoppingList(listId);
  }

  Future<void> duplicateShoppingList(String listId, String newListName) async {
    await _hiveService.duplicateShoppingList(listId, newListName);
  }

  // Shopping List Items Management Methods
  Future<List<ShoppingListItem>> getShoppingListItems(String listId) async {
    return await _hiveService.getShoppingListItems(listId);
  }

  Future<List<ShoppingListItem>> getShoppingList() async {
    return await _hiveService.getShoppingList();
  }

  Future<void> addToShoppingList(ShoppingListItem item) async {
    await _hiveService.addToShoppingList(item);
  }

  Future<void> updateShoppingListItem(ShoppingListItem item) async {
    await _hiveService.updateShoppingListItem(item);
  }

  Future<void> deleteShoppingListItem(String id) async {
    await _hiveService.deleteShoppingListItem(id);
  }

  Future<void> markItemsAsShopped(List<String> itemIds) async {
    await _hiveService.markItemsAsShopped(itemIds);
  }

  Future<void> clearShoppedItems([String? listId]) async {
    await _hiveService.clearShoppedItems(listId);
  }
}

// class HiveService {
//   static const String _productBoxName = 'products';
//   static const String _billBoxName = 'bills';
//   static const String _customerBoxName = 'customers';
//   static const String _userBoxName = 'users';
//   static const String _settingsBoxName = 'settings';
//   static const String _directoryPathKey = 'directoryPath';
//   static const String _fieldConfigsKey =
//       'fieldConfigs'; // Key for fieldConfigs in settings box

//   Future<void> init() async {
//     final prefs = await SharedPreferences.getInstance();
//     final appDir = await getApplicationDocumentsDirectory();
//     final appPath = appDir.path;

//     final storedPath = prefs.getString(_directoryPathKey) ?? appPath;
//     Hive.init(storedPath);

//     // Register adapters for custom types if needed
//     if (!Hive.isAdapterRegistered(FieldConfigAdapter().typeId)) {
//       Hive.registerAdapter(FieldConfigAdapter());
//     }

//     await Hive.openBox<Map>(_productBoxName);
//     await Hive.openBox<Map>(_billBoxName);
//     await Hive.openBox<Map>(_customerBoxName);
//     await Hive.openBox<Map>(_userBoxName);
//     await Hive.openBox(_settingsBoxName);
//   }

//   Future<void> setDirectoryPath(String newPath) async {
//     final prefs = await SharedPreferences.getInstance();
//     final oldPath = await directoryPath;

//     if (oldPath == newPath) return;

//     final oldHiveDir = Directory(oldPath);
//     final newHiveDir = Directory(newPath);

//     if (!await newHiveDir.exists()) {
//       await newHiveDir.create(recursive: true);
//     }

//     await Hive.close();

//     for (var entity in oldHiveDir.listSync()) {
//       if (entity is File) {
//         final newFile = File(
//           '${newHiveDir.path}/${entity.uri.pathSegments.last}',
//         );
//         await newFile.writeAsBytes(await entity.readAsBytes());
//       }
//     }

//     Hive.init(newPath);
//     await Hive.openBox<Map>(_productBoxName);
//     await Hive.openBox<Map>(_billBoxName);
//     await Hive.openBox<Map>(_customerBoxName);
//     await Hive.openBox<Map>(_userBoxName);
//     await Hive.openBox(_settingsBoxName);

//     await prefs.setString(_directoryPathKey, newPath);
//   }

//   Future<String> get directoryPath async {
//     final prefs = await SharedPreferences.getInstance();
//     return prefs.getString(_directoryPathKey) ??
//         (await getApplicationDocumentsDirectory()).path;
//   }

//   Future<Box> getSettingsBox() async {
//     if (!Hive.isBoxOpen(_settingsBoxName)) {
//       return await Hive.openBox(_settingsBoxName);
//     }
//     return Hive.box(_settingsBoxName);
//   }

//   static Box<Map> get _productBox => Hive.box<Map>(_productBoxName);
//   static Box<Map> get _billBox => Hive.box<Map>(_billBoxName);
//   static Box<Map> get _customerBox => Hive.box<Map>(_customerBoxName);
//   static Box<Map> get _userBox => Hive.box<Map>(_userBoxName);
//   static Box get _settingsBox => Hive.box(_settingsBoxName);

//   // New methods for fieldConfigs
//   Future<void> saveFieldConfigs(Map<String, FieldConfig> fieldConfigs) async {
//     final settingsBox = await getSettingsBox();
//     // Convert FieldConfig objects to a map for storage
//     final fieldConfigsMap = fieldConfigs.map(
//       (key, value) => MapEntry(key, value.toMap()),
//     );
//     await settingsBox.put(_fieldConfigsKey, fieldConfigsMap);
//   }

//   Future<Map<String, FieldConfig>> getFieldConfigs() async {
//     final settingsBox = await getSettingsBox();
//     final fieldConfigsMap = settingsBox.get(_fieldConfigsKey);
//     if (fieldConfigsMap == null) {
//       // Return default field configs if none are stored
//       return {
//         'name': FieldConfig.initial('name', WidgetType.textField),
//         'price': FieldConfig.initial('price', WidgetType.textField),
//         'imageFile': FieldConfig.initial('imageFile', WidgetType.imagePicker),
//         'warranty': FieldConfig.initial('warranty', WidgetType.dropdown),
//         'condition': FieldConfig.initial('condition', WidgetType.dropdown),
//         'brand': FieldConfig.initial('brand', WidgetType.textField),
//         'description': FieldConfig.initial('description', WidgetType.textField),
//         'purchasePrice': FieldConfig.initial(
//           'purchasePrice',
//           WidgetType.textField,
//         ),
//         'stock': FieldConfig.initial('stock', WidgetType.textField),
//         'isBackup': FieldConfig.initial('isBackup', WidgetType.checkbox),
//       };
//     }
//     return (fieldConfigsMap as Map).map(
//       (key, value) =>
//           MapEntry(key, FieldConfig.fromMap(Map<String, dynamic>.from(value))),
//     );
//   }

//   List<Product> getProducts() {
//     return _productBox.values
//         .map((e) => Product.fromMap(Map<String, dynamic>.from(e)))
//         .toList();
//   }

//   Future<void> addProduct(Product product) async {
//     await _productBox.put(product.id, product.toMap());
//   }

//   Future<void> updateProduct(Product product) async {
//     await _productBox.put(product.id, product.toMap());
//   }

//   Future<void> deleteProduct(String id) async {
//     await _productBox.delete(id);
//   }

//   List<Bill> getBills() {
//     final List<Bill> bills = [];
//     for (var value in _billBox.values) {
//       try {
//         final billMap = Map<String, dynamic>.from(value);
//         billMap['customerId'] ??= null;
//         billMap['paymentMethod'] ??= null;
//         bills.add(Bill.fromMap(billMap));
//       } catch (e) {
//         debugPrint('Error deserializing bill: $e');
//       }
//     }
//     return bills;
//   }

//   Future<void> saveBill(Bill bill) async {
//     await _billBox.put(bill.id, bill.toMap());
//   }

//   List<Customer> getCustomers() {
//     return _customerBox.values
//         .map((e) => Customer.fromMap(Map<String, dynamic>.from(e)))
//         .toList();
//   }

//   Future<void> saveCustomer(Customer customer) async {
//     await _customerBox.put(customer.id, customer.toMap());
//   }

//   Future<void> updateCustomer(Customer customer) async {
//     await _customerBox.put(customer.id, customer.toMap());
//   }

//   Future<void> deleteCustomer(String id) async {
//     await _customerBox.delete(id);
//   }

//   List<User> getUsers() {
//     return _userBox.values
//         .map((e) => User.fromMap(Map<String, dynamic>.from(e)))
//         .toList();
//   }

//   Future<void> saveUser(User user) async {
//     await _userBox.put(user.id, user.toMap());
//   }

//   Future<void> updateUser(User user) async {
//     await _userBox.put(user.id, user.toMap());
//   }

//   Future<void> deleteUser(String id) async {
//     await _userBox.delete(id);
//   }

//   Future<void> clearAll() async {
//     await _productBox.clear();
//     await _billBox.clear();
//     await _customerBox.clear();
//     await _userBox.clear();
//     await _settingsBox.clear();
//   }

//   Future<void> deleteBill(String id) async {
//     await _billBox.delete(id);
//   }

//   Future<void> close() async {
//     await Hive.close();
//   }
// }

// // Hive Adapter for FieldConfig
// class FieldConfigAdapter extends TypeAdapter<FieldConfig> {
//   @override
//   final int typeId = 0; // Unique ID for FieldConfig

//   @override
//   FieldConfig read(BinaryReader reader) {
//     return FieldConfig(
//       isShow: reader.readBool(),
//       isRequired: reader.readBool(),
//       hintText: reader.readString(),
//       validatorText: reader.readString(),
//       title: reader.readString(),
//       widgetType: WidgetType.values.firstWhere(
//         (e) => e.toString() == reader.readString(),
//         orElse: () => WidgetType.textField,
//       ),
//     );
//   }

//   @override
//   void write(BinaryWriter writer, FieldConfig obj) {
//     writer.writeBool(obj.isShow);
//     writer.writeBool(obj.isRequired);
//     writer.writeString(obj.hintText);
//     writer.writeString(obj.validatorText);
//     writer.writeString(obj.title);
//     writer.writeString(obj.widgetType.toString());
//   }
// }

// class DatabaseService {
//   final HiveService _hiveService;

//   DatabaseService() : _hiveService = HiveService();

//   Future<void> initialize() async {
//     await _hiveService.init();
//   }

//   Future<List<Product>> getProducts() async {
//     return _hiveService.getProducts();
//   }

//   Future<void> addProduct(Product product) async {
//     await _hiveService.addProduct(product);
//   }

//   Future<void> updateProduct(Product product) async {
//     await _hiveService.updateProduct(product);
//   }

//   Future<void> deleteProduct(String id) async {
//     await _hiveService.deleteProduct(id);
//   }

//   Future<void> saveBill(Bill bill) async {
//     await _hiveService.saveBill(bill);
//   }

//   Future<List<Bill>> getBills() async {
//     return _hiveService.getBills();
//   }

//   Future<List<Customer>> getCustomers() async {
//     return _hiveService.getCustomers();
//   }

//   Future<void> saveCustomer(Customer customer) async {
//     await _hiveService.saveCustomer(customer);
//   }

//   Future<void> updateCustomer(Customer customer) async {
//     await _hiveService.updateCustomer(customer);
//   }

//   Future<void> deleteCustomer(String id) async {
//     await _hiveService.deleteCustomer(id);
//   }

//   Future<List<User>> getUsers() async {
//     return _hiveService.getUsers();
//   }

//   Future<void> saveUser(User user) async {
//     await _hiveService.saveUser(user);
//   }

//   Future<void> updateUser(User user) async {
//     await _hiveService.updateUser(user);
//   }

//   Future<void> deleteUser(String id) async {
//     await _hiveService.deleteUser(id);
//   }

//   Future<void> clearAllData() async {
//     await _hiveService.clearAll();
//   }

//   Future<void> setNewDirectory(String newPath) async {
//     await _hiveService.setDirectoryPath(newPath);
//   }

//   Future<String> getCurrentHivePath() async {
//     return await _hiveService.directoryPath;
//   }

//   Future<void> deleteBill(String id) async {
//     await _hiveService.deleteBill(id);
//   }

//   Future<void> close() async {
//     await _hiveService.close();
//   }

//   // New methods for fieldConfigs
//   Future<void> saveFieldConfigs(Map<String, FieldConfig> fieldConfigs) async {
//     await _hiveService.saveFieldConfigs(fieldConfigs);
//   }

//   Future<Map<String, FieldConfig>> getFieldConfigs() async {
//     return await _hiveService.getFieldConfigs();
//   }
// }
