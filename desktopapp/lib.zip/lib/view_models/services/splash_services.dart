// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'package:desktopapp/res/components/app_text_widgrt.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:local_auth/local_auth.dart';

import '../../routes/routes_name.dart';
import '../providers/settings_provider.dart';

class SplashServices {
  Future<bool> _authenticate(BuildContext context) async {
    final localAuth = LocalAuthentication();
    final canAuthenticate = await localAuth.canCheckBiometrics;
    bool authenticated = false;

    if (canAuthenticate) {
      try {
        authenticated = await localAuth.authenticate(
          localizedReason: 'Authenticate to access the app',
          options: const AuthenticationOptions(
            biometricOnly: false,
            stickyAuth: true,
          ),
        );
      } catch (e) {
        debugPrint('Authentication error: $e');
      }
    } else {
      // Fallback to PIN
      final TextEditingController pinController = TextEditingController();
      bool isPinCorrect = true;

      authenticated =
          await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder:
                (ctx) => StatefulBuilder(
                  builder:
                      (context, setState) => AlertDialog(
                        title: mdText(text: 'Enter App Lock PIN'),
                        content: TextField(
                          controller: pinController,
                          decoration: InputDecoration(
                            labelText: 'Enter PIN (4 digits)',
                            errorText: !isPinCorrect ? 'Incorrect PIN' : null,
                          ),
                          keyboardType: TextInputType.number,
                          maxLength: 4,
                          obscureText: true,
                        ),
                        actions: [
                          ElevatedButton(
                            onPressed: () {
                              if (pinController.text == '1234') {
                                Navigator.pop(ctx, true);
                              } else {
                                setState(() {
                                  isPinCorrect = false;
                                });
                              }
                            },
                            child: Text(
                              'Unlock',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                          ),
                        ],
                      ),
                ),
          ) ??
          false;
    }

    return authenticated;
  }

  void isLogin(WidgetRef ref, BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final settingsState = ref.read(settingsProvider);

      if (settingsState.isAppLockEnabled) {
        final isAuthenticated = await _authenticate(context);

        if (!context.mounted) return;

        if (!isAuthenticated) {
          Navigator.of(context).pop(); // close the app or splash
          return;
        }
      }

      // Navigate after 1 sec
      Timer(const Duration(seconds: 1), () {
        if (context.mounted) {
          Navigator.pushReplacementNamed(context, RouteName.mainScreen);
        }
      });
    });
  }
}
