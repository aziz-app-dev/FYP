import 'package:thermal_printer/thermal_printer.dart';
import '../../models/coustomer_model.dart';

class BillDetailState {
  final List<PrinterDevice> devices;
  final PrinterDevice? selectedPrinter;
  final bool isPrintingThermal;
  final Customer? customer;
  final bool isLoading;

  BillDetailState({
    this.devices = const [],
    this.selectedPrinter,
    this.isPrintingThermal = false,
    this.customer,
    this.isLoading = false,
  });

  BillDetailState copyWith({
    List<PrinterDevice>? devices,
    PrinterDevice? selectedPrinter,
    bool? isPrintingThermal,
    Customer? customer,
    bool? isLoading,
    bool clearSelectedPrinter = false,
    bool clearCustomer = false,
  }) {
    return BillDetailState(
      devices: devices ?? this.devices,
      selectedPrinter: clearSelectedPrinter ? null : (selectedPrinter ?? this.selectedPrinter),
      isPrintingThermal: isPrintingThermal ?? this.isPrintingThermal,
      customer: clearCustomer ? null : (customer ?? this.customer),
      isLoading: isLoading ?? this.isLoading,
    );
  }
}
