// import 'package:thermal_printer/thermal_printer.dart';
// import '../../models/items/items_model.dart';

// class SalesState {
//   final Map<Product, int> cartItems;
//   final bool isPaid;
//   final double totalAmount;
//   final List<PrinterDevice> printers;
//   final PrinterDevice? selectedPrinter;
//   final bool isPrintingThermal;

//   SalesState({
//     this.cartItems = const {},
//     this.isPaid = false,
//     this.totalAmount = 0.0,
//     this.printers = const [],
//     this.selectedPrinter,
//     this.isPrintingThermal = false,
//   });

//   SalesState copyWith({
//     Map<Product, int>? cartItems,
//     bool? isPaid,
//     double? totalAmount,
//     List<PrinterDevice>? printers,
//     PrinterDevice? selectedPrinter,
//     bool? isPrintingThermal,
//   }) {
//     return SalesState(
//       cartItems: cartItems ?? this.cartItems,
//       isPaid: isPaid ?? this.isPaid,
//       totalAmount: totalAmount ?? this.totalAmount,
//       printers: printers ?? this.printers,
//       selectedPrinter: selectedPrinter ?? this.selectedPrinter,
//       isPrintingThermal: isPrintingThermal ?? this.isPrintingThermal,
//     );
//   }
// }

class SettingsState {
  final bool isThermalPrint;
  final bool isPDFSave;
  final bool isPaid;

  SettingsState({
    required this.isThermalPrint,
    required this.isPDFSave,
    required this.isPaid,
  });

  factory SettingsState.initial() {
    return SettingsState(
      isThermalPrint: false,
      isPDFSave: false,
      isPaid: false,
    );
  }

  SettingsState copyWith({
    bool? isThermalPrint,
    bool? isPDFSave,
    bool? isPaid,
  }) {
    return SettingsState(
      isThermalPrint: isThermalPrint ?? this.isThermalPrint,
      isPDFSave: isPDFSave ?? this.isPDFSave,
      isPaid: isPaid ?? this.isPaid,
    );
  }
}
