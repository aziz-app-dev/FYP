class ProductSearchState {
  final String searchQuery;

  const ProductSearchState({
    this.searchQuery = '',
  });

  ProductSearchState copyWith({
    String? searchQuery,
  }) {
    return ProductSearchState(
      searchQuery: searchQuery ?? this.searchQuery,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ProductSearchState && other.searchQuery == searchQuery;
  }

  @override
  int get hashCode => searchQuery.hashCode;
}
