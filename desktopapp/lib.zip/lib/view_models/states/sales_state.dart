// import 'package:thermal_printer/thermal_printer.dart';

// import '../../models/items_model.dart';

// class SalesState {
//   final Map<Product, int> cartItems;
//   final bool isPaid;
//   final double totalAmount;
//   final List<PrinterDevice> printers;
//   final PrinterDevice? selectedPrinter;
//   final bool isPrintingThermal;
//   final String? paymentMethod; // Add this field

//   SalesState({
//     this.cartItems = const {},
//     required this.isPaid,
//     this.totalAmount = 0.0,
//     this.printers = const [],
//     this.selectedPrinter,
//     this.isPrintingThermal = false,
//     this.paymentMethod,
//   });

//   SalesState copyWith({
//     Map<Product, int>? cartItems,
//     bool? isPaid,
//     double? totalAmount,
//     List<PrinterDevice>? printers,
//     PrinterDevice? selectedPrinter,
//     bool? isPrintingThermal,
//     String? paymentMethod, // Add this to copyWith
//   }) {
//     return SalesState(
//       cartItems: cartItems ?? this.cartItems,
//       isPaid: isPaid ?? this.isPaid,
//       totalAmount: totalAmount ?? this.totalAmount,
//       printers: printers ?? this.printers,
//       selectedPrinter: selectedPrinter ?? this.selectedPrinter,
//       isPrintingThermal: isPrintingThermal ?? this.isPrintingThermal,
//       paymentMethod: paymentMethod ?? this.paymentMethod,
//     );
//   }
// }

import 'package:thermal_printer/thermal_printer.dart';

import '../../models/items_model.dart';

class SalesState {
  final Map<Product, int> cartItems;
  final bool isPaid;
  final double totalAmount;
  final List<PrinterDevice> printers;
  final PrinterDevice? selectedPrinter;
  final bool isPrintingThermal;
  final String? paymentMethod; // Add this field
  final double discount;
  final double paidAmount;

  SalesState({
    this.cartItems = const {},
    required this.isPaid,
    this.totalAmount = 0.0,
    this.printers = const [],
    this.selectedPrinter,
    this.isPrintingThermal = false,
    this.paymentMethod,
    this.discount = 0.0,
    this.paidAmount = 0.0,
  });

  SalesState copyWith({
    Map<Product, int>? cartItems,
    bool? isPaid,
    double? totalAmount,
    List<PrinterDevice>? printers,
    PrinterDevice? selectedPrinter,
    bool? isPrintingThermal,
    String? paymentMethod, // Add this to copyWith
    double? discount,
    double? paidAmount,
  }) {
    return SalesState(
      cartItems: cartItems ?? this.cartItems,
      isPaid: isPaid ?? this.isPaid,
      totalAmount: totalAmount ?? this.totalAmount,
      printers: printers ?? this.printers,
      selectedPrinter: selectedPrinter ?? this.selectedPrinter,
      isPrintingThermal: isPrintingThermal ?? this.isPrintingThermal,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      discount: discount ?? this.discount,
      paidAmount: paidAmount ?? this.paidAmount,
    );
  }
}
