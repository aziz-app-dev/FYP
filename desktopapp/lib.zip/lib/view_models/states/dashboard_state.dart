class DashboardState {
  final int currentPage;
  final List<List<String>> data;
  final int rowsPerPage;

  const DashboardState({
    this.currentPage = 0,
    this.data = const [],
    this.rowsPerPage = 10,
  });

  DashboardState copyWith({
    int? currentPage,
    List<List<String>>? data,
    int? rowsPerPage,
  }) {
    return DashboardState(
      currentPage: currentPage ?? this.currentPage,
      data: data ?? this.data,
      rowsPerPage: rowsPerPage ?? this.rowsPerPage,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is DashboardState &&
        other.currentPage == currentPage &&
        other.data == data &&
        other.rowsPerPage == rowsPerPage;
  }

  @override
  int get hashCode => Object.hash(currentPage, data, rowsPerPage);
}
