import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

/// A reusable widget to display when there's no data available
class EmptyWidget extends StatelessWidget {
  final String message;
  final IconData? icon;
  final double? iconSize;
  final Color? iconColor;
  final TextStyle? messageStyle;
  final Widget? action;

  const EmptyWidget({
    super.key,
    required this.message,
    this.icon,
    this.iconSize,
    this.iconColor,
    this.messageStyle,
    this.action,
  });

  /// Factory constructor for empty bills
  factory EmptyWidget.bills() {
    return const EmptyWidget(
      message: 'No bills available',
      icon: Icons.receipt_long_outlined,
    );
  }

  /// Factory constructor for empty customers
  factory EmptyWidget.customers() {
    return const EmptyWidget(
      message: 'No customers found',
      icon: Icons.people_outline,
    );
  }

  /// Factory constructor for empty products
  factory EmptyWidget.products() {
    return const EmptyWidget(
      message: 'No products available',
      icon: Icons.inventory_2_outlined,
    );
  }

  /// Factory constructor for empty search results
  factory EmptyWidget.search({String? query}) {
    return EmptyWidget(
      message: query != null && query.isNotEmpty
          ? 'No results found for "$query"'
          : 'No results found',
      icon: Icons.search_off,
    );
  }

  /// Factory constructor for empty cart
  factory EmptyWidget.cart() {
    return const EmptyWidget(
      message: 'Your cart is empty',
      icon: Icons.shopping_cart_outlined,
    );
  }

  /// Factory constructor for no data
  factory EmptyWidget.noData({String? message}) {
    return EmptyWidget(
      message: message ?? 'No data available',
      icon: Icons.inbox_outlined,
    );
  }

  /// Factory constructor for empty profile
  factory EmptyWidget.profile() {
    return const EmptyWidget(
      message: 'No profile data',
      icon: Icons.person_outline,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final defaultColor = isDark ? Colors.grey[400] : Colors.grey[600];

    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon ?? Icons.inbox_outlined,
              size: iconSize ?? 48.spMin,
              color: iconColor ?? defaultColor,
            ),
            SizedBox(height: 12.h),
            Text(
              message,
              textAlign: TextAlign.center,
              style: messageStyle ??
                  TextStyle(
                    fontSize: 14.spMin,
                    color: defaultColor,
                    fontWeight: FontWeight.w500,
                  ),
            ),
            if (action != null) ...[
              SizedBox(height: 16.h),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}
