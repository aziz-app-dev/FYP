class AppUrl {
  static const String baseUrl = 'https://reqres.in';
  static const String loginApi = '$baseUrl/api/login';

  static const String userListApi =
      'https://jsonplaceholder.typicode.com/users';
      static const String postListApi = 'https://jsonplaceholder.typicode.com/posts';

}
