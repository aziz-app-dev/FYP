import 'package:desktopapp/view/profile/widgets/bank_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';

import '../../../res/components/app_bar_widget.dart';
import '../../../routes/routes_name.dart';
import '../../brands/brand_management_view.dart';
import '../widgets/owner_card.dart';
import '../widgets/shop_card.dart';
import '../widgets/soical_media_card.dart';

class ProfileDeskTabView extends ConsumerWidget {
  const ProfileDeskTabView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: 'Profile',
        context: context,
        backIcon: TablerIcons.menu_3,
        automaticallyImplyLeading: false,
        actions: [
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, size: 20.spMin),
            onSelected: (value) {
              if (value == 'edit') {
                Navigator.pushNamed(context, RouteName.profileEdit);
              } else if (value == 'brands') {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BrandManagementScreen(),
                  ),
                );
              }
            },
            itemBuilder:
                (context) => [
                  PopupMenuItem<String>(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(TablerIcons.edit, size: 18.spMin),
                        SizedBox(width: 12.w),
                        Text(
                          'Edit Profile',
                          style: TextStyle(fontSize: 14.spMin),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuItem<String>(
                    value: 'brands',
                    child: Row(
                      children: [
                        Icon(Icons.branding_watermark, size: 18.spMin),
                        SizedBox(width: 12.w),
                        Text(
                          'Brand Management',
                          style: TextStyle(fontSize: 14.spMin),
                        ),
                      ],
                    ),
                  ),
                ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16.w),
          child: Column(
            spacing: 10.h,
            children: [
              Row(
                spacing: 8.w,
                children: [
                  Expanded(flex: 3, child: ShopOwnerCard()),
                  Expanded(flex: 4, child: ShopCard()),
                ],
              ),
              SoicalMediaCard(),
              BankDetailsCard(),
            ],
          ),
        ),
      ),
    );
  }
}
