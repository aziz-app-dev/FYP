import 'package:desktopapp/res/components/app_bar_widget.dart';
import 'package:desktopapp/view/profile/widgets/shop_card.dart';
import 'package:desktopapp/view/profile/widgets/soical_media_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';
import '../../../routes/routes_name.dart';
import '../../brands/brand_management_view.dart';
import '../widgets/bank_card.dart';
import '../widgets/owner_card.dart';

class ProfileMobileView extends ConsumerWidget {
  final VoidCallback openDrawer;

  const ProfileMobileView({super.key, required this.openDrawer});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: 'Profile',
        context: context,
        backIcon: TablerIcons.menu_3,
        leadingOnTap: () {
          openDrawer();
        },
        actions: [
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, size: 20.spMin),
            onSelected: (value) {
              if (value == 'edit') {
                Navigator.pushNamed(context, RouteName.profileEdit);
              } else if (value == 'brands') {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BrandManagementScreen(),
                  ),
                );
              }
            },
            itemBuilder:
                (context) => [
                  PopupMenuItem<String>(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(TablerIcons.edit, size: 18.spMin),
                        SizedBox(width: 12.w),
                        Text(
                          'Edit Profile',
                          style: TextStyle(fontSize: 14.spMin),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuItem<String>(
                    value: 'brands',
                    child: Row(
                      children: [
                        Icon(Icons.branding_watermark, size: 18.spMin),
                        SizedBox(width: 12.w),
                        Text(
                          'Brand Management',
                          style: TextStyle(fontSize: 14.spMin),
                        ),
                      ],
                    ),
                  ),
                ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
          child: Column(
            spacing: 5.h,
            children: [
              ShopOwnerCard(),
              ShopCard(),
              SoicalMediaCard(),
              BankDetailsCard(),
            ],
          ),
        ),
      ),
    );
  }
}
