import 'package:desktopapp/res/components/app_bar_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:desktopapp/res/colors/app_color.dart';

import 'add_product_view.dart';

class ProductTypeSelectionScreen extends StatelessWidget {
  final String? initialName;

  const ProductTypeSelectionScreen({super.key, this.initialName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: "Select Item Type",
        context: context,
      ),
      //  AppBar(
      //   title: Text(
      //     'Select Item Type',
      //     style: TextStyle(
      //       fontWeight: FontWeight.w600,
      //       fontSize: 20.spMin,
      //       color: Colors.white,
      //     ),
      //   ),
      //   elevation: 0,
      //   backgroundColor: Theme.of(context).primaryColor,
      //   flexibleSpace: Container(
      //     decoration: BoxDecoration(
      //       gradient: LinearGradient(
      //         colors: [
      //           Theme.of(context).primaryColor,
      //           Theme.of(context).primaryColor.withValues(alpha: 0.8),
      //         ],
      //         begin: Alignment.topLeft,
      //         end: Alignment.bottomRight,
      //       ),
      //     ),
      //   ),
      // ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildTypeCard(
                context,
                title: 'Services',
                icon: Icons.build,
                isService: true,
              ),
              SizedBox(width: 20.w),
              _buildTypeCard(
                context,
                title: 'Items',
                icon: Icons.inventory,
                isService: false,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTypeCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required bool isService,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddProductScreen(
                isService: isService,
                initialName: initialName,
              ),
            ),
          );
        },
        child: Card(
          elevation: 6,
          shadowColor: Colors.black.withValues(alpha: 0.1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.r),
          ),
          child: Container(
            height: 200.h,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(color: AppColors.primary, width: 1.5),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 50.spMin, color: AppColors.primary),
                SizedBox(height: 10.h),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 20.spMin,
                    fontWeight: FontWeight.bold,
                    // color: Theme.of(context).primaryColor,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
