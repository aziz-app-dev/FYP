// ignore_for_file: use_build_context_synchronously, deprecated_member_use, library_private_types_in_public_api

import 'package:desktopapp/res/components/app_bar_widget.dart';
import 'package:desktopapp/res/components/app_button.dart';
import 'package:desktopapp/utils/app_sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:desktopapp/res/colors/app_color.dart';
import '../../models/items_model.dart';
import '../../models/brand_model.dart';
import '../../models/category_model.dart';
import '../../res/components/app_text_widgrt.dart';
import '../../res/components/text_field_widget.dart';
import '../../view_models/providers/add_prduct_provider.dart';
import '../../view_models/states/add_product_states.dart';
import '../../view_models/services/database/database_services.dart';
import '../home/rapper.dart';

// Provider to load brands
final brandsProvider = FutureProvider.autoDispose<List<Brand>>((ref) async {
  final dbService = DatabaseService();
  return await dbService.getBrands();
});

// Provider to load categories
final categoriesProvider = FutureProvider.autoDispose<List<Category>>((
  ref,
) async {
  final dbService = DatabaseService();
  return await dbService.getCategories();
});

class AddProductScreen extends ConsumerStatefulWidget {
  final Product? product;
  final bool isService;
  final String? initialName;

  const AddProductScreen({
    super.key,
    this.product,
    required this.isService,
    this.initialName,
  });

  @override
  _AddProductScreenState createState() => _AddProductScreenState();
}

class _AddProductScreenState extends ConsumerState<AddProductScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // Declare controllers
  late TextEditingController _nameController;
  late TextEditingController _priceController;
  late TextEditingController _purchasePriceController;
  late TextEditingController _stockController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    // Initialize controllers with initial values from formState
    final formState = ref.read(productFormProvider(widget.product));
    // Use initialName if provided, otherwise use formState name
    _nameController = TextEditingController(
      text: widget.initialName ?? formState.name,
    );
    _priceController = TextEditingController(text: formState.price?.toString());
    _purchasePriceController = TextEditingController(
      text: formState.purchasePrice?.toString(),
    );
    _stockController = TextEditingController(text: formState.stock?.toString());
    _descriptionController = TextEditingController(text: formState.description);
  }

  @override
  void didUpdateWidget(AddProductScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Update controllers if the product changes (e.g., navigating to edit a different product)
    if (oldWidget.product != widget.product) {
      final formState = ref.read(productFormProvider(widget.product));
      _nameController.text = formState.name ?? '';
      _priceController.text = formState.price?.toString() ?? '';
      _purchasePriceController.text = formState.purchasePrice?.toString() ?? '';
      _stockController.text = formState.stock?.toString() ?? '';
      _descriptionController.text = formState.description ?? '';
    }
  }

  @override
  void dispose() {
    // Dispose of controllers to prevent memory leaks
    _nameController.dispose();
    _priceController.dispose();
    _purchasePriceController.dispose();
    _stockController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title:
            widget.product == null
                ? 'Add New ${widget.isService ? 'Service' : 'Item'}'
                : 'Edit ${widget.isService ? 'Service' : 'Item'}',
        context: context,
      ),
      body: ResponsiveWrapper(
        mobile: _buildMobileForm(context, ref),
        tablet: _buildTabletForm(context, ref),
        desktop: _buildDesktopForm(context, ref),
      ),
    );
  }

  Widget _buildMobileForm(BuildContext context, WidgetRef ref) {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
      child: _buildForm(context, ref),
    );
  }

  Widget _buildTabletForm(BuildContext context, WidgetRef ref) {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 24.h),
      child: _buildForm(context, ref),
    );
  }

  Widget _buildDesktopForm(BuildContext context, WidgetRef ref) {
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 600.w),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 32.w, vertical: 32.h),
          child: _buildForm(context, ref),
        ),
      ),
    );
  }

  Widget _buildForm(BuildContext context, WidgetRef ref) {
    final formState = ref.watch(productFormProvider(widget.product));
    final formNotifier = ref.read(productFormProvider(widget.product).notifier);
    final isEditing = widget.product != null;
    final buttonText =
        isEditing
            ? 'Update ${widget.isService ? 'Service' : 'Item'}'
            : 'Add ${widget.isService ? 'Service' : 'Item'}';
    final fieldConfigs = formState.fieldConfigs;
    final fieldErrors =
        formState.fieldErrors; // Get from state instead of local

    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: AppSizes.horizontalPaddingSm.w,
        vertical: AppSizes.verticalPaddingSm,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Image Picker
            if (fieldConfigs['imageFile']!.isShow) ...[
              Stack(
                children: [
                  GestureDetector(
                    onTap: () async {
                      await formNotifier.pickImage();
                    },
                    child: Container(
                      height: 250.h,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color:
                              Theme.of(context).brightness == Brightness.dark
                                  ? AppColors.dTFieldHintColor
                                  : AppColors.lTFieldHintColor ??
                                      AppColors.primary,
                          width: 1.5,
                        ),
                        borderRadius: BorderRadius.circular(12.r),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.05),
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12.r),
                        child:
                            formState.imageFile != null
                                ? Image.file(
                                  formState.imageFile!,
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                )
                                : Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.add_a_photo_outlined,
                                        size: 25.spMin,
                                        color:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? AppColors.dIconColor
                                                : AppColors.lIconColor,
                                      ),
                                      SizedBox(height: 8.h),
                                      smTextBold(
                                        text:
                                            fieldConfigs['imageFile']!.hintText,
                                        color:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? AppColors.grey100
                                                : AppColors.grey700,
                                      ),
                                    ],
                                  ),
                                ),
                      ),
                    ),
                  ),
                  if (formState.imageFile != null)
                    Positioned(
                      top: 8.h,
                      right: 8.w,
                      child: IconButton(
                        icon: Icon(
                          Icons.cancel,
                          color: Colors.red,
                          size: 18.spMin,
                        ),
                        onPressed: () => formNotifier.updateImageFile(null),
                      ),
                    ),
                ],
              ),
              if (fieldConfigs['imageFile']!.isRequired &&
                  formState.imageFile == null &&
                  widget.product?.imageUrl == null)
                Padding(
                  padding: EdgeInsets.only(top: 8.h),
                  child: smText(
                    text: fieldConfigs['imageFile']!.validatorText,
                    color: AppColors.error,
                  ),
                ),
              SizedBox(height: 20.h),
            ],

            // Name Field
            if (fieldConfigs['name']!.isShow)
              CustomTextField(
                controller: _nameController,
                label:
                    fieldConfigs['name']!.isRequired
                        ? fieldConfigs['name']!.title
                        : fieldConfigs['name']!.title,
                lableColor:
                    (fieldErrors['name'] ?? false) &&
                            fieldConfigs['name']!.isRequired
                        ? AppColors.error
                        : Theme.of(context).brightness == Brightness.dark
                        ? AppColors.dTFieldHintColor
                        : AppColors.lTFieldHintColor,
                hintText: fieldConfigs['name']!.hintText,
                filled: true,
                prefixIcon: Icon(
                  Icons.label_outline,
                  color: AppColors.primary.withValues(alpha: 0.7),
                  size: 20.spMin,
                ),
                validator: (value) {
                  final hasError =
                      fieldConfigs['name']!.isRequired &&
                      (value == null || value.isEmpty);
                  return hasError ? fieldConfigs['name']!.validatorText : null;
                },
                onChange: (value) {
                  formNotifier.updateName(value ?? '');
                  return null;
                },
              ),
            SizedBox(height: 16.h),

            // Other Fields
            ..._buildOtherFields(
              formState,
              formNotifier,
              widget.isService,
              context,
            ),

            // Timestamps
            if (isEditing) ...[
              SizedBox(height: 16.h),
              Container(
                padding: EdgeInsets.all(12.h),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Created: ${formState.createdAt?.toString().substring(0, 16) ?? 'N/A'}',
                      style: TextStyle(
                        fontSize: 14.spMin,
                        color: Colors.grey.shade700,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      'Updated: ${formState.updatedAt?.toString().substring(0, 16) ?? 'N/A'}',
                      style: TextStyle(
                        fontSize: 14.spMin,
                        color: Colors.grey.shade700,
                      ),
                    ),
                  ],
                ),
              ),
            ],

            // Error Message
            if (formState.errorMessage != null)
              Padding(
                padding: EdgeInsets.symmetric(vertical: 12.h),
                child: Text(
                  formState.errorMessage!,
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 14.spMin,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),

            // Submit Button
            AnimatedScale(
              scale: formState.isLoading ? 0.95 : 1.0,
              duration: Duration(milliseconds: 200),
              child: AppButton().primaryButton(
                text: buttonText,
                isLoading: formState.isLoading,
                onPressed: () async {
                  formNotifier.validateAllFields(); // Use Riverpod validation
                  if (_formKey.currentState!.validate()) {
                    final success = await formNotifier.submitForm();
                    if (success) {
                      // Show success message
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            widget.product == null
                                ? '${widget.isService ? 'Service' : 'Product'} added successfully!'
                                : '${widget.isService ? 'Service' : 'Product'} updated successfully!',
                            style: TextStyle(fontSize: 14.spMin),
                          ),
                          backgroundColor: Colors.green,
                          duration: Duration(seconds: 2),
                        ),
                      );

                      // Only navigate back when editing an existing product
                      // When adding new products, stay on the page to allow quick addition of similar items
                      if (widget.product != null) {
                        Navigator.pop(context, true);
                      } else {
                        // Clear all text controllers
                        _nameController.clear();
                        _priceController.clear();
                        _purchasePriceController.clear();
                        _stockController.clear();
                        _descriptionController.clear();

                        // Reset form state
                        formNotifier.resetForm();

                        // Reset form validation
                        _formKey.currentState?.reset();
                      }
                    }
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildOtherFields(
    ProductFormState formState,
    ProductFormNotifier formNotifier,
    bool isService,
    BuildContext context,
  ) {
    final fieldConfigs = formState.fieldConfigs;
    final fieldErrors = formState.fieldErrors; // Get from state
    final fields = <Widget>[];

    // Price
    if (fieldConfigs['price']!.isShow) {
      fields.add(
        CustomTextField(
          controller: _priceController,
          label:
              fieldConfigs['price']!.isRequired
                  ? fieldConfigs['price']!.title
                  : fieldConfigs['price']!.title,
          lableColor:
              (fieldErrors['price'] ?? false) &&
                      fieldConfigs['price']!.isRequired
                  ? AppColors.error
                  : Theme.of(context).brightness == Brightness.dark
                  ? AppColors.dTFieldHintColor
                  : AppColors.lTFieldHintColor,
          hintText: fieldConfigs['price']!.hintText,
          keyboardType: TextInputType.number,
          filled: true,
          prefixIcon: Icon(
            Icons.attach_money,
            color: AppColors.primary.withValues(alpha: 0.7),
            size: 20.spMin,
          ),
          validator: (value) {
            final hasError =
                fieldConfigs['price']!.isRequired &&
                (double.tryParse(value ?? '') == null ||
                    double.parse(value!) <= 0);
            return hasError ? fieldConfigs['price']!.validatorText : null;
          },
          onChange: (value) {
            formNotifier.updatePrice(value ?? '');
            return null;
          },
        ),
      );
      fields.add(SizedBox(height: 16.h));
    }

    // Product-specific fields
    if (!isService) {
      if (fieldConfigs['purchasePrice']!.isShow) {
        fields.add(
          CustomTextField(
            controller: _purchasePriceController,
            label:
                fieldConfigs['purchasePrice']!.isRequired
                    ? fieldConfigs['purchasePrice']!.title
                    : fieldConfigs['purchasePrice']!.title,
            lableColor:
                (fieldErrors['purchasePrice'] ?? false) &&
                        fieldConfigs['purchasePrice']!.isRequired
                    ? AppColors.error
                    : Theme.of(context).brightness == Brightness.dark
                    ? AppColors.dTFieldHintColor
                    : AppColors.lTFieldHintColor,
            hintText: fieldConfigs['purchasePrice']!.hintText,
            keyboardType: TextInputType.number,
            filled: true,
            prefixIcon: Icon(
              Icons.shopping_cart_outlined,
              color: AppColors.primary.withValues(alpha: 0.7),
              size: 20.spMin,
            ),
            validator: (value) {
              final hasError =
                  fieldConfigs['purchasePrice']!.isRequired &&
                  (double.tryParse(value ?? '') == null ||
                      double.parse(value!) <= 0);
              return hasError
                  ? fieldConfigs['purchasePrice']!.validatorText
                  : null;
            },
            onChange: (value) {
              formNotifier.updatePurchasePrice(value ?? '');
              return null;
            },
          ),
        );
        fields.add(SizedBox(height: 16.h));
      }

      if (fieldConfigs['stock']!.isShow) {
        fields.add(
          CustomTextField(
            controller: _stockController,
            label:
                fieldConfigs['stock']!.isRequired
                    ? fieldConfigs['stock']!.title
                    : fieldConfigs['stock']!.title,
            lableColor:
                (fieldErrors['stock'] ?? false) &&
                        fieldConfigs['stock']!.isRequired
                    ? AppColors.error
                    : Theme.of(context).brightness == Brightness.dark
                    ? AppColors.dTFieldHintColor
                    : AppColors.lTFieldHintColor,
            hintText: fieldConfigs['stock']!.hintText,
            keyboardType: TextInputType.number,
            filled: true,
            prefixIcon: Icon(
              Icons.inventory_2_outlined,
              color: AppColors.primary.withValues(alpha: 0.7),
              size: 20.spMin,
            ),
            validator: (value) {
              final hasError =
                  fieldConfigs['stock']!.isRequired &&
                  (int.tryParse(value ?? '') == null || int.parse(value!) < 0);
              return hasError ? fieldConfigs['stock']!.validatorText : null;
            },
            onChange: (value) {
              formNotifier.updateStock(value ?? '');
              return null;
            },
          ),
        );
        fields.add(SizedBox(height: 16.h));
      }

      if (fieldConfigs['condition']!.isShow) {
        fields.add(
          AppDropdown<String>(
            label:
                fieldConfigs['condition']!.isRequired
                    ? fieldConfigs['condition']!.title
                    : fieldConfigs['condition']!.title,
            lableColor:
                (fieldErrors['condition'] ?? false) &&
                        fieldConfigs['condition']!.isRequired
                    ? AppColors.error
                    : Theme.of(context).brightness == Brightness.dark
                    ? AppColors.dTFieldHintColor
                    : AppColors.lTFieldHintColor,
            hintText: fieldConfigs['condition']!.hintText,
            value: formState.condition,
            items: const ['New', 'Used'],
            displayItems: const ['New', 'Used'],
            filled: true,
            onChanged: (value) {
              formNotifier.updateCondition(value);
            },
          ),
        );
        fields.add(SizedBox(height: 12.h));
      }

      if (fieldConfigs['brand']!.isShow) {
        final brandsAsync = ref.watch(brandsProvider);
        fields.add(
          brandsAsync.when(
            data: (brands) {
              final brandNames = brands.map((b) => b.name).toList();
              return AppDropdown<String>(
                label:
                    fieldConfigs['brand']!.isRequired
                        ? fieldConfigs['brand']!.title
                        : fieldConfigs['brand']!.title,
                lableColor:
                    (fieldErrors['brand'] ?? false) &&
                            fieldConfigs['brand']!.isRequired
                        ? AppColors.error
                        : Theme.of(context).brightness == Brightness.dark
                        ? AppColors.dTFieldHintColor
                        : AppColors.lTFieldHintColor,
                hintText: fieldConfigs['brand']!.hintText,
                value:
                    formState.brand != null &&
                            brandNames.contains(formState.brand)
                        ? formState.brand
                        : null,
                items: brandNames,
                displayItems: brandNames,
                filled: true,
                onChanged: (value) {
                  formNotifier.updateBrand(value ?? '');
                },
              );
            },
            loading:
                () => Container(
                  height: 56.h,
                  padding: EdgeInsets.symmetric(horizontal: 12.w),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color:
                          Theme.of(context).brightness == Brightness.dark
                              ? (AppColors.dTFieldHintColor)
                              : (AppColors.lTFieldHintColor ?? Colors.grey),
                    ),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 16.w,
                        height: 16.w,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppColors.primary,
                          ),
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Text(
                        'Loading brands...',
                        style: TextStyle(
                          fontSize: 14.spMin,
                          color:
                              Theme.of(context).brightness == Brightness.dark
                                  ? AppColors.dTFieldHintColor
                                  : AppColors.lTFieldHintColor,
                        ),
                      ),
                    ],
                  ),
                ),
            error:
                (error, stack) => Container(
                  height: 56.h,
                  padding: EdgeInsets.symmetric(horizontal: 12.w),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.error),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.error_outline,
                        color: AppColors.error,
                        size: 20.spMin,
                      ),
                      SizedBox(width: 12.w),
                      Expanded(
                        child: Text(
                          'Error loading brands',
                          style: TextStyle(
                            fontSize: 14.spMin,
                            color: AppColors.error,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
          ),
        );
        fields.add(SizedBox(height: 16.h));
      }

      // Category Dropdown
      if (fieldConfigs['category']!.isShow) {
        final categoriesAsync = ref.watch(categoriesProvider);
        fields.add(
          categoriesAsync.when(
            data: (categories) {
              final categoryNames = categories.map((c) => c.name).toList();
              return AppDropdown<String>(
                label:
                    fieldConfigs['category']!.isRequired
                        ? fieldConfigs['category']!.title
                        : fieldConfigs['category']!.title,
                lableColor:
                    (fieldErrors['category'] ?? false) &&
                            fieldConfigs['category']!.isRequired
                        ? AppColors.error
                        : Theme.of(context).brightness == Brightness.dark
                        ? AppColors.dTFieldHintColor
                        : AppColors.lTFieldHintColor,
                hintText: fieldConfigs['category']!.hintText,
                value:
                    formState.category != null &&
                            categoryNames.contains(formState.category)
                        ? formState.category
                        : null,
                items: categoryNames,
                displayItems: categoryNames,
                filled: true,
                onChanged: (value) {
                  formNotifier.updateCategory(value ?? '');
                },
              );
            },
            loading:
                () => Container(
                  height: 56.h,
                  padding: EdgeInsets.symmetric(horizontal: 12.w),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color:
                          Theme.of(context).brightness == Brightness.dark
                              ? (AppColors.dTFieldHintColor)
                              : (AppColors.lTFieldHintColor ?? Colors.grey),
                    ),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 16.w,
                        height: 16.w,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppColors.primary,
                          ),
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Text(
                        'Loading categories...',
                        style: TextStyle(
                          fontSize: 14.spMin,
                          color:
                              Theme.of(context).brightness == Brightness.dark
                                  ? AppColors.dTFieldHintColor
                                  : AppColors.lTFieldHintColor,
                        ),
                      ),
                    ],
                  ),
                ),
            error:
                (error, stack) => Container(
                  height: 56.h,
                  padding: EdgeInsets.symmetric(horizontal: 12.w),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.error),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.error_outline,
                        color: AppColors.error,
                        size: 20.spMin,
                      ),
                      SizedBox(width: 12.w),
                      Expanded(
                        child: Text(
                          'Error loading categories',
                          style: TextStyle(
                            fontSize: 14.spMin,
                            color: AppColors.error,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
          ),
        );
        fields.add(SizedBox(height: 16.h));
      }
    }

    // Description
    if (fieldConfigs['description']!.isShow) {
      fields.add(
        CustomTextField(
          controller: _descriptionController,
          label:
              fieldConfigs['description']!.isRequired
                  ? fieldConfigs['description']!.title
                  : fieldConfigs['description']!.title,
          lableColor:
              (fieldErrors['description'] ?? false) &&
                      fieldConfigs['description']!.isRequired
                  ? AppColors.error
                  : Theme.of(context).brightness == Brightness.dark
                  ? AppColors.dTFieldHintColor
                  : AppColors.lTFieldHintColor,
          hintText: fieldConfigs['description']!.hintText,
          maxLines: 3,
          filled: true,
          prefixIcon: Icon(
            Icons.description_outlined,
            color: AppColors.primary.withValues(alpha: 0.7),
            size: 20.spMin,
          ),
          validator: (value) {
            final hasError =
                fieldConfigs['description']!.isRequired &&
                (value == null || value.isEmpty);
            return hasError ? fieldConfigs['description']!.validatorText : null;
          },
          onChange: (value) {
            formNotifier.updateDescription(value ?? '');
            return null;
          },
        ),
      );
      fields.add(SizedBox(height: 16.h));
    }

    return fields;
  }
}
