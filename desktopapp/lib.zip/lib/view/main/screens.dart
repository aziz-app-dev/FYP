import 'package:desktopapp/models/navigation_models.dart';
import 'package:desktopapp/view/home/home_view.dart';
import 'package:desktopapp/view/profile/profile_view.dart';
import 'package:desktopapp/view/sales/multi_cart_sale_view.dart';
import 'package:desktopapp/view/settings/settings_view.dart';
import 'package:desktopapp/view_models/providers/settings_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';

import '../bills/bills_view.dart';
import '../customers/customer_list_view.dart';
import '../sales/sale_view.dart';

//! Navigation Items
const List<NavigationItem> navItems = [
  NavigationItem(
    icon: TablerIcons.home,
    activeIcon: TablerIcons.home,
    label: 'Home',
  ),
  NavigationItem(
    icon: TablerIcons.shopping_bag,
    activeIcon: TablerIcons.shopping_bag,
    label: 'Sales',
  ),
  NavigationItem(
    icon: TablerIcons.receipt,
    activeIcon: TablerIcons.receipt,
    label: 'Receipts',
  ),
  NavigationItem(
    icon: TablerIcons.users,
    activeIcon: TablerIcons.users,
    label: 'Customers',
  ),
  NavigationItem(
    icon: Icons.person_4_outlined,
    activeIcon: Icons.person_4_outlined,
    label: 'Profile',
  ),
  NavigationItem(
    icon: TablerIcons.settings,
    activeIcon: TablerIcons.settings,
    label: 'Settings',
  ),
];

// Sales screen selector based on settings
class SalesScreenSelector extends ConsumerWidget {
  const SalesScreenSelector({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final useMultiCart = ref.watch(settingsProvider.select((s) => s.useMultiCart));

    return useMultiCart
        ? const MultiCartSalesScreen()
        : const SalesScreen();
  }
}

List<Widget> pages(GlobalKey<ScaffoldState> scaffoldKey) => [
  HomePage(openDrawer: () => scaffoldKey.currentState?.openDrawer()),
  const SalesScreenSelector(), // Dynamically shows single or multi-cart based on settings
  BillsScreen(),
  CustomerListScreen(),
  ProfileView(openDrawer: () => scaffoldKey.currentState?.openDrawer()),
  SettingsPage(openDrawer: () => scaffoldKey.currentState?.openDrawer()),
];
