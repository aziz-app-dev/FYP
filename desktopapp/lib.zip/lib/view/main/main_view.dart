import 'package:desktopapp/models/navigation_models.dart';
import 'package:desktopapp/res/colors/app_color.dart';
import 'package:desktopapp/utils/app_sizes.dart';
import 'package:desktopapp/view/main/infoCard.dart';
import 'package:desktopapp/view/main/screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../view_models/providers/profile_provider.dart';

// Riverpod provider for selected index
final selectedIndexProvider = StateProvider<int>((ref) => 0);

class MainScrenn extends ConsumerStatefulWidget {
  const MainScrenn({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _MainScrennState();
}

class _MainScrennState extends ConsumerState<MainScrenn> {
  @override
  void initState() {
    super.initState();
    ref.read(profileProvider.notifier).loadUserData();
  }

  Widget buildDesktopDrawer(WidgetRef ref) {
    final selectedIndex = ref.watch(selectedIndexProvider);
    final Color activeIconColor = AppColors.primary;
    final Color inactiveIconColor = Colors.grey[600]!;
    return Container(
      color:
          (Theme.of(context).brightness == Brightness.dark
              ? AppColors.dBottomNavBarColor
              : Colors.white),
      width: 185.h,
      child: Column(
        children: [
          infoCard(ref),
          ...navItems.asMap().entries.map((entry) {
            final index = entry.key;
            final item = entry.value;
            return Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 12.0,
                vertical: 4.0,
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(12.0),
                onTap:
                    () =>
                        ref.read(selectedIndexProvider.notifier).state = index,
                child: Container(
                  padding: const EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    color:
                        selectedIndex == index
                            ? activeIconColor.withValues(alpha: 0.2)
                            : Colors.transparent,
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        selectedIndex == index ? item.activeIcon : item.icon,
                        color:
                            selectedIndex == index
                                ? activeIconColor
                                : inactiveIconColor,
                      ),
                      const SizedBox(width: 12),
                      Text(
                        item.label,
                        style: TextStyle(
                          fontWeight:
                              selectedIndex == index
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget buildTabletNavItem(int index, NavigationItem item, WidgetRef ref) {
    final selectedIndex = ref.watch(selectedIndexProvider);
    final Color activeIconColor = AppColors.primary;
    final Color inactiveIconColor = Colors.grey[600]!;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: IconButton(
        padding: EdgeInsets.all(2),
        highlightColor: activeIconColor.withValues(alpha: 0.3),
        splashRadius: 10,
        hoverColor: activeIconColor.withValues(alpha: 0.2),
        icon: Container(
          padding: EdgeInsets.all(8.spMin),
          decoration: BoxDecoration(
            color:
                selectedIndex == index
                    ? activeIconColor.withValues(alpha: 0.2)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(12.0),
          ),
          child: Icon(
            selectedIndex == index ? item.activeIcon : item.icon,
            color: selectedIndex == index ? activeIconColor : inactiveIconColor,
          ),
        ),
        onPressed: () => ref.read(selectedIndexProvider.notifier).state = index,
      ),
    );
  }

  Widget buildMobileDrawer(WidgetRef ref) {
    final selectedIndex = ref.watch(selectedIndexProvider);
    final Color activeIconColor = AppColors.primary;
    final Color inactiveIconColor = Colors.grey[600]!;

    return Drawer(
      child: FocusScope(
        child: Builder(
          builder: (BuildContext drawerContext) {
            return Column(
              children: [
                infoCard(ref),
                ...navItems.asMap().entries.map((entry) {
                  final index = entry.key;
                  final item = entry.value;
                  return Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 12.w,
                      vertical: 2.h,
                    ),
                    child: InkWell(
                      focusNode: FocusNode(
                        // Skip traversal to avoid unnecessary focus events
                        skipTraversal: true,
                        // Ensure focus is not retained after disposal
                        // onDispose: () {},
                      ),
                      borderRadius: BorderRadius.circular(12.0),
                      onTap: () {
                        // Update state and close drawer in a post-frame callback
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          ref.read(selectedIndexProvider.notifier).state =
                              index;
                          Navigator.pop(drawerContext);
                        });
                      },
                      child: Container(
                        padding: EdgeInsets.all(10.h),
                        decoration: BoxDecoration(
                          color:
                              selectedIndex == index
                                  ? activeIconColor.withValues(alpha: 0.2)
                                  : Colors.transparent,
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              selectedIndex == index
                                  ? item.activeIcon
                                  : item.icon,
                              color:
                                  selectedIndex == index
                                      ? activeIconColor
                                      : inactiveIconColor,
                            ),
                            const SizedBox(width: 12),
                            Text(item.label),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget buildMobileBottomNavBar(WidgetRef ref) {
    final selectedIndex = ref.watch(selectedIndexProvider);
    final Color activeIconColor = AppColors.primary;
    final Color inactiveIconColor = Colors.grey[600]!;

    return NavigationBar(
      backgroundColor:
          (Theme.of(context).brightness == Brightness.dark
              ? AppColors.dBottomNavBarColor
              : Colors.white),
      indicatorColor: Colors.transparent,
      selectedIndex: selectedIndex,
      overlayColor: WidgetStatePropertyAll(Colors.transparent),
      labelTextStyle: WidgetStatePropertyAll(
        TextStyle(fontSize: 12.spMin, fontWeight: FontWeight.bold),
      ),
      onDestinationSelected:
          (index) => ref.read(selectedIndexProvider.notifier).state = index,
      destinations:
          navItems
              .map(
                (item) => NavigationDestination(
                  icon: Icon(item.icon, color: inactiveIconColor),
                  selectedIcon: Container(
                    decoration: BoxDecoration(
                      color: activeIconColor.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(8.h),
                      child: Icon(
                        item.activeIcon,
                        color: activeIconColor,
                        size: 22.spMin,
                      ),
                    ),
                  ),

                  label: item.label,
                ),
              )
              .toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedIndex = ref.watch(selectedIndexProvider);

    final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
    if (AppSizes.isTablet(context)) {
      return Scaffold(
        body: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              color:
                  (Theme.of(context).brightness == Brightness.dark
                      ? AppColors.dBottomNavBarColor
                      : Colors.white),
              height: MediaQuery.sizeOf(context).height,
              width: 35.w,

              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 20.h),
                    tabIcon(ref),
                    SizedBox(height: 20.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Divider(),
                    ),
                    ...navItems.asMap().entries.map((entry) {
                      final index = entry.key;
                      final item = entry.value;
                      return buildTabletNavItem(index, item, ref);
                    }),
                  ],
                ),
              ),
            ),
            VerticalDivider(),
            Expanded(
              child: pages(scaffoldKey)[selectedIndex],
            ), // Pass scaffoldKey
          ],
        ),
      );
    } else if (AppSizes.isDesktop(context)) {
      return Scaffold(
        body: Row(
          children: [
            buildDesktopDrawer(ref),
            VerticalDivider(),
            Expanded(
              child: pages(scaffoldKey)[selectedIndex],
            ), // Pass scaffoldKey
          ],
        ),
      );
    } else {
      return Scaffold(
        key: scaffoldKey,
        drawer: buildMobileDrawer(ref), // Always enable the drawer
        body: pages(scaffoldKey)[selectedIndex], // Pass scaffoldKey
        bottomNavigationBar: buildMobileBottomNavBar(ref),
      );
    }
  }
}
