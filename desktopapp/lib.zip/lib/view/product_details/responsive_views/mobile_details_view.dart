import 'dart:io';
import 'package:desktopapp/res/components/app_text_widgrt.dart';
import 'package:desktopapp/utils/app_sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../models/items_model.dart';
import '../../../res/colors/app_color.dart';
import '../../../view_models/providers/product_details_provider.dart';
import '../../../view_models/states/product_details_state.dart';
import '../product_details_view.dart';

class MobileProductDetailsView extends ConsumerWidget {
  final Product product;

  const MobileProductDetailsView({super.key, required this.product});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detailsState = ref.watch(productDetailsProvider(product));
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? Colors.black : Colors.white;
    final cardColor = isDark ? Colors.grey.shade900 : Colors.grey.shade50;

    return SingleChildScrollView(
      child: Column(
        children: [
          // Hero Image Section
          Hero(
            tag: 'product-${product.id}',
            child: Stack(
              children: [
                Container(
                  width: double.infinity,
                  height: 200.h,
                  color: isDark ? Colors.grey.shade900 : Colors.grey.shade100,
                  child:
                      product.imageUrl != null
                          ? Image.file(
                            File(product.imageUrl!),
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return Center(
                                child: Icon(
                                  Icons.image_not_supported,
                                  size: 80.spMin,
                                  color: Colors.grey,
                                ),
                              );
                            },
                          )
                          : Center(
                            child: Icon(
                              product.isService
                                  ? Icons.room_service
                                  : Icons.inventory_2_rounded,
                              size: 100.spMin,
                              color: Colors.grey.shade400,
                            ),
                          ),
                ),
                if (detailsState.brandLogoUrl != null)
                  Positioned(
                    top: 10.h,
                    right: 10.h,
                    child: Container(
                      width: 30.w,
                      height: 30.w,
                      margin: EdgeInsets.only(right: 6.w),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4.r),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4.r),
                        child: Image.file(
                          File(detailsState.brandLogoUrl!),
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Icon(
                              Icons.branding_watermark,
                              size: 16.spMin,
                              color: Colors.grey,
                            );
                          },
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),

          //! Content
          Container(
            color: bgColor,
            padding: EdgeInsets.symmetric(
              horizontal: AppSizes.md.h,
              vertical: AppSizes.md.h,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //! Name and Type
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: mdTextBold(
                        text: product.name,
                        maxLines: 2,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 6.h,
                        vertical: 4.h,
                      ),
                      decoration: BoxDecoration(
                        color:
                            product.isService
                                ? Colors.purple
                                : AppColors.primary,
                        borderRadius: BorderRadius.circular(
                          AppSizes.borderRadiusMd.r,
                        ),
                      ),
                      child: xsTextBold(
                        text: product.isService ? 'Service' : 'Product',
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 10.h),

                // Price and Brand
                lgTextBold(
                  text: 'Rs ${product.price.toStringAsFixed(2)}',
                  color: AppColors.primary,
                ),

                // SizedBox(height: 8.h),
                // Row(
                //   children: [
                //     if (detailsState.brandLogoUrl != null)
                //       Container(
                //         width: 24.w,
                //         height: 24.w,
                //         margin: EdgeInsets.only(right: 6.w),
                //         decoration: BoxDecoration(
                //           borderRadius: BorderRadius.circular(4.r),
                //         ),
                //         child: ClipRRect(
                //           borderRadius: BorderRadius.circular(4.r),
                //           child: Image.file(
                //             File(detailsState.brandLogoUrl!),
                //             fit: BoxFit.cover,
                //             errorBuilder: (context, error, stackTrace) {
                //               return Icon(
                //                 Icons.branding_watermark,
                //                 size: 16.spMin,
                //                 color: Colors.grey,
                //               );
                //             },
                //           ),
                //         ),
                //       )
                //     else
                //       Padding(
                //         padding: EdgeInsets.only(right: 6.w),
                //         child: Icon(
                //           Icons.branding_watermark,
                //           size: 16.spMin,
                //           color: Colors.grey,
                //         ),
                //       ),
                //     mdText(text: product.brand ?? 'No Brand'),
                //   ],
                // ),
                SizedBox(height: 32.h),

                // Sales Stats
                if (!detailsState.isLoading)
                  _buildSalesStatsCard(
                    detailsState,
                    context,
                    isDark,
                    cardColor,
                  ),

                SizedBox(height: 20.h),

                //! Product Info
                if (!product.isService) ...[
                  _buildInfoSection(context, isDark, cardColor),
                  SizedBox(height: 20.h),
                ],

                //! Description
                if (product.description != null &&
                    product.description!.isNotEmpty) ...[
                  mdTextBold(text: 'About'),
                  SizedBox(height: 12.h),
                  smText(text: product.description!, height: 1.5),
                  SizedBox(height: 24.h),
                ],

                //! Additional Details
                _buildDetailsSection(context, isDark, cardColor),

                SizedBox(height: 32.h),

                // Related Products
                if (detailsState.relatedProducts.isNotEmpty) ...[
                  _buildRelatedProductsSection(
                    detailsState,
                    context,
                    isDark,
                    cardColor,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSalesStatsCard(
    ProductDetailsState state,
    BuildContext context,
    bool isDark,
    Color cardColor,
  ) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSizes.md.h,
        vertical: AppSizes.sm.h,
      ),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.analytics_outlined,
                color: AppColors.primary,
                size: 22.spMin,
              ),
              SizedBox(width: 8.w),
              mdTextBold(text: 'Sales Analytics'),
            ],
          ),
          SizedBox(height: 16.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  'Customers',
                  state.customerCount.toString(),
                  Icons.people_outline,
                  Colors.blue,
                  isDark,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: _buildStatItem(
                  'Total Sold',
                  state.totalSold.toString(),
                  Icons.shopping_cart_outlined,
                  Colors.green,
                  isDark,
                ),
              ),
            ],
          ),
          SizedBox(height: 16.h),
          _buildInfoRow(
            'Total Revenue',
            'Rs ${state.totalRevenue.toStringAsFixed(2)}',
            Icons.account_balance_wallet_outlined,
            Colors.purple,
            isDark,
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(
    String label,
    String value,
    IconData icon,
    Color color,
    bool isDark,
  ) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSizes.md.h,
        vertical: AppSizes.sm.h,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(AppSizes.borderRadiusMd.r),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24.spMin),
          SizedBox(height: 8.h),
          mdTextBold(text: value),
          SizedBox(height: 2.h),
          smText(text: label),
        ],
      ),
    );
  }

  Widget _buildInfoSection(BuildContext context, bool isDark, Color cardColor) {
    final profit =
        product.purchasePrice != null
            ? product.price - product.purchasePrice!
            : null;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSizes.md.h,
        vertical: AppSizes.sm.h,
      ),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Column(
        spacing: 15.h,
        children: [
          if (product.stock != null)
            _buildInfoRow(
              'Stock',
              '${product.stock} units',
              Icons.inventory_2_outlined,
              product.stock! < 10 ? Colors.orange : Colors.green,
              isDark,
            ),
          if (product.purchasePrice != null) ...[
            // Divider(height: 24.h),
            _buildInfoRow(
              'Purchase Price',
              'Rs ${product.purchasePrice!.toStringAsFixed(2)}',
              Icons.shopping_cart_outlined,
              Colors.blue,
              isDark,
            ),
          ],
          if (profit != null) ...[
            // Divider(height: 24.h),
            _buildInfoRow(
              'Profit per Unit',
              'Rs ${profit.toStringAsFixed(2)}',
              Icons.trending_up,
              Colors.green,
              isDark,
            ),
          ],
          if (!product.isService) ...[
            // Divider(height: 24.h),
            _buildInfoRow(
              'Condition',
              product.condition ?? 'New',
              Icons.verified_outlined,
              Colors.purple,
              isDark,
            ),
          ],
          if (!product.isService && product.warranty) ...[
            Divider(height: 24.h),
            _buildInfoRow(
              'Warranty',
              'Available',
              Icons.verified_user_outlined,
              Colors.teal,
              isDark,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoRow(
    String label,
    String value,
    IconData icon,
    Color color,
    bool isDark,
  ) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(10.h),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(10.r),
          ),
          child: Icon(icon, color: color, size: 22.spMin),
        ),
        SizedBox(width: 16.h),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              smTextBold(text: label),
              SizedBox(height: 2.h),
              mdTextBold(text: value),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDetailsSection(
    BuildContext context,
    bool isDark,
    Color cardColor,
  ) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSizes.md.h,
        vertical: AppSizes.sm.h,
      ),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          mdTextBold(text: 'Product Details'),
          SizedBox(height: 10.h),
          _buildDetailRow('Product ID', product.id, isDark),
          SizedBox(height: 12.h),
          _buildDetailRow('Created', _formatDate(product.createdAt), isDark),
          SizedBox(height: 12.h),
          _buildDetailRow(
            'Last Updated',
            _formatDate(product.updatedAt),
            isDark,
          ),
          if (product.isBackup) ...[
            SizedBox(height: 12.h),
            _buildDetailRow('Backup', 'Enabled', isDark),
          ],
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, bool isDark) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [smText(text: label), Flexible(child: smTextBold(text: value))],
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  Widget _buildRelatedProductsSection(
    ProductDetailsState state,
    BuildContext context,
    bool isDark,
    Color cardColor,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'More from ${product.brand ?? "this brand"}',
          style: TextStyle(
            fontSize: 18.spMin,
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black,
          ),
        ),
        SizedBox(height: 16.h),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.75,
            crossAxisSpacing: 12.w,
            mainAxisSpacing: 12.h,
          ),
          itemCount: state.relatedProducts.length,
          itemBuilder: (context, index) {
            final relatedProduct = state.relatedProducts[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) =>
                            ProductDetailsScreen(product: relatedProduct),
                  ),
                );
              },
              child: Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color:
                              isDark
                                  ? Colors.grey.shade800
                                  : Colors.grey.shade100,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(12.r),
                            topRight: Radius.circular(12.r),
                          ),
                        ),
                        child:
                            relatedProduct.imageUrl != null
                                ? ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(12.r),
                                    topRight: Radius.circular(12.r),
                                  ),
                                  child: Image.file(
                                    File(relatedProduct.imageUrl!),
                                    fit: BoxFit.cover,
                                    width: double.infinity,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Center(
                                        child: Icon(
                                          Icons.image_not_supported,
                                          size: 40.spMin,
                                          color: Colors.grey,
                                        ),
                                      );
                                    },
                                  ),
                                )
                                : Center(
                                  child: Icon(
                                    relatedProduct.isService
                                        ? Icons.room_service
                                        : Icons.inventory_2_rounded,
                                    size: 50.spMin,
                                    color: Colors.grey.shade400,
                                  ),
                                ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(10.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            relatedProduct.name,
                            style: TextStyle(
                              fontSize: 14.spMin,
                              fontWeight: FontWeight.w600,
                              color: isDark ? Colors.white : Colors.black,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 6.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Rs ${relatedProduct.price.toStringAsFixed(0)}',
                                style: TextStyle(
                                  fontSize: 16.spMin,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.primary,
                                ),
                              ),
                              if (!relatedProduct.isService &&
                                  relatedProduct.stock != null)
                                Text(
                                  'Stock: ${relatedProduct.stock}',
                                  style: TextStyle(
                                    fontSize: 11.spMin,
                                    color:
                                        relatedProduct.stock! < 10
                                            ? Colors.orange
                                            : Colors.grey,
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
