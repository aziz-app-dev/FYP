// ignore_for_file: use_build_context_synchronously

import 'package:desktopapp/res/components/app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../models/items_model.dart';
import '../../res/components/app_bar_widget.dart';
import '../../view_models/services/database/database_services.dart';
import '../../view_models/providers/product_view.dart';
import '../add_product/add_product_view.dart';
import '../home/rapper.dart';
import 'responsive_views/mobile_details_view.dart';

class ProductDetailsScreen extends ConsumerStatefulWidget {
  final Product product;

  const ProductDetailsScreen({super.key, required this.product});

  @override
  ConsumerState<ProductDetailsScreen> createState() =>
      _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends ConsumerState<ProductDetailsScreen> {
  final DatabaseService _dbService = DatabaseService();

  void _showStockDialog() {
    final TextEditingController controller = TextEditingController();

    showDialog(
      context: context,
      builder:
          (dialogContext) => AlertDialog(
            title: Text('Add Stock', style: TextStyle(fontSize: 18.spMin)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Current Stock: ${widget.product.stock ?? 0} units',
                  style: TextStyle(fontSize: 14.spMin, color: Colors.grey),
                ),
                SizedBox(height: 16.h),
                TextField(
                  controller: controller,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'Quantity to Add',
                    hintText: 'Enter quantity',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    prefixIcon: Icon(Icons.add),
                  ),
                  autofocus: true,
                ),
              ],
            ),
            actions: [
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(dialogContext),
                      child: Text(
                        'Cancel',
                        style: TextStyle(fontSize: 14.spMin),
                      ),
                    ),
                  ),
                  Expanded(
                    child: AppButton().primaryButton(
                      text: 'Add Stock',
                      height: 35.h,
                      onPressed: () async {
                        final quantity = int.tryParse(controller.text);
                        if (quantity == null || quantity <= 0) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Please enter a valid quantity',
                                style: TextStyle(fontSize: 14.spMin),
                              ),
                              backgroundColor: Colors.red,
                            ),
                          );
                          return;
                        }

                        final currentStock = widget.product.stock ?? 0;
                        final updatedProduct = Product(
                          id: widget.product.id,
                          name: widget.product.name,
                          price: widget.product.price,
                          stock: currentStock + quantity,
                          description: widget.product.description,
                          imageUrl: widget.product.imageUrl,
                          isService: widget.product.isService,
                          purchasePrice: widget.product.purchasePrice,
                          isBackup: widget.product.isBackup,
                          createdAt: widget.product.createdAt,
                          updatedAt: DateTime.now(),
                          warranty: widget.product.warranty,
                          condition: widget.product.condition,
                          brand: widget.product.brand,
                          fieldConfigs: widget.product.fieldConfigs,
                        );

                        await _dbService.updateProduct(updatedProduct);

                        // Refresh products in the products provider to update UI across the app
                        ref.read(productsNotifierProvider.notifier).refreshProducts();

                        if (mounted) {
                          Navigator.pop(dialogContext);
                          Navigator.pop(
                            context,
                            true,
                          ); // Return to previous screen
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Stock updated: +$quantity units',
                                style: TextStyle(fontSize: 14.spMin),
                              ),
                              backgroundColor: Colors.green,
                            ),
                          );
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: 'Product Details',
        context: context,
        actions: [
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, size: 22.spMin),
            onSelected: (value) {
              if (value == 'edit') {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) => AddProductScreen(
                          product: widget.product,
                          isService: widget.product.isService,
                        ),
                  ),
                );
              } else if (value == 'stock') {
                _showStockDialog();
              }
            },
            itemBuilder:
                (context) => [
                  PopupMenuItem<String>(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit_outlined, size: 20.spMin),
                        SizedBox(width: 12.w),
                        Text(
                          'Edit Product',
                          style: TextStyle(fontSize: 14.spMin),
                        ),
                      ],
                    ),
                  ),
                  if (!widget.product.isService)
                    PopupMenuItem<String>(
                      value: 'stock',
                      child: Row(
                        children: [
                          Icon(Icons.add_box_outlined, size: 20.spMin),
                          SizedBox(width: 12.w),
                          Text(
                            'Add Stock',
                            style: TextStyle(fontSize: 14.spMin),
                          ),
                        ],
                      ),
                    ),
                ],
          ),
          SizedBox(width: 8.w),
        ],
      ),
      body: ResponsiveWrapper(
        mobile: MobileProductDetailsView(product: widget.product),
        tablet: MobileProductDetailsView(product: widget.product),
        desktop: MobileProductDetailsView(product: widget.product),
      ),
    );
  }
}
