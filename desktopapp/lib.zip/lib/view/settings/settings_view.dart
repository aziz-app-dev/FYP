// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:desktopapp/res/components/app_button.dart';
import 'package:desktopapp/res/components/app_text_widgrt.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';
import 'package:local_auth/local_auth.dart';
import '../../res/components/app_bar_widget.dart';
import '../../view_models/providers/settings_provider.dart';
import 'widget/screens_mangement.dart';

class SettingsPage extends ConsumerWidget {
  final VoidCallback openDrawer;
  const SettingsPage({super.key, required this.openDrawer});

  Future<void> _pickNewDirectory(BuildContext context, WidgetRef ref) async {
    final result = await FilePicker.platform.getDirectoryPath();
    final currentPath = ref.read(settingsProvider).directoryPath;

    if (result != null && result != currentPath) {
      final confirm = await showDialog<bool>(
        context: context,
        builder:
            (ctx) => AlertDialog(
              title: mdText(text: 'Change Directory'),
              content: smText(
                maxLines: 6,
                text:
                    'Changing the directory may cause data loss. Do you want to migrate and continue?',
              ),
              actions: [
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: mdText(text: 'Cancel'),
                      ),
                    ),
                    Expanded(
                      child: AppButton().primaryButton(
                        text: 'Yes, migrate',
                        onPressed: () => Navigator.pop(ctx, true),
                      ),
                    ),
                  ],
                ),
              ],
            ),
      );

      if (confirm == true) {
        await ref.read(settingsProvider.notifier).setDirectoryPath(result);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Directory path updated and data migrated',
              style: TextStyle(fontSize: 14.spMin),
            ),
          ),
        );
      }
    }
  }

  Future<void> _enableAppLock(BuildContext context, WidgetRef ref) async {
    final localAuth = LocalAuthentication();
    final canAuthenticate = await localAuth.canCheckBiometrics;
    bool authenticated = false;

    if (canAuthenticate) {
      try {
        authenticated = await localAuth.authenticate(
          localizedReason: 'Authenticate to enable app lock',
          options: const AuthenticationOptions(
            biometricOnly: false,
            stickyAuth: true,
          ),
        );
      } catch (e) {
        debugPrint('Authentication error: $e');
      }
    } else {
      final TextEditingController pinController = TextEditingController();
      final TextEditingController confirmPinController =
          TextEditingController();
      bool pinsMatch = true;

      authenticated =
          await showDialog<bool>(
            context: context,
            builder:
                (ctx) => StatefulBuilder(
                  builder:
                      (context, setState) => AlertDialog(
                        title: mdTextBold(text: 'Set App Lock PIN'),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextField(
                              controller: pinController,
                              decoration: InputDecoration(
                                labelText: 'Enter PIN (4 digits)',
                                errorText:
                                    pinController.text.length != 4 &&
                                            pinController.text.isNotEmpty
                                        ? 'PIN must be 4 digits'
                                        : null,
                              ),
                              keyboardType: TextInputType.number,
                              maxLength: 4,
                              obscureText: true,
                            ),
                            TextField(
                              controller: confirmPinController,
                              decoration: InputDecoration(
                                labelText: 'Confirm PIN',
                                errorText:
                                    !pinsMatch ? 'PINs do not match' : null,
                              ),
                              keyboardType: TextInputType.number,
                              maxLength: 4,
                              obscureText: true,
                              onChanged: (value) {
                                setState(() {
                                  pinsMatch =
                                      pinController.text ==
                                      confirmPinController.text;
                                });
                              },
                            ),
                          ],
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(ctx, false),
                            child: Text(
                              'Cancel',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              if (pinController.text.length == 4 &&
                                  pinController.text ==
                                      confirmPinController.text) {
                                Navigator.pop(ctx, true);
                              } else {
                                setState(() {
                                  pinsMatch = false;
                                });
                              }
                            },
                            child: Text(
                              'Set PIN',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                          ),
                        ],
                      ),
                ),
          ) ??
          false;
    }

    if (authenticated) {
      ref.read(settingsProvider.notifier).setAppLockEnabled(true);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'App Lock enabled successfully',
            style: TextStyle(fontSize: 14.spMin),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settingsState = ref.watch(settingsProvider);

    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: 'Settings',
        backgroundColor: Colors.white,
        context: context,
        backIcon: TablerIcons.menu_3,
        automaticallyImplyLeading: false,
        leadingOnTap: () {
          openDrawer();
        },
      ),
      body: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: Colors.transparent,
          splashColor: Colors.transparent,
          hoverColor: Colors.transparent,
        ),
        child: ListView(
          padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 16.w),
          children: [
            // General Settings ExpansionTile
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: ExpansionTile(
                initiallyExpanded: false,
                tilePadding: EdgeInsets.symmetric(horizontal: 16.w),
                childrenPadding: EdgeInsets.all(16.h),
                title: mdTextBold(text: 'General Settings'),
                children: [
                  // ✅ Reusable Switch Tile Widget Pattern
                  _smallSwitchTile(
                    context: context,
                    title: 'Enable App Lock',
                    value: settingsState.isAppLockEnabled,
                    onChanged: (val) async {
                      if (val) {
                        await _enableAppLock(context, ref);
                      } else {
                        ref
                            .read(settingsProvider.notifier)
                            .setAppLockEnabled(false);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'App Lock disabled',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                          ),
                        );
                      }
                    },
                  ),
                  _smallSwitchTile(
                    context: context,
                    title: 'Enable Print Bills',
                    subtitle: 'Automatically print bills after sale completion',
                    value: settingsState.isPrintEnabled,
                    onChanged: (val) {
                      ref.read(settingsProvider.notifier).setPrintEnabled(val);
                      if (val) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              settingsState.printFormat == PrintFormat.a4
                                  ? 'Print enabled. PDF bills will be generated and saved after each sale.'
                                  : 'Print enabled. Thermal receipts will be printed after each sale.',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                            duration: const Duration(seconds: 3),
                          ),
                        );
                      }
                    },
                  ),
                  if (settingsState.isPrintEnabled) ...[
                    Padding(
                      padding: EdgeInsets.only(left: 16.w, right: 16.w, bottom: 8.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Print Format',
                            style: TextStyle(
                              fontSize: 14.spMin,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          RadioListTile<PrintFormat>(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            title: Text(
                              'Thermal Print',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                            subtitle: Text(
                              'Directly print thermal receipts after sale',
                              style: TextStyle(fontSize: 12.spMin, color: Colors.grey),
                            ),
                            value: PrintFormat.thermal,
                            groupValue: settingsState.printFormat,
                            onChanged: (val) {
                              if (val != null) {
                                ref.read(settingsProvider.notifier).setPrintFormat(val);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'Thermal print selected. Receipts will be printed directly after each sale.',
                                      style: TextStyle(fontSize: 14.spMin),
                                    ),
                                    duration: const Duration(seconds: 3),
                                  ),
                                );
                              }
                            },
                          ),
                          RadioListTile<PrintFormat>(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            title: Text(
                              'A4 Print (PDF)',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                            subtitle: Text(
                              'Directly save and open PDF bills after sale',
                              style: TextStyle(fontSize: 12.spMin, color: Colors.grey),
                            ),
                            value: PrintFormat.a4,
                            groupValue: settingsState.printFormat,
                            onChanged: (val) {
                              if (val != null) {
                                ref.read(settingsProvider.notifier).setPrintFormat(val);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'A4 Print selected. PDF bills will be saved and opened after each sale.',
                                      style: TextStyle(fontSize: 14.spMin),
                                    ),
                                    duration: const Duration(seconds: 3),
                                  ),
                                );
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 8.h),
                  ],
                  _smallSwitchTile(
                    context: context,
                    title: 'By Default Bills Paid',
                    value: settingsState.isPaid,
                    onChanged: (val) {
                      ref.read(settingsProvider.notifier).setIsPaid(val);
                    },
                  ),
                  _smallSwitchTile(
                    context: context,
                    title: 'Enable Multi-Cart Mode',
                    subtitle: 'Manage multiple customer carts simultaneously',
                    value: settingsState.useMultiCart,
                    onChanged: (val) {
                      ref.read(settingsProvider.notifier).setUseMultiCart(val);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            val
                                ? 'Multi-cart mode enabled. Restart sales screen to apply.'
                                : 'Single cart mode enabled.',
                            style: TextStyle(fontSize: 14.spMin),
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.h),
            // Theme Settings ExpansionTile
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: ExpansionTile(
                initiallyExpanded: false,
                tilePadding: EdgeInsets.symmetric(horizontal: 16.w),
                childrenPadding: EdgeInsets.all(16.h),
                title: mdTextBold(text: 'Theme'),

                children: [
                  RadioListTile<ThemeMode>(
                    title: smText(text: 'Light'),
                    value: ThemeMode.light,
                    groupValue: settingsState.themeMode,
                    onChanged: (value) {
                      if (value != null) {
                        ref.read(settingsProvider.notifier).setThemeMode(value);
                      }
                    },
                    contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                  ),
                  RadioListTile<ThemeMode>(
                    title: smText(text: 'Dark'),
                    value: ThemeMode.dark,
                    groupValue: settingsState.themeMode,
                    onChanged: (value) {
                      if (value != null) {
                        ref.read(settingsProvider.notifier).setThemeMode(value);
                      }
                    },
                    contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                  ),
                  RadioListTile<ThemeMode>(
                    title: smText(text: 'system'),
                    value: ThemeMode.system,
                    groupValue: settingsState.themeMode,
                    onChanged: (value) {
                      if (value != null) {
                        ref.read(settingsProvider.notifier).setThemeMode(value);
                      }
                    },
                    contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.h),
            // Paths ExpansionTile
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: ExpansionTile(
                initiallyExpanded: false,
                tilePadding: EdgeInsets.symmetric(horizontal: 16.w),
                childrenPadding: EdgeInsets.all(16.h),
                title: mdTextBold(text: 'Paths'),
                children: [
                  ListTile(
                    title: smText(text: 'Current Directory Path'),
                    subtitle: smText(
                      text:
                          settingsState.directoryPath.isEmpty
                              ? 'Not set'
                              : settingsState.directoryPath,
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.edit, size: 20.spMin),
                      onPressed: () => _pickNewDirectory(context, ref),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.h),
            // Screen Management ExpansionTile
            ScreenManagementSection(ref: ref),
            SizedBox(height: 16.h),
            // Desktop Side Bar ExpansionTile
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: ExpansionTile(
                initiallyExpanded: false,
                tilePadding: EdgeInsets.symmetric(horizontal: 16.w),
                childrenPadding: EdgeInsets.all(16.h),
                title: mdTextBold(text: 'Desktop Side Bar'),
                children: [
                  CheckboxListTile(
                    title: smText(text: 'Show User Card'),
                    value: settingsState.isShowUserCard,
                    onChanged: (val) {
                      ref.read(settingsProvider.notifier).setShowUserCard(val!);
                    },
                    contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                    controlAffinity: ListTileControlAffinity.leading,
                  ),
                  AnimatedCrossFade(
                    duration: const Duration(milliseconds: 300),
                    crossFadeState:
                        settingsState.isShowUserCard
                            ? CrossFadeState.showSecond
                            : CrossFadeState.showFirst,
                    firstChild: const SizedBox.shrink(),
                    secondChild: Column(
                      children: [
                        CheckboxListTile(
                          title: smText(text: 'Show Tagline'),
                          value: settingsState.isShowTagLine,
                          onChanged: (val) {
                            ref
                                .read(settingsProvider.notifier)
                                .setShowTagLine(val!);
                          },
                          contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                          controlAffinity: ListTileControlAffinity.leading,
                        ),
                        CheckboxListTile(
                          title: smText(
                            text: 'Show Tagline Instead of CEO Name',
                          ),
                          value: settingsState.isTagLineInsteadOfCEOName,
                          onChanged: (val) {
                            ref
                                .read(settingsProvider.notifier)
                                .setTagLineInsteadOfCEOName(val!);
                          },
                          contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                          controlAffinity: ListTileControlAffinity.leading,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.h),
            // Elevations ExpansionTile
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: ExpansionTile(
                initiallyExpanded: false,
                tilePadding: EdgeInsets.symmetric(horizontal: 16.w),
                childrenPadding: EdgeInsets.all(16.h),
                title: mdTextBold(text: 'Elevations'),
                children: [
                  ListTile(
                    title: smTextBold(text: 'Card Elevation'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Slider(
                          value: settingsState.cardElevation,
                          min: 0.0,
                          max: 10.0,
                          divisions: 20,
                          label: settingsState.cardElevation.toStringAsFixed(1),
                          onChanged: (value) {
                            ref
                                .read(settingsProvider.notifier)
                                .setCardElevation(value);
                          },
                        ),
                        smText(
                          text:
                              'Elevation: ${settingsState.cardElevation.toStringAsFixed(1)}',
                        ),
                      ],
                    ),
                    contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                  ),
                  ListTile(
                    title: smTextBold(text: 'AppBar Elevation'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Slider(
                          value: settingsState.appBarElevation,
                          min: 0.0,
                          max: 10.0,
                          divisions: 20,
                          label: settingsState.appBarElevation.toStringAsFixed(
                            1,
                          ),
                          onChanged: (value) {
                            ref
                                .read(settingsProvider.notifier)
                                .setAppBarElevation(value);
                          },
                        ),
                        smText(
                          text:
                              'Elevation: ${settingsState.appBarElevation.toStringAsFixed(1)}',
                        ),
                      ],
                    ),
                    contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                  ),
                  ListTile(
                    title: smTextBold(text: 'Product Card Elevation'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Slider(
                          value: settingsState.productCardElevation,
                          min: 0.0,
                          max: 10.0,
                          divisions: 20,
                          label: settingsState.productCardElevation
                              .toStringAsFixed(1),
                          onChanged: (value) {
                            ref
                                .read(settingsProvider.notifier)
                                .setProductCardElevation(value);
                          },
                        ),
                        smText(
                          text:
                              'Elevation: ${settingsState.productCardElevation.toStringAsFixed(1)}',
                        ),
                      ],
                    ),
                    contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _smallSwitchTile({
    required BuildContext context,
    required String title,
    String? subtitle,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 12.spMin,
          color:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
        ),
      ),
      subtitle:
          subtitle != null
              ? Text(
                subtitle,
                style: TextStyle(fontSize: 10.spMin, color: Colors.grey),
              )
              : null,
      trailing: Transform.scale(
        scale: 0.8.spMin,
        child: Switch(
          value: value,
          onChanged: onChanged,
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
      ),
      onTap: () => onChanged(!value),
    );
  }
}
