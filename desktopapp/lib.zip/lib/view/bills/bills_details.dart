// ignore_for_file: use_build_context_synchronously

import 'dart:io';
import 'dart:typed_data';
import 'package:data_table_2/data_table_2.dart';
import 'package:desktopapp/res/colors/app_color.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';
import 'package:intl/intl.dart';
import 'package:local_auth/local_auth.dart';
import 'package:open_file/open_file.dart';
import 'package:thermal_printer/thermal_printer.dart';
import '../../models/bills_model.dart';
import '../../res/components/app_bar_widget.dart';
import '../../res/components/app_text_widgrt.dart';
import '../../view_models/providers/bills_provider.dart';
import '../../view_models/providers/profile_provider.dart';
import '../../view_models/services/database/database_services.dart';
import '../home/rapper.dart';
import 'edit_bill.dart';
import 'widgets/pdf_genrater_widget.dart';
import 'widgets/thermal_print_wodget.dart';

import '../../view_models/providers/add_prduct_provider.dart';
import '../../view_models/providers/bill_detail_provider.dart';

class BillDetailScreen extends ConsumerStatefulWidget {
  final Bill bill;

  const BillDetailScreen({super.key, required this.bill});

  @override
  BillDetailScreenState createState() => BillDetailScreenState();
}

class BillDetailScreenState extends ConsumerState<BillDetailScreen> {
  late ThermalReceiptPrinter thermalPrinter;
  late HiveService _hiveService;

  Future<void> _initializeSettings() async {
    await _hiveService.init();
    await _loadCustomer();
  }

  Future<void> _loadCustomer() async {
    await ref.read(billDetailProvider(widget.bill).notifier).loadCustomer();
  }

  @override
  void initState() {
    super.initState();
    _hiveService = HiveService();
    _initializeSettings();
    _loadDefaultLogo();

    thermalPrinter = ThermalReceiptPrinter(bill: widget.bill, context: context);

    // Delay provider modification until after the widget tree is built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scanForPrinters();
    });
  }

  Future<void> _loadDefaultLogo() async {
    try {
      // Logo loading logic if needed
    } catch (e) {
      // Proceed without logo
    }
  }

  void _scanForPrinters() {
    final notifier = ref.read(billDetailProvider(widget.bill).notifier);
    notifier.clearDevices();
    thermalPrinter.scanForPrinters().listen((device) {
      if (mounted) {
        notifier.addDevice(device);
      }
    });
  }

  Future<void> _generateAndSavePDF(Bill bill, String shopName) async {
    // Load user profile data from database
    final dbService = ref.read(databaseServiceProvider);
    final users = await dbService.getUsers();

    Uint8List? shopLogo;
    String? ownerName;
    String? phoneNumber;
    String? tagline;
    String? bankName;
    String? accountNumber;
    Uint8List? bankQrCode;

    if (users.isNotEmpty) {
      final user = users.first;
      ownerName = user.ownerName;
      phoneNumber = user.phoneNumber;
      tagline = user.shopTagline;

      // Load shop logo if exists
      if (user.shopLogoPath != null && user.shopLogoPath!.isNotEmpty) {
        final logoFile = File(user.shopLogoPath!);
        if (await logoFile.exists()) {
          shopLogo = await logoFile.readAsBytes();
        }
      }

      // Load first bank details if available
      if (user.bankDetails.isNotEmpty) {
        final firstBank = user.bankDetails.first;
        bankName = firstBank.bankName;
        accountNumber = firstBank.accountNumber;

        // Load bank QR code if exists
        if (firstBank.qrCodePath != null && firstBank.qrCodePath!.isNotEmpty) {
          final qrFile = File(firstBank.qrCodePath!);
          if (await qrFile.exists()) {
            bankQrCode = await qrFile.readAsBytes();
          }
        }
      }
    }

    final pdfGenerator = ReceiptPDFGenerator(
      bill: bill,
      shopName: shopName,
      shopLogo: shopLogo,
      ownerName: ownerName,
      phoneNumber: phoneNumber,
      tagline: tagline,
      bankName: bankName,
      accountNumber: accountNumber,
      bankQrCode: bankQrCode,
    );
    final pdf = pdfGenerator.generatePDF();

    final directoryPath = await HiveService().directoryPath;
    final directory = Directory('$directoryPath/invoices');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    final file = File(
      '$directoryPath/invoices/invoice_${bill.id.substring(0, 8)}.pdf',
    );
    await file.writeAsBytes(await pdf.save());
    await OpenFile.open(file.path);
  }

  Future<void> _printThermal() async {
    final notifier = ref.read(billDetailProvider(widget.bill).notifier);
    final state = ref.read(billDetailProvider(widget.bill));

    notifier.setPrintingStatus(true);
    try {
      await thermalPrinter.printThermal(state.selectedPrinter, () {
        if (mounted) notifier.setPrintingStatus(false);
      });
    } catch (e) {
      if (mounted) notifier.setPrintingStatus(false);
    }
  }

  Future<void> _deleteBill() async {
    await ref.read(databaseServiceProvider).deleteBill(widget.bill.id);
    if (mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        ref.read(billsProvider.notifier).fetchBills();
      });
      Navigator.pop(context);
    }
  }

  Future<void> _showPrinterSelectionDialog() async {
    final state = ref.read(billDetailProvider(widget.bill));
    final selected = await showDialog<PrinterDevice>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: mdTextBold(text: 'Select Thermal Printer'),
            content: Container(
              width: double.maxFinite,
              constraints: BoxConstraints(maxHeight: 300.h),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: state.devices.length,
                itemBuilder: (context, index) {
                  final device = state.devices[index];
                  return ListTile(
                    title: smText(text: device.name),
                    onTap: () => Navigator.pop(context, device),
                  );
                },
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: smText(text: 'Cancel'),
              ),
            ],
          ),
    );
    if (selected != null && mounted) {
      ref
          .read(billDetailProvider(widget.bill).notifier)
          .setSelectedPrinter(selected);
    }
  }

  // Function to handle biometric authentication
  Future<bool> _authenticate(BuildContext context) async {
    final localAuth = LocalAuthentication();
    final canAuthenticate = await localAuth.canCheckBiometrics;
    bool authenticated = false;

    if (canAuthenticate) {
      try {
        authenticated = await localAuth.authenticate(
          localizedReason: 'Authenticate to edit or delete the bill',
          options: const AuthenticationOptions(
            biometricOnly: false,
            stickyAuth: true,
          ),
        );
      } catch (e) {
        debugPrint('Authentication error: $e');
      }
    } else {
      // Fallback to PIN
      final TextEditingController pinController = TextEditingController();
      bool isPinCorrect = true;

      authenticated =
          await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder:
                (ctx) => StatefulBuilder(
                  builder:
                      (context, setState) => AlertDialog(
                        title: Text(
                          'Enter PIN to Authenticate',
                          style: TextStyle(fontSize: 18.spMin),
                        ),
                        content: TextField(
                          controller: pinController,
                          decoration: InputDecoration(
                            labelText: 'Enter PIN (4 digits)',
                            errorText: !isPinCorrect ? 'Incorrect PIN' : null,
                          ),
                          keyboardType: TextInputType.number,
                          maxLength: 4,
                          obscureText: true,
                        ),
                        actions: [
                          ElevatedButton(
                            onPressed: () {
                              if (pinController.text == '1234') {
                                Navigator.pop(ctx, true);
                              } else {
                                setState(() {
                                  isPinCorrect = false;
                                });
                              }
                            },
                            child: Text(
                              'Unlock',
                              style: TextStyle(fontSize: 14.spMin),
                            ),
                          ),
                        ],
                      ),
                ),
          ) ??
          false;
    }

    return authenticated;
  }

  Widget _buildHeader() {
    final state = ref.watch(billDetailProvider(widget.bill));

    return Card(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8.w, horizontal: 12.w),
        child: Column(
          spacing: 6.h,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            mdTextBold(text: 'General Information'),
            SizedBox(height: 3.h),
            MainTxtRow(val: widget.bill.id, txt: 'Bill ID:'),
            MainTxtRow(
              val: DateFormat('dd/MM/yyyy HH:mm').format(widget.bill.dateTime),
              txt: 'Date:',
            ),
            MainTxtRow(
              val: widget.bill.customerName ?? "Walk-in",
              txt: 'Name:',
            ),
            MainTxtRow(val: state.customer?.phoneNumber ?? "", txt: 'Phone:'),
            MainTxtRow(val: state.customer?.address ?? "", txt: 'Address:'),
          ],
        ),
      ),
    );
  }

  Widget _buildBillingSummary() {
    final discount = widget.bill.discount;
    final totalAfterDiscount = widget.bill.totalAmount - discount;
    final paidAmount = widget.bill.paidAmount;
    final pendingAmount =
        totalAfterDiscount - paidAmount > 0
            ? totalAfterDiscount - paidAmount
            : 0.0;

    return Card(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8.w, horizontal: 12.w),
        child: Column(
          spacing: 6.h,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            mdTextBold(text: 'Billing Summary'),
            SizedBox(height: 3.h),
            MainTxtRow(
              val: totalAfterDiscount.toStringAsFixed(2),
              txt: 'Total:',
            ),
            MainTxtRow(val: paidAmount.toStringAsFixed(2), txt: 'Paid Amount:'),
            MainTxtRow(
              valWidget: mdTextBold(
                text: '\$${pendingAmount.toStringAsFixed(2)}',
                color: pendingAmount > 0 ? Colors.orange : Colors.green,
              ),
              txt: 'Pending Amount:',
            ),
            MainTxtRow(
              valWidget: Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color:
                      widget.bill.status == 'Paid'
                          ? Colors.green.withValues(alpha: 0.1)
                          : widget.bill.status == 'Pending'
                          ? Colors.orange.withValues(alpha: 0.1)
                          : Colors.red.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(4.r),
                ),
                child: mdText(
                  text: widget.bill.status,
                  color:
                      widget.bill.status == 'Paid'
                          ? Colors.green
                          : widget.bill.status == 'Pending'
                          ? Colors.orange
                          : Colors.red,
                ),
              ),
              txt: 'Status:',
            ),
            if (widget.bill.paymentMethod != null) ...[
              MainTxtRow(
                val: widget.bill.paymentMethod!,
                txt: 'Payment Method:',
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDataTable2() {
    final discount = widget.bill.discount;
    final totalAfterDiscount = widget.bill.totalAmount - discount;
    final totalRows = widget.bill.items.length + 5;

    return Card(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8.w, horizontal: 12.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            mdTextBold(text: 'Items'),
            SizedBox(height: 15.h),
            SizedBox(
              height: totalRows * 43.8.h,
              child: DataTable2(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(8.r),
                    topRight: Radius.circular(8.r),
                  ),
                  border: Border.all(color: Colors.grey),
                ),
                headingRowDecoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(6.r),
                    topRight: Radius.circular(9.r),
                  ),
                ),
                columnSpacing: 2.w,
                horizontalMargin: 5.w,
                dividerThickness: 0,
                headingRowColor: WidgetStateProperty.all(
                  (Theme.of(context).brightness == Brightness.dark
                      ? AppColors.primary.withValues(alpha: 0.4)
                      : AppColors.primary),
                ),
                headingTextStyle: TextStyle(
                  fontSize: 12.spMin,
                  fontWeight: FontWeight.bold,
                ),
                dataTextStyle: TextStyle(
                  fontSize: 12.spMin,
                  color:
                      (Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black),
                ),
                columns: [
                  DataColumn2(
                    label: smTextBold(text: 'Name'),
                    size: ColumnSize.M,
                  ),
                  DataColumn2(
                    label: smTextBold(text: 'Qty'),
                    size: ColumnSize.S,
                    numeric: true,
                  ),
                  DataColumn2(
                    label: smTextBold(text: 'Unit Price'),
                    size: ColumnSize.S,
                    numeric: true,
                  ),
                  DataColumn2(
                    label: smTextBold(text: 'Total'),
                    size: ColumnSize.S,
                    numeric: true,
                  ),
                ],
                rows: [
                  ...widget.bill.items.map((item) {
                    final qty = widget.bill.quantities[item.id] ?? 1;
                    final itemTotal = item.price * qty;
                    return DataRow2(
                      cells: [
                        DataCell(smText(text: item.name)),
                        DataCell(smText(text: qty.toString())),
                        DataCell(
                          smText(text: '\$${item.price.toStringAsFixed(2)}'),
                        ),
                        DataCell(
                          smText(text: '\$${itemTotal.toStringAsFixed(2)}'),
                        ),
                      ],
                    );
                  }),
                  DataRow2(
                    color: WidgetStateProperty.all(Colors.transparent),
                    cells: [
                      DataCell(Container()),
                      DataCell(Container()),
                      DataCell(Container()),
                      DataCell(Container()),
                    ],
                  ),
                  DataRow2(
                    decoration: BoxDecoration(
                      color:
                          (Theme.of(context).brightness == Brightness.dark
                              ? AppColors.dScafoldColor
                              : AppColors.lScafoldColor),
                      // borderRadius: BorderRadius.only(
                      //   topLeft: Radius.circular(10),
                      //   topRight: Radius.circular(10),
                      // ),
                    ),
                    color: WidgetStateProperty.all(
                      (Theme.of(context).brightness == Brightness.dark
                          ? AppColors.dScafoldColor
                          : AppColors.lScafoldColor),
                    ),
                    cells: [
                      DataCell(smTextBold(text: 'Subtotal')),
                      DataCell(smText(text: '')),
                      DataCell(smText(text: '')),
                      DataCell(
                        smTextBold(
                          text:
                              '\$${widget.bill.totalAmount.toStringAsFixed(2)}',
                        ),
                      ),
                    ],
                  ),
                  if (discount > 0)
                    DataRow2(
                      decoration: BoxDecoration(
                        color:
                            (Theme.of(context).brightness == Brightness.dark
                                ? AppColors.dScafoldColor
                                : AppColors.lScafoldColor),
                      ),
                      color: WidgetStateProperty.all(
                        (Theme.of(context).brightness == Brightness.dark
                            ? AppColors.dScafoldColor
                            : AppColors.lScafoldColor),
                      ),
                      cells: [
                        DataCell(smText(text: 'Discount')),
                        DataCell(smText(text: '')),
                        DataCell(smText(text: '')),
                        DataCell(
                          smText(text: '\$${discount.toStringAsFixed(2)}'),
                        ),
                      ],
                    ),
                  DataRow2(
                    color: WidgetStateProperty.all(Colors.transparent),
                    cells: [
                      DataCell(Container()),
                      DataCell(Container()),
                      DataCell(Container()),
                      DataCell(Container()),
                    ],
                  ),
                  DataRow2(
                    decoration: BoxDecoration(
                      color:
                          (Theme.of(context).brightness == Brightness.dark
                              ? AppColors.dScafoldColor
                              : AppColors.lScafoldColor),
                    ),
                    color: WidgetStateProperty.all(
                      (Theme.of(context).brightness == Brightness.dark
                          ? AppColors.dScafoldColor
                          : AppColors.lScafoldColor),
                    ),
                    cells: [
                      DataCell(mdTextBold(text: 'Total')),
                      DataCell(smText(text: '')),
                      DataCell(smText(text: '')),
                      DataCell(
                        mdTextBold(
                          text: '\$${totalAfterDiscount.toStringAsFixed(2)}',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileView() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildHeader(),
          SizedBox(height: 16.h),
          _buildBillingSummary(),
          SizedBox(height: 16.h),
          _buildDataTable2(),
        ],
      ),
    );
  }

  Widget _buildDesktopView() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 32.w, vertical: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: _buildHeader()),
              SizedBox(width: 16.w),
              Expanded(child: _buildBillingSummary()),
            ],
          ),
          SizedBox(height: 16.h),
          _buildDataTable2(),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final profileState = ref.read(profileProvider);
    final shopName = profileState.shopName ?? 'Your Shop';
    final detailState = ref.watch(billDetailProvider(widget.bill));

    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: 'Bill #${widget.bill.id}',
        context: context,
        actions: [
          DropdownButton<String>(
            focusColor: Colors.transparent,
            icon: Icon(Icons.more_vert, size: 20.spMin),
            underline: SizedBox(),
            items: [
              DropdownMenuItem<String>(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit, size: 16.spMin),
                    SizedBox(width: 8.w),
                    smText(text: 'Edit Bill'),
                  ],
                ),
              ),
              DropdownMenuItem<String>(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, size: 16.spMin, color: Colors.red),
                    SizedBox(width: 8.w),
                    smText(text: 'Delete Bill', color: Colors.red),
                  ],
                ),
              ),
              DropdownMenuItem<String>(
                value: 'save_pdf',
                child: Row(
                  children: [
                    Icon(Icons.picture_as_pdf, size: 16.spMin),
                    SizedBox(width: 8.w),
                    smText(text: 'Save as PDF'),
                  ],
                ),
              ),
              DropdownMenuItem<String>(
                value: 'select_printer',
                child: Row(
                  children: [
                    Icon(Icons.print, size: 16.spMin),
                    SizedBox(width: 8.w),
                    smText(text: 'Select Thermal Printer'),
                  ],
                ),
              ),
              if (detailState.selectedPrinter != null)
                DropdownMenuItem<String>(
                  value: 'print_thermal',
                  enabled: !detailState.isPrintingThermal,
                  child: Row(
                    children: [
                      Icon(Icons.receipt, size: 16.spMin),
                      SizedBox(width: 8.w),
                      smText(
                        text:
                            detailState.isPrintingThermal
                                ? 'Printing...'
                                : 'Print Thermal',
                      ),
                    ],
                  ),
                ),
            ],
            onChanged: (value) async {
              if (value == 'edit') {
                // Require biometric authentication for editing
                final authenticated = await _authenticate(context);
                if (authenticated) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => EditBillScreen(bill: widget.bill),
                    ),
                  );
                }
              } else if (value == 'delete') {
                // Require biometric authentication for deleting
                final authenticated = await _authenticate(context);
                if (authenticated) {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder:
                        (context) => AlertDialog(
                          title: mdTextBold(text: 'Delete Bill'),
                          content: mdText(
                            text: 'Are you sure you want to delete this bill?',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, false),
                              child: smText(text: 'Cancel'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(context, true),
                              child: smText(text: 'Delete', color: Colors.red),
                            ),
                          ],
                        ),
                  );
                  if (confirm == true) {
                    await _deleteBill();
                  }
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Authentication failed')),
                  );
                }
              } else if (value == 'save_pdf') {
                await _generateAndSavePDF(widget.bill, shopName);
              } else if (value == 'select_printer') {
                await _showPrinterSelectionDialog();
              } else if (value == 'print_thermal') {
                await _printThermal();
              }
            },
          ),
        ],
      ),
      body: ResponsiveWrapper(
        mobile: _buildMobileView(),
        tablet: _buildMobileView(),
        desktop: _buildDesktopView(),
      ),
    );
  }
}

class TxtRow extends StatelessWidget {
  const TxtRow({super.key, required this.txt});

  final String txt;

  @override
  Widget build(BuildContext context) {
    return Row(
      spacing: 2.w,
      children: [
        Icon(TablerIcons.point_filled, size: 18.spMin),
        mdText(text: txt),
      ],
    );
  }
}

class MainTxtRow extends StatelessWidget {
  const MainTxtRow({super.key, required this.txt, this.val, this.valWidget});

  final String txt;
  final String? val;
  final Widget? valWidget;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      spacing: 2.w,
      children: [TxtRow(txt: txt), valWidget ?? mdTextBold(text: val ?? "")],
    );
  }
}
