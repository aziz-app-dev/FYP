import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../models/bills_model.dart';

class ReceiptPDFGenerator {
  final Bill bill;
  final String shopName;
  final Uint8List? shopLogo;
  final String? ownerName;
  final String? phoneNumber;
  final String? tagline;
  final String? bankName;
  final String? accountNumber;
  final Uint8List? bankQrCode;

  ReceiptPDFGenerator({
    required this.bill,
    required this.shopName,
    this.shopLogo,
    this.ownerName,
    this.phoneNumber,
    this.tagline,
    this.bankName,
    this.accountNumber,
    this.bankQrCode,
  });

  pw.Document generatePDF() {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.roll80,
        build: (pw.Context context) => _buildPDFContent(),
      ),
    );

    return pdf;
  }

  pw.Widget _buildPDFContent() {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      mainAxisAlignment: pw.MainAxisAlignment.start,
      children: [
        pw.Row(
          children: [
            if (shopLogo != null)
              pw.Center(child: pw.Image(pw.MemoryImage(shopLogo!), width: 36)),
            pw.SizedBox(width: 10),
            pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                // Shop Name
                pw.Center(
                  child: pw.Text(
                    shopName,
                    style: pw.TextStyle(
                      fontSize: 10,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),

                // Owner Name
                if (ownerName != null && ownerName!.isNotEmpty)
                  pw.Center(
                    child: pw.Text(
                      ownerName!,
                      style: pw.TextStyle(
                        fontSize: 8,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                  ),

                // Phone Number
                if (phoneNumber != null && phoneNumber!.isNotEmpty)
                  pw.Center(
                    child: pw.Text(
                      'Phone: $phoneNumber',
                      style: const pw.TextStyle(fontSize: 7),
                    ),
                  ),
              ],
            ),
          ],
        ),

        pw.SizedBox(height: 3),
        pw.Text('-----------------------------------------------'),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
              "Date: ${DateFormat('dd/MM/yyyy').format(bill.dateTime)}",
              style: const pw.TextStyle(fontSize: 7),
            ),
            pw.Center(
              child: pw.Text(
                "Invoice #${bill.id.substring(0, 8)}",
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 6,
                ),
              ),
            ),
          ],
        ),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            if (bill.customerName != null)
              pw.Text(
                "Customer: ${bill.customerName}",
                style: const pw.TextStyle(fontSize: 7),
              ),
            pw.Text(
              "Payment Status:${bill.status}",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 6),
            ),
          ],
        ),
        pw.Divider(),
        pw.Row(
          children: [
            pw.Expanded(
              flex: 2,
              child: pw.Text(
                "Item",
                maxLines: 2,
                overflow: pw.TextOverflow.clip,
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 8,
                ),
              ),
            ),
            pw.SizedBox(
              width: 30,
              child: pw.Text(
                "Price",
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 8,
                ),
                textAlign: pw.TextAlign.right,
              ),
            ),
            pw.SizedBox(width: 5),
            pw.SizedBox(
              width: 30,
              child: pw.Text(
                "Qty",
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 8,
                ),
                textAlign: pw.TextAlign.center,
              ),
            ),
            pw.SizedBox(width: 5),
            pw.SizedBox(
              width: 35,
              child: pw.Text(
                "Total",
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 8,
                ),
                textAlign: pw.TextAlign.right,
              ),
            ),
          ],
        ),
        pw.Divider(),
        ...bill.items.map((item) {
          final qty = bill.quantities[item.id] ?? 1;
          final total = item.price * qty;
          return pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 4),
            child: pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Expanded(
                  flex: 1,
                  child: pw.Text(
                    item.name,

                    style: const pw.TextStyle(fontSize: 7),
                    maxLines: 2,
                    overflow: pw.TextOverflow.clip,
                  ),
                ),
                pw.SizedBox(
                  width: 30,
                  child: pw.Text(
                    "Rs.${item.price.toStringAsFixed(0)}",
                    style: const pw.TextStyle(fontSize: 7),
                    textAlign: pw.TextAlign.right,
                  ),
                ),
                pw.SizedBox(width: 5),
                pw.SizedBox(
                  width: 30,
                  child: pw.Text(
                    qty.toStringAsFixed(0),
                    style: const pw.TextStyle(fontSize: 7),
                    textAlign: pw.TextAlign.center,
                  ),
                ),
                pw.SizedBox(width: 5),
                pw.SizedBox(
                  width: 30,
                  child: pw.Text(
                    "Rs.${total.toStringAsFixed(0)}",
                    style: const pw.TextStyle(fontSize: 7),
                    textAlign: pw.TextAlign.right,
                  ),
                ),
              ],
            ),
          );
        }),
        pw.Divider(borderStyle: pw.BorderStyle.dashed),

        // Subtotal
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text("Subtotal:", style: const pw.TextStyle(fontSize: 8)),
            pw.Text(
              "Rs.${bill.totalAmount.toStringAsFixed(2)}",
              style: const pw.TextStyle(fontSize: 8),
            ),
          ],
        ),

        // Discount (if any)
        if (bill.discount > 0) ...[
          pw.SizedBox(height: 4),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text("Discount:", style: const pw.TextStyle(fontSize: 7)),
              pw.Text(
                "- Rs.${bill.discount.toStringAsFixed(2)}",
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 8,
                ),
              ),
            ],
          ),
        ],

        pw.Divider(borderStyle: pw.BorderStyle.dashed),

        // Total (Subtotal - Discount) - using computed property
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text("Total:", style: pw.TextStyle(fontSize: 7)),
            pw.Text(
              "Rs.${bill.totalAfterDiscount.toStringAsFixed(2)}",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 8),
            ),
          ],
        ),

        // Paid Amount (only if user paid something)
        if (bill.paidAmount > 0) ...[
          pw.SizedBox(height: 4),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(
                "Pay  ${bill.paymentMethod != null ? '${bill.paymentMethod}' : ''}",
                style: const pw.TextStyle(fontSize: 7),
              ),
              pw.Text(
                "Rs.${bill.paidAmount.toStringAsFixed(2)}",
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 8,
                ),
              ),
            ],
          ),
        ],

        // // Payment Progress (if partial payment)
        // if (bill.isPartialPayment) ...[
        //   pw.SizedBox(height: 4),
        //   pw.Row(
        //     mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        //     children: [
        //       pw.Text("Payment Progress:", style: const pw.TextStyle(fontSize: 8)),
        //       pw.Text(
        //         "${bill.paymentPercentage.toStringAsFixed(1)}%",
        //         style: pw.TextStyle(
        //           fontSize: 8,
        //           color: PdfColors.orange,
        //         ),
        //       ),
        //     ],
        //   ),
        // ],

        // Amount Due/Pending - using computed property
        if (bill.pendingAmount > 0) ...[
          pw.Divider(borderStyle: pw.BorderStyle.dashed),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: pw.BoxDecoration(
              color: PdfColors.red50,
              borderRadius: pw.BorderRadius.circular(4),
            ),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text(
                  "Amount Due:",
                  style: pw.TextStyle(
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColors.red,
                  ),
                ),
                pw.Text(
                  "Rs.${bill.pendingAmount.toStringAsFixed(2)}",
                  style: pw.TextStyle(
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColors.red,
                  ),
                ),
              ],
            ),
          ),
        ],

        pw.SizedBox(height: 4),

        pw.Divider(),

        // Tagline or default thank you message
        if (tagline != null && tagline!.isNotEmpty)
          pw.Center(
            child: pw.Text(
              tagline!,
              style: const pw.TextStyle(fontSize: 7),
              textAlign: pw.TextAlign.center,
            ),
          )
        else
          pw.Center(
            child: pw.Text(
              "Thank you for your business!",
              style: const pw.TextStyle(fontSize: 7),
            ),
          ),

        // Bank Details Section
        if (bankName != null ||
            accountNumber != null ||
            bankQrCode != null) ...[
          pw.Divider(),
          pw.Center(
            child: pw.Text(
              "Bank Details",
              style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.SizedBox(height: 2),

          // Account Number
          if (accountNumber != null && accountNumber!.isNotEmpty)
            pw.Center(
              child: pw.Text(
                "$bankName Account: $accountNumber",
                style: const pw.TextStyle(fontSize: 9),
              ),
            ),

          // Bank QR Code
          if (bankQrCode != null) ...[
            pw.SizedBox(height: 5),
            pw.Center(
              child: pw.Text(
                "Scan to pay",
                style: const pw.TextStyle(fontSize: 7),
              ),
            ),
            pw.SizedBox(height: 5),
            pw.Center(
              child: pw.Image(
                pw.MemoryImage(bankQrCode!),
                width: 70,
                height: 70,
              ),
            ),
          ],
        ],
      ],
    );
  }
}
