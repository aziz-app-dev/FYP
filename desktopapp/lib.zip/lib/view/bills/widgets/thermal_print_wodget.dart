import 'package:flutter/material.dart';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:thermal_printer/thermal_printer.dart';
import '../../../models/bills_model.dart';
import 'recipt_genrater.dart';

class ThermalReceiptPrinter {
  final PrinterManager printerManager = PrinterManager.instance;
  final Bill bill;
  // final String shopName;
  // final Uint8List? shopLogo;
  // final String paymentQrData;
  final BuildContext context;

  ThermalReceiptPrinter({
    required this.bill,
    // required this.shopName,
    required this.context,
    // this.shopLogo,
    // required this.paymentQrData,
  });

  Future<void> printThermal(
    PrinterDevice? selectedPrinter,
    VoidCallback setPrintingState,
  ) async {
    if (selectedPrinter == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Please select a printer")));
      return;
    }

    setPrintingState(); // Start printing state
    try {
      await printerManager.connect(
        type: PrinterType.usb,
        model: UsbPrinterInput(
          name: selectedPrinter.name,
          vendorId: selectedPrinter.vendorId,
          productId: selectedPrinter.productId,
        ),
      );

      final receiptGenerator = ReceiptGenerator(
        bill: bill,
        // shopName: shopName,
        // shopLogo: shopLogo,
        // paymentQrData: paymentQrData,
      );

      const PaperSize paper = PaperSize.mm80;
      final profile = await CapabilityProfile.load();
      final Generator generator = Generator(paper, profile);
      List<int> bytes = [];

      // Print receipt content
      for (var item in receiptGenerator.getReceiptContent()) {
        if (item.containsKey("text")) {
          bytes += generator.text(
            item["text"],
            styles: PosStyles(
              align: item["align"],
              bold: item["bold"] ?? false,
              height: item["height"] ?? 1,
              width: item["width"] ?? 1,
            ),
          );
        } else if (item.containsKey("hr")) {
          bytes += generator.hr();
        } else if (item.containsKey("row")) {
          bytes += generator.row(
            (item["row"] as List)
                .map((col) => PosColumn(text: col["text"], width: col["width"]))
                .toList(),
          );
        } else if (item.containsKey("image")) {
          bytes += generator.image(item["image"]);
        }
      }

      bytes += generator.feed(2);
      bytes += generator.cut();

      await printerManager.send(type: PrinterType.usb, bytes: bytes);
    } catch (e) {
      debugPrint(e.toString());
    } finally {
      await printerManager.disconnect(type: PrinterType.usb);
      setPrintingState(); // End printing state
    }
  }

  Stream<PrinterDevice> scanForPrinters() {
    return printerManager.discovery(type: PrinterType.usb);
  }
}
