import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';

import '../../../models/bills_model.dart';

class ReceiptGenerator {
  final Bill bill;
  // final String shopName;
  // final Uint8List? shopLogo;
  // final String paymentQrData;

  ReceiptGenerator({
    required this.bill,
    // required this.shopName,
    // this.shopLogo,
    // required this.paymentQrData,
  });

  List<Map<String, dynamic>> getReceiptContent() {
    final content = <Map<String, dynamic>>[];

    // Shop header
    // if (shopLogo != null) {
    //   content.add({"image": shopLogo});
    // }
    content.addAll([
      {
        "text": 'shopName',
        "align": PosAlign.center,
        "bold": true,
        "height": 2,
        "width": 2,
      },
      {"hr": true},
      {
        "text": "Invoice #${bill.id.substring(0, 8)}",
        "align": PosAlign.center,
        "bold": true,
      },
      {
        "text": "Date: ${DateFormat('dd/MM/yyyy HH:mm').format(bill.dateTime)}",
        "align": PosAlign.left,
      },
    ]);

    // Customer info
    if (bill.customerName != null) {
      content.add({
        "text": "Customer: ${bill.customerName}",
        "align": PosAlign.left,
      });
    }

    // Items header
    content.addAll([
      {"hr": true},
      {
        "row": [
          {"text": "Item", "width": 4},
          {"text": "Price", "width": 2},
          {"text": "Qty", "width": 2},
          {"text": "Total", "width": 2},
        ],
      },
    ]);

    // Items
    for (var item in bill.items) {
      final qty = bill.quantities[item.id] ?? 1;
      final total = item.price * qty;
      content.add({
        "row": [
          {"text": item.name, "width": 4},
          {"text": "\$${item.price.toStringAsFixed(2)}", "width": 2},
          {"text": qty.toString(), "width": 2},
          {"text": "\$${total.toStringAsFixed(2)}", "width": 2},
        ],
      });
    }

    // Footer
    content.addAll([
      {"hr": true},
      {
        "text": "Subtotal: \$${bill.totalAmount.toStringAsFixed(2)}",
        "align": PosAlign.right,
      },
      if (bill.paymentMethod != null) ...[
        {
          "text": "Payment Method: ${bill.paymentMethod}",
          "align": PosAlign.left,
        },
      ],
      {"text": "Status: ${bill.status}", "align": PosAlign.left},
      {"hr": true},
      {"text": "Thank you for your business!", "align": PosAlign.center},
      {"text": "Scan to pay", "align": PosAlign.center},
      {"image": ''},
    ]);

    return content;
  }

  pw.Widget toPdfWidget() {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        // Shop header
        // if (shopLogo != null)
        //   pw.Center(child: pw.Image(pw.MemoryImage(shopLogo!), width: 100)),
        pw.Center(
          child: pw.Text(
            "shopName",
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
          ),
        ),
        pw.Divider(),
        // Invoice info
        pw.Center(
          child: pw.Text(
            "Invoice #${bill.id.substring(0, 8)}",
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          ),
        ),
        pw.Text(
          "Date: ${DateFormat('dd/MM/yyyy HH:mm').format(bill.dateTime)}",
        ),

        // Customer info
        if (bill.customerName != null)
          pw.Text("Customer: ${bill.customerName}"),
        pw.Divider(),

        // Items header
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
              "Item",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.Text(
              "Price",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.Text("Qty", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.Text(
              "Total",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
          ],
        ),
        pw.Divider(),

        // Items
        ...bill.items.map((item) {
          final qty = bill.quantities[item.id] ?? 1;
          final total = item.price * qty;
          return pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 4),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Expanded(child: pw.Text(item.name)),
                pw.Text("\$${item.price.toStringAsFixed(2)}"),
                pw.Text(qty.toString()),
                pw.Text("\$${total.toStringAsFixed(2)}"),
              ],
            ),
          );
        }),

        // Footer
        pw.Divider(),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
              "Subtotal:",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.Text(
              "\$${bill.totalAmount.toStringAsFixed(2)}",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
          ],
        ),
        if (bill.paymentMethod != null)
          pw.Text("Payment Method: ${bill.paymentMethod}"),
        pw.Text("Status: ${bill.status}"),
        pw.Divider(),
        pw.Center(child: pw.Text("Thank you for your business!")),
        pw.SizedBox(height: 10),
        pw.Center(child: pw.Text("Scan to pay")),
        pw.SizedBox(height: 10),
        pw.Center(
          child: pw.BarcodeWidget(
            data: "paymentQrData",
            barcode: pw.Barcode.qrCode(),
            width: 100,
            height: 100,
          ),
        ),
      ],
    );
  }
}
