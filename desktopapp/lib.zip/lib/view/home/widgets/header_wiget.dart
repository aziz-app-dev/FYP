import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../res/components/app_text_widgrt.dart';

Widget buildSectionHeader(
  String title,
  IconData icon,
  Color color, {
  VoidCallback? onTap,
}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(8.r),
    child: Row(
      children: [
        Container(
          padding: EdgeInsets.all(8.spMin),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(6.r),
          ),
          child: Icon(icon, color: color, size: 20.spMin),
        ),
        SizedBox(width: 12.h),
        Expanded(child: lgTextBold(text: title)),
        if (onTap != null) ...[
          SizedBox(width: 8.w),
          Icon(Icons.arrow_forward_ios, size: 16.spMin),
        ],
      ],
    ),
  );
}
