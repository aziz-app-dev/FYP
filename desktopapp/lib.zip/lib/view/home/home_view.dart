import 'dart:io';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:desktopapp/res/components/app_bar_widget.dart';
import 'package:desktopapp/utils/app_sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../res/colors/app_color.dart';
import '../../view_models/providers/home_page_provider.dart';
import '../../view_models/providers/settings_provider.dart';
import '../shopping_list/shopping_list_view.dart';
import 'rapper.dart';
import 'section_products_view.dart';
import 'widgets/beands_widget.dart';
import 'widgets/cat_widget.dart';
import 'widgets/header_wiget.dart';
import 'widgets/products_widget.dart';

class HomePage extends ConsumerWidget {
  final VoidCallback openDrawer;

  const HomePage({super.key, required this.openDrawer});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final homeState = ref.watch(homePageProvider);

    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        context: context,
        automaticallyImplyLeading: false,
        title: 'Home',
        actions: [
          // Padding(
          //   padding: EdgeInsets.only(right: 8.w),
          //   child: Row(
          //     spacing: 4.w,
          //     mainAxisSize: MainAxisSize.min,
          //     children: [
          //       AppButton().primaryButton(
          //         padding: EdgeInsets.symmetric(horizontal: 4.w),

          //         text: "Add Products",
          //         onPressed: () {
          //           Navigator.push(
          //             context,
          //             MaterialPageRoute(
          //               builder:
          //                   (context) => const ProductTypeSelectionScreen(),
          //             ),
          //           ).then((value) {
          //             ref.read(homePageProvider.notifier).refreshProducts();
          //           });
          //         },
          //         width: 100.h,
          //         height: 28.h,
          //         fontSize: 11.spMin,
          //       ),
          //       AppButton().primaryButton(
          //         padding: EdgeInsets.symmetric(horizontal: 4.h),
          //         text: "Shopping List",
          //         onPressed: () {
          //           Navigator.push(
          //             context,
          //             MaterialPageRoute(
          //               builder: (context) => const ShoppingListView(),
          //             ),
          //           );
          //         },
          //         width: 100.h,
          //         height: 28.h,
          //         fontSize: 11.spMin,
          //       ),
          //     ],
          //   ),
          // ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ShoppingListView()),
          );
        },
      ),
      body:
          homeState.isLoading
              ? const Center(child: CircularProgressIndicator())
              : homeState.error != null
              ? Center(child: Text('Error: ${homeState.error}'))
              : homeState.products.isEmpty
              ? const Center(child: Text('No products available'))
              : ResponsiveWrapper(
                mobile: _buildSectionedView(context, homeState, ref),
                tablet: _buildSectionedView(context, homeState, ref),
                desktop: _buildSectionedView(context, homeState, ref),
              ),
    );
  }

  Widget _buildSectionedView(
    BuildContext context,
    dynamic homeState,
    WidgetRef ref,
  ) {
    final settings = ref.watch(settingsProvider);

    // Build sections based on order
    final sections = <Widget>[];

    for (final sectionKey in settings.sectionOrder) {
      switch (sectionKey) {
        case 'banner':
          if (settings.showBannerSection &&
              settings.bannerImagePaths.isNotEmpty) {
            sections.addAll([
              _buildBannerCarousel(
                settings.bannerImagePaths,
                settings.bannerAutoScroll,
                settings.bannerScrollDuration,
                context,
              ),
              SizedBox(height: 24.h),
            ]);
          }
          break;

        case 'brands':
          if (settings.showBrandsSection &&
              !homeState.brandsLoading &&
              homeState.brands.isNotEmpty) {
            sections.addAll([
              buildSectionHeader(
                'Shop by Brands',
                Icons.branding_watermark,
                AppColors.primary,
              ),
              SizedBox(height: 12.h),
              buildBrandsCarousel(context, homeState.brands, ref),
              SizedBox(height: 24.h),
            ]);
          }
          break;

        case 'categories':
          if (settings.showCategoriesSection &&
              !homeState.categoriesLoading &&
              homeState.categories.isNotEmpty) {
            sections.addAll([
              buildSectionHeader('Categories', Icons.category, Colors.purple),
              SizedBox(height: 12.h),
              buildCategoriesCarousel(context, homeState.categories, ref),
              SizedBox(height: 24.h),
            ]);
          }
          break;

        case 'topSelling':
          if (settings.showTopSellingSection &&
              homeState.topSellingProducts.isNotEmpty) {
            final products =
                homeState.topSellingProducts
                    .take(settings.topSellingProductsCount)
                    .toList();
            sections.addAll([
              buildSectionHeader(
                'Top Selling Products & Services',
                Icons.trending_up,
                Colors.orange,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TopSellingProductsView(),
                    ),
                  );
                },
              ),
              SizedBox(height: 12.h),
              buildProductGrid(context, products),
              SizedBox(height: 24.h),
            ]);
          }
          break;

        case 'latestItems':
          if (settings.showLatestItemsSection &&
              homeState.latestItems.isNotEmpty) {
            final products =
                homeState.latestItems.take(settings.latestItemsCount).toList();
            sections.addAll([
              buildSectionHeader(
                'Latest Added Items',
                Icons.new_releases,
                Colors.blue,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LatestItemsView(),
                    ),
                  );
                },
              ),
              SizedBox(height: 12.h),
              buildProductGrid(context, products),
              SizedBox(height: 24.h),
            ]);
          }
          break;

        case 'latestServices':
          if (settings.showLatestServicesSection &&
              homeState.latestServices.isNotEmpty) {
            final products =
                homeState.latestServices
                    .take(settings.latestServicesCount)
                    .toList();
            sections.addAll([
              buildSectionHeader(
                'Latest Services',
                Icons.room_service,
                Colors.green,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LatestServicesView(),
                    ),
                  );
                },
              ),
              SizedBox(height: 12.h),
              buildProductGrid(context, products),
              SizedBox(height: 24.h),
            ]);
          }
          break;

        case 'lowStock':
          if (settings.showLowStockSection &&
              homeState.lowStockItems.isNotEmpty) {
            final products =
                homeState.lowStockItems
                    .take(settings.lowStockItemsCount)
                    .toList();
            sections.addAll([
              buildSectionHeader(
                'Low Stock Items',
                Icons.warning_amber_rounded,
                Colors.red,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LowStockItemsView(),
                    ),
                  );
                },
              ),
              SizedBox(height: 12.h),
              buildProductGrid(context, products),
              SizedBox(height: 24.h),
            ]);
          }
          break;
      }
    }

    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(
        horizontal: AppSizes.md.h,
        vertical: AppSizes.md.h,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: sections,
      ),
    );
  }

  Widget _buildBannerCarousel(
    List<String> imagePaths,
    bool autoScroll,
    int scrollDuration,
    BuildContext context,
  ) {
    final double sliderHight = MediaQuery.sizeOf(context).width;
    return CarouselSlider(
      options: CarouselOptions(
        height:
            AppSizes.isMobile(context)
                ? sliderHight * 0.350
                : sliderHight * 0.150,
        // height: sliderHight,
        autoPlay: autoScroll,
        autoPlayInterval: Duration(seconds: scrollDuration),
        autoPlayAnimationDuration: const Duration(milliseconds: 800),
        autoPlayCurve: Curves.fastOutSlowIn,
        enlargeCenterPage: true,
        viewportFraction: 1,
        // aspectRatio: 16.spMin / 9.spMin,
      ),
      items:
          imagePaths.map((imagePath) {
            return Builder(
              builder: (BuildContext context) {
                return Container(
                  height: sliderHight,
                  width: MediaQuery.of(context).size.width,
                  // margin: EdgeInsets.symmetric(horizontal: 5.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(
                      AppSizes.borderRadiusMd.r,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(
                      AppSizes.borderRadiusMd.r,
                    ),
                    child: Image.file(
                      File(imagePath),
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          color: Colors.grey.shade300,
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.broken_image,
                                  size: 48.spMin,
                                  color: Colors.grey,
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  'Image not found',
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 12.spMin,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                );
              },
            );
          }).toList(),
    );
  }
}
