// ignore_for_file: use_build_context_synchronously

import 'dart:io';
import 'package:desktopapp/res/components/app_button.dart';
import 'package:desktopapp/res/components/text_field_widget.dart';
import 'package:desktopapp/utils/app_sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import '../../models/brand_model.dart';
import '../../res/colors/app_color.dart';
import '../../res/components/app_bar_widget.dart';
import '../../res/components/app_text_widgrt.dart';
import '../../view_models/services/database/database_services.dart';

final brandsProvider = FutureProvider.autoDispose<List<Brand>>((ref) async {
  final dbService = DatabaseService();
  return await dbService.getBrands();
});

class BrandManagementScreen extends ConsumerStatefulWidget {
  const BrandManagementScreen({super.key});

  @override
  ConsumerState<BrandManagementScreen> createState() =>
      _BrandManagementScreenState();
}

class _BrandManagementScreenState extends ConsumerState<BrandManagementScreen> {
  final DatabaseService _dbService = DatabaseService();

  void _showAddBrandDialog({Brand? brand}) {
    final TextEditingController controller = TextEditingController(
      text: brand?.name ?? '',
    );
    final isEdit = brand != null;
    final ValueNotifier<File?> selectedImageNotifier = ValueNotifier<File?>(
      null,
    );
    final ValueNotifier<String?> existingImageUrlNotifier =
        ValueNotifier<String?>(brand?.imageUrl);

    showDialog(
      context: context,
      builder:
          (dialogContext) => AlertDialog(
            title: Text(
              isEdit ? 'Edit Brand' : 'Add New Brand',
              style: TextStyle(fontSize: 18.spMin),
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Image Picker
                  ValueListenableBuilder<File?>(
                    valueListenable: selectedImageNotifier,
                    builder: (context, selectedImage, _) {
                      return ValueListenableBuilder<String?>(
                        valueListenable: existingImageUrlNotifier,
                        builder: (context, existingImageUrl, _) {
                          return GestureDetector(
                            onTap: () async {
                              final ImagePicker picker = ImagePicker();
                              final XFile? image = await picker.pickImage(
                                source: ImageSource.gallery,
                                maxWidth: 800,
                                maxHeight: 800,
                              );
                              if (image != null) {
                                selectedImageNotifier.value = File(image.path);
                                existingImageUrlNotifier.value = null;
                              }
                            },
                            child: Container(
                              height: 120.h,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: AppColors.primary.withValues(
                                    alpha: 0.5,
                                  ),
                                  width: 1.5,
                                ),
                                borderRadius: BorderRadius.circular(12.r),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(12.r),
                                child:
                                    selectedImage != null
                                        ? Stack(
                                          children: [
                                            Image.file(
                                              selectedImage,
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                            ),
                                            Positioned(
                                              top: 4.h,
                                              right: 4.w,
                                              child: IconButton(
                                                icon: Icon(
                                                  Icons.cancel,
                                                  color: Colors.red,
                                                  size: 24.spMin,
                                                ),
                                                onPressed: () {
                                                  selectedImageNotifier.value =
                                                      null;
                                                  existingImageUrlNotifier
                                                      .value = brand?.imageUrl;
                                                },
                                              ),
                                            ),
                                          ],
                                        )
                                        : existingImageUrl != null
                                        ? Stack(
                                          children: [
                                            Image.file(
                                              File(existingImageUrl),
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                            ),
                                            Positioned(
                                              top: 4.h,
                                              right: 4.w,
                                              child: IconButton(
                                                icon: Icon(
                                                  Icons.cancel,
                                                  color: Colors.red,
                                                  size: 24.spMin,
                                                ),
                                                onPressed: () {
                                                  existingImageUrlNotifier
                                                      .value = null;
                                                },
                                              ),
                                            ),
                                          ],
                                        )
                                        : Center(
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Icon(
                                                Icons
                                                    .add_photo_alternate_outlined,
                                                size: 40.spMin,
                                                color: AppColors.primary
                                                    .withValues(alpha: 0.7),
                                              ),
                                              SizedBox(height: 8.h),
                                              smText(
                                                text: 'Tap to add brand logo',
                                                color: Colors.grey,
                                              ),
                                            ],
                                          ),
                                        ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                  SizedBox(height: 16.h),

                  CustomTextField(
                    controller: controller,

                    label: 'Brand Name',
                    hintText: 'Enter brand name',
                  ),
                ],
              ),
            ),
            actions: [
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(dialogContext),
                      child: Text(
                        'Cancel',
                        style: TextStyle(fontSize: 14.spMin),
                      ),
                    ),
                  ),
                  Expanded(
                    child: AppButton().primaryButton(
                      height: 35.h,
                      text: isEdit ? 'Update' : 'Add',
                      onPressed: () async {
                        if (controller.text.trim().isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Brand name cannot be empty',
                                style: TextStyle(fontSize: 14.spMin),
                              ),
                              backgroundColor: Colors.red,
                            ),
                          );
                          return;
                        }
                      },
                    ),
                  ),
                ],
              ),
              // ElevatedButton(
              //   onPressed: () async {
              //     if (controller.text.trim().isEmpty) {
              //       ScaffoldMessenger.of(context).showSnackBar(
              //         SnackBar(
              //           content: Text(
              //             'Brand name cannot be empty',
              //             style: TextStyle(fontSize: 14.spMin),
              //           ),
              //           backgroundColor: Colors.red,
              //         ),
              //       );
              //       return;
              //     }

              //     final imageUrl =
              //         selectedImageNotifier.value?.path ??
              //         existingImageUrlNotifier.value;

              //     if (isEdit) {
              //       final updatedBrand = brand.copyWith(
              //         name: controller.text.trim(),
              //         imageUrl: imageUrl,
              //         updatedAt: DateTime.now(),
              //       );
              //       await _dbService.updateBrand(updatedBrand);
              //     } else {
              //       final newBrand = Brand(
              //         id: DateTime.now().millisecondsSinceEpoch.toString(),
              //         name: controller.text.trim(),
              //         imageUrl: imageUrl,
              //         createdAt: DateTime.now(),
              //         updatedAt: DateTime.now(),
              //       );
              //       await _dbService.addBrand(newBrand);
              //     }

              //     if (mounted) {
              //       Navigator.pop(dialogContext);
              //       ref.invalidate(brandsProvider);
              //       ScaffoldMessenger.of(context).showSnackBar(
              //         SnackBar(
              //           content: Text(
              //             isEdit
              //                 ? 'Brand updated successfully'
              //                 : 'Brand added successfully',
              //             style: TextStyle(fontSize: 14.spMin),
              //           ),
              //           backgroundColor: Colors.green,
              //         ),
              //       );
              //     }
              //   },
              //   child: Text(
              //     isEdit ? 'Update' : 'Add',
              //     style: TextStyle(fontSize: 14.spMin),
              //   ),
              // ),
            ],
          ),
    );
  }

  void _deleteBrand(Brand brand) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Delete Brand', style: TextStyle(fontSize: 18.spMin)),
            content: Text(
              'Are you sure you want to delete "${brand.name}"?',
              style: TextStyle(fontSize: 14.spMin),
            ),
            actions: [
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text(
                        'Cancel',
                        style: TextStyle(fontSize: 14.spMin),
                      ),
                    ),
                  ),
                  Expanded(
                    child: AppButton().primaryButton(
                      color: AppColors.error,
                      height: 35.h,
                      text: "Delete",
                      onPressed: () async {
                        await _dbService.deleteBrand(brand.id);
                        if (mounted) {
                          Navigator.pop(context);
                          ref.invalidate(brandsProvider);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Brand deleted successfully',
                                style: TextStyle(fontSize: 14.spMin),
                              ),
                              backgroundColor: Colors.orange,
                            ),
                          );
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final brandsAsync = ref.watch(brandsProvider);

    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: 'Brand Management',
        context: context,
      ),
      body: brandsAsync.when(
        data: (brands) {
          if (brands.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.category_outlined,
                    size: 80.spMin,
                    color: Colors.grey,
                  ),
                  SizedBox(height: 16.h),
                  mdTextBold(text: 'No brands added yet'),
                  SizedBox(height: 8.h),
                  smText(text: 'Tap the + button to add a brand'),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: EdgeInsets.symmetric(
              horizontal: AppSizes.md.h,
              vertical: AppSizes.sm.h,
            ),
            itemCount: brands.length,
            itemBuilder: (context, index) {
              final brand = brands[index];
              return Card(
                elevation: 2,
                margin: EdgeInsets.only(bottom: 12.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: ListTile(
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: AppSizes.md.h,
                    vertical: 8.h,
                  ),
                  leading:
                      brand.imageUrl != null
                          ? SizedBox(
                            width: 56.h,
                            height: 56.h,
                            child: Image.file(
                              File(brand.imageUrl!),
                              fit: BoxFit.contain,
                              errorBuilder: (context, error, stackTrace) {
                                return Icon(
                                  Icons.branding_watermark,
                                  color: AppColors.primary,
                                  size: 24.spMin,
                                );
                              },
                            ),
                          )
                          : Container(
                            width: 56.h,
                            height: 56.h,
                            decoration: BoxDecoration(
                              color: AppColors.primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                            child: Icon(
                              Icons.branding_watermark,
                              color: AppColors.primary,
                              size: 24.spMin,
                            ),
                          ),
                  title: mdTextBold(text: brand.name),

                  trailing: PopupMenuButton<String>(
                    icon: Icon(
                      Icons.more_vert,
                      color: Colors.grey,
                      size: 22.spMin,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    onSelected: (value) {
                      if (value == 'edit') {
                        _showAddBrandDialog(brand: brand);
                      } else if (value == 'delete') {
                        _deleteBrand(brand);
                      }
                    },
                    itemBuilder:
                        (context) => [
                          PopupMenuItem(
                            value: 'edit',
                            child: Row(
                              children: [
                                Icon(
                                  Icons.edit,
                                  color: AppColors.primary,
                                  size: 18.spMin,
                                ),
                                SizedBox(width: 8.w),
                                Text(
                                  'Edit',
                                  style: TextStyle(fontSize: 14.spMin),
                                ),
                              ],
                            ),
                          ),
                          PopupMenuItem(
                            value: 'delete',
                            child: Row(
                              children: [
                                Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                  size: 18.spMin,
                                ),
                                SizedBox(width: 8.w),
                                Text(
                                  'Delete',
                                  style: TextStyle(fontSize: 14.spMin),
                                ),
                              ],
                            ),
                          ),
                        ],
                  ),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error:
            (error, stack) => Center(
              child: Text(
                'Error: $error',
                style: TextStyle(fontSize: 14.spMin, color: Colors.red),
              ),
            ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddBrandDialog,
        child: const Icon(Icons.add),
      ),
    );
  }
}
