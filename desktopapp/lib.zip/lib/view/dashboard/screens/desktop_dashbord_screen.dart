import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';

class DesktopDashbordScreen extends StatelessWidget {
  const DesktopDashbordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DesktopDashBorad();
  }
}

class DesktopDashBorad extends StatelessWidget {
  const DesktopDashBorad({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: 400,
        width: 200,
        child: DataTable2(
          columnSpacing: 4,
          horizontalMargin: 4,
          dataRowHeight: 4,
          dividerThickness: 0,
          decoration: BoxDecoration(
            border: Border.all(),
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
          columns: const [
            DataColumn(label: Text('Column 1')),
            DataColumn(label: Text('Column 2')),
            DataColumn(label: Text('Column 3')),
            DataColumn(label: Text('Column 4')),
          ],
          rows: List<DataRow>.generate(
            20,
            (index) => DataRow(
              cells: [
                DataCell(Text('Row ${index + 1}')),
                DataCell(Text('Data ${index + 1}')),
                DataCell(Text('Value ${index + 1}')),
                DataCell(Text('Detail ${index + 1}')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
