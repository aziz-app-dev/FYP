import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../home/rapper.dart';
import '../../view_models/providers/dashboard_provider.dart';

class DashboradView extends ConsumerWidget {
  const DashboradView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dashboardState = ref.watch(dashboardProvider);
    final startIndex = dashboardState.currentPage * dashboardState.rowsPerPage;
    final endIndex = (dashboardState.currentPage + 1) * dashboardState.rowsPerPage;
    final visibleData = dashboardState.data.sublist(
      startIndex,
      endIndex > dashboardState.data.length ? dashboardState.data.length : endIndex,
    );

    return Scaffold(
      body: ResponsiveWrapper(
        desktop: _buildDesktopView(context, ref, visibleData),
        tablet: _buildTabletView(),
        mobile: _buildMobileView(),
      ),
    );
  }

  Widget _buildDesktopView(BuildContext context, WidgetRef ref, List<List<String>> visibleData) {
    return Padding(
      padding: EdgeInsets.all(16.h),
      child: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withValues(alpha: 0.2),
                    spreadRadius: 2,
                    blurRadius: 5,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Table header
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 12.h),
                    child: Text(
                      'Product Inventory',
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                  // DataTable with proper constraints
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.w),
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          return SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: ConstrainedBox(
                              constraints: BoxConstraints(
                                minWidth: constraints.maxWidth,
                              ),
                              child: DataTable2(
                                columnSpacing: 12.w,
                                horizontalMargin: 12.w,
                                minWidth: 800.w,
                                dataRowHeight: 48.h,
                                headingRowHeight: 56.h,
                                dividerThickness: 1,
                                showCheckboxColumn: false,
                                columns: const [
                                  DataColumn2(
                                    label: Text('Product'),
                                    size: ColumnSize.L,
                                  ),
                                  DataColumn2(
                                    label: Text('Category'),
                                    size: ColumnSize.M,
                                  ),
                                  DataColumn2(
                                    label: Text('Price'),
                                    size: ColumnSize.S,
                                  ),
                                  DataColumn2(
                                    label: Text('Status'),
                                    size: ColumnSize.S,
                                  ),
                                ],
                                rows:
                                    visibleData
                                        .map(
                                          (row) => DataRow2(
                                            cells: [
                                              DataCell(Text(row[0])),
                                              DataCell(Text(row[1])),
                                              DataCell(Text(row[2])),
                                              DataCell(
                                                Container(
                                                  padding: EdgeInsets.symmetric(
                                                    horizontal: 8.w,
                                                    vertical: 4.h,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color: _getStatusColor(
                                                      row[3],
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          12,
                                                        ),
                                                  ),
                                                  child: Text(
                                                    row[3],
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 12.sp,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        )
                                        .toList(),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  // Pagination controls
                  _buildPaginationControls(context, ref),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabletView() {
    return const Center(child: Text('Tablet View'));
  }

  Widget _buildMobileView() {
    return const Center(child: Text('Mobile View'));
  }

  Widget _buildPaginationControls(BuildContext context, WidgetRef ref) {
    final dashboardState = ref.watch(dashboardProvider);
    final totalPages = (dashboardState.data.length / dashboardState.rowsPerPage).ceil();
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 16.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left),
            onPressed:
                dashboardState.currentPage > 0
                    ? () => ref.read(dashboardProvider.notifier).previousPage()
                    : null,
          ),
          SizedBox(width: 16.w),
          Text(
            'Page ${dashboardState.currentPage + 1} of $totalPages',
            style: TextStyle(fontSize: 14.sp),
          ),
          SizedBox(width: 16.w),
          IconButton(
            icon: const Icon(Icons.chevron_right),
            onPressed:
                dashboardState.currentPage < totalPages - 1
                    ? () => ref.read(dashboardProvider.notifier).nextPage()
                    : null,
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Status 1':
        return Colors.green;
      case 'Status 2':
        return Colors.orange;
      case 'Status 3':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}
