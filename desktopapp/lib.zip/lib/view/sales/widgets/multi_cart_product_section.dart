import 'package:desktopapp/res/components/app_text_widgrt.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';
import '../../../models/items_model.dart';
import '../../../res/colors/app_color.dart';
import '../../../view_models/providers/multi_cart_provider.dart';
import '../../../view_models/providers/sales_provider.dart';
import '../../../view_models/providers/product_search_provider.dart';
import '../../../res/components/product_card.dart';

class ProductsSectionWithSearch extends ConsumerStatefulWidget {
  const ProductsSectionWithSearch({super.key});

  @override
  ConsumerState<ProductsSectionWithSearch> createState() =>
      _ProductsSectionWithSearchState();
}

class _ProductsSectionWithSearchState
    extends ConsumerState<ProductsSectionWithSearch> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Product> _filterProducts(List<Product> products, String searchQuery) {
    if (searchQuery.isEmpty) return products;

    return products.where((product) {
      final nameLower = product.name.toLowerCase();
      final queryLower = searchQuery.toLowerCase();
      final descriptionLower = product.description?.toLowerCase() ?? '';

      return nameLower.contains(queryLower) ||
          descriptionLower.contains(queryLower);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final productsAsync = ref.watch(productsFutureProvider);
    final searchState = ref.watch(multiCartProductSearchProvider);
    final bool isTablet =
        MediaQuery.of(context).size.width >= 600 &&
        MediaQuery.of(context).size.width < 1100;
    final bool isMobile = MediaQuery.of(context).size.width < 600;

    return productsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error:
          (error, stack) => Center(
            child: Text('Error: $error', style: TextStyle(fontSize: 16.spMin)),
          ),
      data: (products) {
        final filteredProducts = _filterProducts(
          products,
          searchState.searchQuery,
        );

        return Column(
          children: [
            // Search Bar
            Padding(
              padding: EdgeInsets.all(8.w),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search products...',
                  hintStyle: TextStyle(fontSize: 14.spMin),
                  prefixIcon: Icon(
                    TablerIcons.search,
                    size: 20.spMin,
                    color:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.white70
                            : AppColors.lIconColor,
                  ),
                  suffixIcon:
                      searchState.searchQuery.isNotEmpty
                          ? IconButton(
                            icon: Icon(TablerIcons.x, size: 20.spMin),
                            onPressed: () {
                              _searchController.clear();
                              ref
                                  .read(multiCartProductSearchProvider.notifier)
                                  .clearSearch();
                            },
                          )
                          : null,
                  filled: true,
                  fillColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? AppColors.grey800
                          : AppColors.grey100,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 12.w,
                    vertical: 10.h,
                  ),
                ),
                onChanged: (value) {
                  ref
                      .read(multiCartProductSearchProvider.notifier)
                      .updateSearchQuery(value);
                },
              ),
            ),

            // Products Grid
            Expanded(
              child:
                  filteredProducts.isEmpty
                      ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              TablerIcons.search_off,
                              size: 48.spMin,
                              color: Colors.grey,
                            ),
                            SizedBox(height: 8.h),
                            Text(
                              searchState.searchQuery.isEmpty
                                  ? 'No items available'
                                  : 'No products found for "${searchState.searchQuery}"',
                              style: TextStyle(
                                fontSize: 14.spMin,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      )
                      : GridView.builder(
                        padding: EdgeInsets.all(4.w),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: isMobile ? 3 : (isTablet ? 4 : 5),
                          childAspectRatio:
                              isMobile
                                  ? 1.4.spMin
                                  : isTablet
                                  ? 0.90.spMin
                                  : 0.80.spMin,
                          crossAxisSpacing: 4.w,
                          mainAxisSpacing: 4.w,
                        ),
                        itemCount: filteredProducts.length,
                        itemBuilder: (context, index) {
                          final product = filteredProducts[index];
                          return ProductCard(
                            product: product,
                            onTap: () {
                              // Skip stock check for services (isService == true, stock == null)
                              if (!product.isService &&
                                  product.stock != null &&
                                  product.stock! <= 0) {
                                showDialog(
                                  context: context,
                                  builder:
                                      (context) => AlertDialog(
                                        title: mdTextBold(text: 'Out of Stock'),
                                        content: smText(
                                          text:
                                              '${product.name} is currently out of stock.',
                                          maxLines: 3,
                                        ),
                                        actions: [
                                          TextButton(
                                            onPressed:
                                                () => Navigator.pop(context),
                                            child: Text(
                                              'OK',
                                              style: TextStyle(
                                                fontSize: 14.spMin,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                );
                              } else {
                                // Use multi-cart provider to add to active cart
                                ref
                                    .read(multiCartProvider.notifier)
                                    .addToCart(product);
                              }
                            },
                          );
                        },
                      ),
            ),
          ],
        );
      },
    );
  }
}

// Keep the old function for backwards compatibility
Widget buildProductsSection(WidgetRef ref) {
  return const ProductsSectionWithSearch();
}
