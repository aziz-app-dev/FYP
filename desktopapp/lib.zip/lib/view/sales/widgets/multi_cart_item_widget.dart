import 'dart:io';
import 'package:desktopapp/res/colors/app_color.dart';
import 'package:desktopapp/res/components/app_text_widgrt.dart';
import 'package:desktopapp/view_models/providers/multi_cart_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../models/items_model.dart';

class MultiCartItemWidget extends StatelessWidget {
  final MapEntry<Product, int> entry;
  final WidgetRef ref;
  final String cartId;

  const MultiCartItemWidget({
    super.key,
    required this.entry,
    required this.ref,
    required this.cartId,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      child: Container(
        height: 60.spMin,
        padding: EdgeInsets.all(4.h),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? AppColors.dCardColor
              : AppColors.primaryLight1,
          borderRadius: const BorderRadius.all(Radius.circular(6)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              spacing: 2.w,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                entry.key.imageUrl != null && entry.key.imageUrl!.isNotEmpty
                    ? ClipRRect(
                        borderRadius: const BorderRadius.all(Radius.circular(6)),
                        child: Image.file(
                          File(entry.key.imageUrl!),
                          fit: BoxFit.cover,
                          width: 50.spMin,
                          height: 50.spMin,
                          errorBuilder: (context, error, stackTrace) => Icon(
                            Icons.broken_image,
                            size: 40.spMin,
                            color: Colors.grey,
                          ),
                        ),
                      )
                    : SizedBox(
                        width: 15.w,
                        child: Icon(Icons.shopping_bag, size: 25.spMin),
                      ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 35.w,
                      child: smTextBold(text: entry.key.name, maxLines: 2),
                    ),
                    xsText(text: entry.key.price.toStringAsFixed(0)),
                  ],
                ),
              ],
            ),
            Padding(
              padding: EdgeInsets.only(right: 1.w),
              child: Row(
                spacing: 2.h,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.min,
                children: [
                  ActionIcon(
                    onTap: () => ref
                        .read(multiCartProvider.notifier)
                        .removeFromCart(entry.key),
                    icon: Icons.remove,
                  ),
                  Consumer(
                    builder: (context, ref, _) {
                      final currentCart = ref.watch(multiCartProvider).activeCart;
                      final currentValue = currentCart?.cartItems[entry.key] ?? 0;
                      return smText(text: '$currentValue');
                    },
                  ),
                  ActionIcon(
                    onTap: () => ref
                        .read(multiCartProvider.notifier)
                        .addToCart(entry.key),
                    icon: Icons.add,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ActionIcon extends StatelessWidget {
  const ActionIcon({super.key, required this.onTap, required this.icon});
  final VoidCallback onTap;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? AppColors.grey800
            : AppColors.primaryLight4,
        borderRadius: const BorderRadius.all(Radius.circular(4)),
      ),
      child: InkWell(onTap: onTap, child: Icon(icon, size: 14.spMin)),
    );
  }
}
