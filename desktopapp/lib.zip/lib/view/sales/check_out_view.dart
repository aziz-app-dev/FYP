// ignore_for_file: use_build_context_synchronously

import 'dart:math'; // Added for random generation
import 'package:desktopapp/res/colors/app_color.dart';
import 'package:desktopapp/res/components/app_bar_widget.dart';
import 'package:desktopapp/res/components/app_button.dart';
import 'package:desktopapp/res/components/app_text_widgrt.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';
import '../../models/coustomer_model.dart';
import '../../res/components/text_field_widget.dart';
import '../../view_models/providers/sales_provider.dart';
import '../../view_models/providers/checkout_provider.dart';
import '../../view_models/services/database/database_services.dart';
import '../../models/items_model.dart';
import '../../view_models/states/sales_state.dart';
import '../../utils/payment_calculator.dart';
import '../home/rapper.dart';

class CustomerFormState {
  final String? name;
  final String? address;
  final String? phoneNumber;
  final double? paidAmount;
  final bool? paymentStatus;
  final String? paymentMethod;
  final double? discount;
  final Map<String, FieldConfig> fieldConfigs;
  final String? errorMessage;
  final bool isLoading;

  CustomerFormState({
    this.name,
    this.address,
    this.phoneNumber,
    this.paidAmount,
    this.paymentStatus,
    this.paymentMethod,
    this.discount,
    required this.fieldConfigs,
    this.errorMessage,
    this.isLoading = false,
  });

  CustomerFormState copyWith({
    String? name,
    String? address,
    String? phoneNumber,
    double? paidAmount,
    bool? paymentStatus,
    String? paymentMethod,
    double? discount,
    Map<String, FieldConfig>? fieldConfigs,
    String? errorMessage,
    bool? isLoading,
  }) {
    return CustomerFormState(
      name: name ?? this.name,
      address: address ?? this.address,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      paidAmount: paidAmount ?? this.paidAmount,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      discount: discount ?? this.discount,
      fieldConfigs: fieldConfigs ?? this.fieldConfigs,
      errorMessage: errorMessage,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

class CustomerFormNotifier extends StateNotifier<CustomerFormState> {
  final DatabaseService _databaseService;

  CustomerFormNotifier(this._databaseService)
    : super(CustomerFormState(fieldConfigs: _loadDefaultFieldConfigs()));

  static Map<String, FieldConfig> _loadDefaultFieldConfigs() {
    return {
      'name': FieldConfig.initial('name', WidgetType.textField),
      'address': FieldConfig.initial('address', WidgetType.textField),
      'phoneNumber': FieldConfig.initial('phoneNumber', WidgetType.textField),
      'paidAmount': FieldConfig.initial('paidAmount', WidgetType.textField),
      'paymentStatus': FieldConfig.initial(
        'paymentStatus',
        WidgetType.dropdown,
      ),
      'paymentMethod': FieldConfig.initial(
        'paymentMethod',
        WidgetType.dropdown,
      ),
      'discount': FieldConfig.initial('discount', WidgetType.textField),
    };
  }

  void updateName(String name) {
    state = state.copyWith(name: name, errorMessage: null);
  }

  void updateAddress(String address) {
    state = state.copyWith(
      address: address.isEmpty ? null : address,
      errorMessage: null,
    );
  }

  void updatePhoneNumber(String phoneNumber) {
    state = state.copyWith(
      phoneNumber: phoneNumber.isEmpty ? null : phoneNumber,
      errorMessage: null,
    );
  }

  void updatePaidAmount(String paidAmount) {
    final parsedAmount = double.tryParse(paidAmount);
    state = state.copyWith(paidAmount: parsedAmount, errorMessage: null);
  }

  void updatePaymentStatus(String status) {
    state = state.copyWith(paymentStatus: status == 'Paid', errorMessage: null);
  }

  void updatePaymentMethod(String? method) {
    state = state.copyWith(paymentMethod: method, errorMessage: null);
  }

  void updateDiscount(String discount) {
    final parsedDiscount = double.tryParse(discount);
    state = state.copyWith(discount: parsedDiscount, errorMessage: null);
  }

  void updateFieldConfig(
    String fieldName, {
    bool? isShow,
    bool? isRequired,
    String? hintText,
    String? validatorText,
    String? title,
    WidgetType? widgetType,
  }) {
    final updatedConfigs = Map<String, FieldConfig>.from(state.fieldConfigs);
    updatedConfigs[fieldName] = updatedConfigs[fieldName]!.copyWith(
      isShow: isShow,
      isRequired: isRequired,
      hintText: hintText,
      validatorText: validatorText,
      title: title,
      widgetType: widgetType,
    );
    state = state.copyWith(fieldConfigs: updatedConfigs);
    _saveFieldConfigs(updatedConfigs);
  }

  Future<void> _saveFieldConfigs(Map<String, FieldConfig> fieldConfigs) async {
    try {
      await _databaseService.saveCustomerFieldConfigs(fieldConfigs);
    } catch (e) {
      state = state.copyWith(errorMessage: 'Failed to save field configs: $e');
    }
  }
}

final customerFormProvider =
    StateNotifierProvider<CustomerFormNotifier, CustomerFormState>(
      (ref) => CustomerFormNotifier(ref.read(databaseServiceProvider)),
    );

class CustomerPaymentScreen extends ConsumerStatefulWidget {
  final double totalAmount;
  final double discount;

  const CustomerPaymentScreen({
    super.key,
    required this.totalAmount,
    required this.discount,
  });

  @override
  ConsumerState<CustomerPaymentScreen> createState() =>
      _CustomerPaymentScreenState();
}

class _CustomerPaymentScreenState extends ConsumerState<CustomerPaymentScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController paidAmountController = TextEditingController();
  final TextEditingController discountController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final customers = await ref.read(databaseServiceProvider).getCustomers();
      ref.read(checkoutProvider.notifier).loadCustomers(customers);
      final fieldConfigs =
          await ref.read(databaseServiceProvider).getCustomerFieldConfigs();
      ref
          .read(customerFormProvider.notifier)
          .updateFieldConfig(
            'name',
            title: fieldConfigs['name']?.title ?? 'Customer Name',
            hintText: fieldConfigs['name']?.hintText ?? 'Enter customer name',
            validatorText:
                fieldConfigs['name']?.validatorText ??
                'Customer name is required',
            isShow: fieldConfigs['name']?.isShow ?? true,
            isRequired: fieldConfigs['name']?.isRequired ?? true,
          );
      ref
          .read(customerFormProvider.notifier)
          .updateFieldConfig(
            'address',
            title: fieldConfigs['address']?.title ?? 'Address',
            hintText: fieldConfigs['address']?.hintText ?? 'Enter address',
            validatorText:
                fieldConfigs['address']?.validatorText ?? 'Address is required',
            isShow: fieldConfigs['address']?.isShow ?? true,
            isRequired: fieldConfigs['address']?.isRequired ?? false,
          );
      ref
          .read(customerFormProvider.notifier)
          .updateFieldConfig(
            'phoneNumber',
            title: fieldConfigs['phoneNumber']?.title ?? 'Phone Number',
            hintText:
                fieldConfigs['phoneNumber']?.hintText ?? 'Enter phone number',
            validatorText:
                fieldConfigs['phoneNumber']?.validatorText ??
                'Phone number is required',
            isShow: fieldConfigs['phoneNumber']?.isShow ?? true,
            isRequired: fieldConfigs['phoneNumber']?.isRequired ?? false,
          );
      ref
          .read(customerFormProvider.notifier)
          .updateFieldConfig(
            'paidAmount',
            title: fieldConfigs['paidAmount']?.title ?? 'Paid Amount',
            hintText:
                fieldConfigs['paidAmount']?.hintText ?? 'Enter paid amount',
            validatorText:
                fieldConfigs['paidAmount']?.validatorText ?? 'Invalid amount',
            isShow: fieldConfigs['paidAmount']?.isShow ?? true,
            isRequired: fieldConfigs['paidAmount']?.isRequired ?? false,
          );
      ref
          .read(customerFormProvider.notifier)
          .updateFieldConfig(
            'paymentStatus',
            title: fieldConfigs['paymentStatus']?.title ?? 'Payment Status',
            hintText:
                fieldConfigs['paymentStatus']?.hintText ??
                'Select payment status',
            validatorText:
                fieldConfigs['paymentStatus']?.validatorText ??
                'Payment status is required',
            isShow: fieldConfigs['paymentStatus']?.isShow ?? true,
            isRequired: fieldConfigs['paymentStatus']?.isRequired ?? true,
          );
      ref
          .read(customerFormProvider.notifier)
          .updateFieldConfig(
            'paymentMethod',
            title: fieldConfigs['paymentMethod']?.title ?? 'Payment Method',
            hintText:
                fieldConfigs['paymentMethod']?.hintText ??
                'Select payment method',
            validatorText:
                fieldConfigs['paymentMethod']?.validatorText ??
                'Payment method is required',
            isShow: fieldConfigs['paymentMethod']?.isShow ?? true,
            isRequired: fieldConfigs['paymentMethod']?.isRequired ?? true,
          );
      ref
          .read(customerFormProvider.notifier)
          .updateFieldConfig(
            'discount',
            title: fieldConfigs['discount']?.title ?? 'Discount',
            hintText:
                fieldConfigs['discount']?.hintText ?? 'Enter discount amount',
            validatorText:
                fieldConfigs['discount']?.validatorText ??
                'Invalid discount amount',
            isShow: fieldConfigs['discount']?.isShow ?? true,
            isRequired: fieldConfigs['discount']?.isRequired ?? false,
          );
    });

    final salesState = ref.read(salesProvider);
    paidAmountController.text =
        salesState.paidAmount > 0
            ? salesState.paidAmount.toStringAsFixed(0)
            : '';
    discountController.text =
        salesState.discount > 0 ? salesState.discount.toStringAsFixed(0) : '';
  }

  @override
  void dispose() {
    nameController.dispose();
    addressController.dispose();
    phoneController.dispose();
    paidAmountController.dispose();
    discountController.dispose();
    super.dispose();
  }

  void _toggleWalkIn(bool? value) {
    final isWalkIn = value ?? false;
    ref.read(checkoutProvider.notifier).toggleWalkIn(isWalkIn);

    if (isWalkIn) {
      // Generate random bill ID (e.g., BILL-1234)
      final random = Random();
      final randomBillId =
          'BILL-${random.nextInt(10000).toString().padLeft(4, '0')}';
      nameController.text = randomBillId;
      addressController.text = '';
      phoneController.text = '';
      ref.read(customerFormProvider.notifier).updateName(randomBillId);
      ref.read(customerFormProvider.notifier).updateAddress('');
      ref.read(customerFormProvider.notifier).updatePhoneNumber('');
      // Show confirmation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: mdText(text: 'Walk-in: Generated bill ID $randomBillId'),
        ),
      );
    } else {
      // Clear fields when unchecking Walk-in
      nameController.text = '';
      addressController.text = '';
      phoneController.text = '';
      ref.read(customerFormProvider.notifier).updateName('');
      ref.read(customerFormProvider.notifier).updateAddress('');
      ref.read(customerFormProvider.notifier).updatePhoneNumber('');
    }
  }

  Widget _buildNameField(CustomerFormState customerFormState, bool isWalkIn) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomTextField(
          controller: nameController,
          hintText: customerFormState.fieldConfigs['name']!.hintText,
          label: customerFormState.fieldConfigs['name']!.title,
          keyboardType: TextInputType.name,
          prefixIcon: Icon(
            Icons.person,
            color:
                Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : AppColors.lIconColor,
          ),
          enabled: !isWalkIn,
          readOnly: isWalkIn,
          validator: (value) {
            if (customerFormState.fieldConfigs['name']!.isRequired &&
                (value == null || value.isEmpty)) {
              return customerFormState.fieldConfigs['name']!.validatorText;
            }
            return null;
          },
          onChange:
              isWalkIn
                  ? null
                  : (value) {
                    ref
                        .read(customerFormProvider.notifier)
                        .updateName(value ?? '');
                    ref.read(checkoutProvider.notifier).filterCustomers(value ?? '');
                    return null;
                  },
        ),
        if (isWalkIn) ...[
          SizedBox(height: 4.h),
          mdText(text: 'Walk-in customer - no data saved', color: Colors.grey),
        ],
      ],
    );
  }

  Widget _buildSuggestions(List<Customer> filteredCustomers, bool showSuggestions, bool isWalkIn) {
    return showSuggestions && filteredCustomers.isNotEmpty && !isWalkIn
        ? Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(8.r)),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: 150.h),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: filteredCustomers.length,
                itemBuilder: (context, index) {
                  final customer = filteredCustomers[index];
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 4.h),
                    child: ListTile(
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.person,
                            size: 14.spMin,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                          smText(
                            text: customer.name,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ],
                      ),
                      subtitle: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.location_city,
                                size: 14.spMin,
                                color:
                                    Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                              ),
                              smText(
                                text: customer.address,
                                color:
                                    Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.phone,
                                size: 14.spMin,
                                color:
                                    Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                              ),
                              smText(
                                text: customer.phoneNumber,
                                color:
                                    Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                              ),
                            ],
                          ),
                        ],
                      ),
                      onTap: () {
                        nameController.text = customer.name;
                        addressController.text = customer.address;
                        phoneController.text = customer.phoneNumber;
                        ref.read(checkoutProvider.notifier).hideSuggestions();
                        ref
                            .read(customerFormProvider.notifier)
                            .updateName(customer.name);
                        ref
                            .read(customerFormProvider.notifier)
                            .updateAddress(customer.address);
                        ref
                            .read(customerFormProvider.notifier)
                            .updatePhoneNumber(customer.phoneNumber);
                      },
                    ),
                  );
                },
              ),
            ),
          ),
        )
        : SizedBox.shrink();
  }

  Widget _buildAddressField(CustomerFormState customerFormState, bool isWalkIn) {
    return CustomTextField(
      controller: addressController,
      hintText:
          isWalkIn
              ? 'walk-in'
              : customerFormState.fieldConfigs['address']!.hintText,
      label: customerFormState.fieldConfigs['address']!.title,
      keyboardType: TextInputType.streetAddress,
      prefixIcon: Icon(
        TablerIcons.location,
        color:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : AppColors.lIconColor,
      ),
      enabled: !isWalkIn,
      readOnly: isWalkIn,
      validator:
          isWalkIn
              ? null
              : (value) {
                if (customerFormState.fieldConfigs['address']!.isRequired &&
                    (value == null || value.isEmpty)) {
                  return customerFormState
                      .fieldConfigs['address']!
                      .validatorText;
                }
                return null;
              },
      onChange:
          isWalkIn
              ? null
              : (value) {
                ref
                    .read(customerFormProvider.notifier)
                    .updateAddress(value ?? '');
                return null;
              },
    );
  }

  Widget _buildPhoneField(CustomerFormState customerFormState, bool isWalkIn) {
    return CustomTextField(
      controller: phoneController,
      hintText:
          isWalkIn
              ? 'walk-in'
              : customerFormState.fieldConfigs['phoneNumber']!.hintText,
      label: customerFormState.fieldConfigs['phoneNumber']!.title,
      keyboardType: TextInputType.phone,
      prefixIcon: Icon(
        Icons.phone,
        color:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : AppColors.lIconColor,
      ),
      enabled: !isWalkIn,
      readOnly: isWalkIn,
      validator:
          isWalkIn
              ? null
              : (value) {
                if (customerFormState.fieldConfigs['phoneNumber']!.isRequired &&
                    (value == null || value.isEmpty)) {
                  return customerFormState
                      .fieldConfigs['phoneNumber']!
                      .validatorText;
                }
                if (value != null &&
                    value.isNotEmpty &&
                    !RegExp(r'^\d{10,15}$').hasMatch(value)) {
                  return 'Enter a valid phone number (10-15 digits)';
                }
                return null;
              },
      onChange:
          isWalkIn
              ? null
              : (value) {
                ref
                    .read(customerFormProvider.notifier)
                    .updatePhoneNumber(value ?? '');
                return null;
              },
    );
  }

  Widget _buildPaymentStatusField(
    CustomerFormState customerFormState,
    SalesState salesState,
  ) {
    return AppDropdown<String>(
      label: customerFormState.fieldConfigs['paymentStatus']!.title,
      hintText: customerFormState.fieldConfigs['paymentStatus']!.hintText,
      items: ['Paid', 'Pending'],
      value: salesState.isPaid ? 'Paid' : 'Pending',
      onChanged: (value) {
        ref.read(salesProvider.notifier).setPaymentStatus(value == 'Paid');
        ref
            .read(customerFormProvider.notifier)
            .updatePaymentStatus(value ?? 'Pending');
      },
      prefixIcon: Icon(
        Icons.payment,
        color:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : AppColors.lIconColor,
      ),
      validator: (value) {
        if (customerFormState.fieldConfigs['paymentStatus']!.isRequired &&
            (value == null || value.isEmpty)) {
          return customerFormState.fieldConfigs['paymentStatus']!.validatorText;
        }
        return null;
      },
    );
  }

  Widget _buildPaymentMethodField(
    CustomerFormState customerFormState,
    SalesState salesState,
  ) {
    return AppDropdown<String>(
      label: customerFormState.fieldConfigs['paymentMethod']!.title,
      hintText: customerFormState.fieldConfigs['paymentMethod']!.hintText,
      items: ['Cash', 'Online Pay'],
      value: salesState.paymentMethod,
      onChanged: (value) {
        ref.read(salesProvider.notifier).setPaymentMethod(value);
        ref.read(customerFormProvider.notifier).updatePaymentMethod(value);
      },
      prefixIcon: Icon(
        Icons.payment,
        color:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : AppColors.lIconColor,
      ),
      validator: (value) {
        if (customerFormState.fieldConfigs['paymentMethod']!.isRequired &&
            (value == null || value.isEmpty)) {
          return customerFormState.fieldConfigs['paymentMethod']!.validatorText;
        }
        return null;
      },
    );
  }

  Widget _buildDiscountField(CustomerFormState customerFormState) {
    return CustomTextField(
      controller: discountController,
      hintText:
          '${customerFormState.fieldConfigs['discount']!.hintText} (max: Rs.${widget.totalAmount.toStringAsFixed(0)})',
      label: customerFormState.fieldConfigs['discount']!.title,
      keyboardType: TextInputType.number,
      prefixIcon: Icon(
        Icons.discount,
        color:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : AppColors.lIconColor,
      ),
      validator: (value) {
        if (customerFormState.fieldConfigs['discount']!.isRequired &&
            (value == null || value.isEmpty)) {
          return customerFormState.fieldConfigs['discount']!.validatorText;
        }
        final amt = double.tryParse(value ?? '');
        if (value != null && value.isNotEmpty) {
          if (amt == null) {
            return 'Enter a valid number';
          }
          if (amt > widget.totalAmount) {
            return 'Cannot exceed total: Rs.${widget.totalAmount.toStringAsFixed(0)}';
          }
          if (amt < 0) {
            return 'Discount cannot be negative';
          }
        }
        return null;
      },
      onChange: (value) {
        final amt = double.tryParse(value ?? '') ?? 0.0;
        ref.read(salesProvider.notifier).setDiscount(amt);
        ref.read(customerFormProvider.notifier).updateDiscount(value ?? '');
        return null;
      },
    );
  }

  Widget _buildPaidAmountField(
    CustomerFormState customerFormState,
    SalesState salesState,
    double totalAfterDiscount,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomTextField(
          controller: paidAmountController,
          hintText:
              '${customerFormState.fieldConfigs['paidAmount']!.hintText} (max: Rs.${totalAfterDiscount.toStringAsFixed(0)})',
          label: customerFormState.fieldConfigs['paidAmount']!.title,
          keyboardType: TextInputType.number,
          prefixIcon: Icon(
            Icons.money,
            color:
                Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : AppColors.lIconColor,
          ),
          validator: (value) {
            if (customerFormState.fieldConfigs['paidAmount']!.isRequired &&
                (value == null || value.isEmpty)) {
              return customerFormState
                  .fieldConfigs['paidAmount']!
                  .validatorText;
            }
            final amt = double.tryParse(value ?? '');
            if (value != null && value.isNotEmpty) {
              if (amt == null) {
                return 'Enter a valid number';
              }
              if (amt > totalAfterDiscount) {
                return 'Cannot exceed total: Rs.${totalAfterDiscount.toStringAsFixed(0)}';
              }
              if (amt < 0) {
                return 'Amount cannot be negative';
              }
            }
            return null;
          },
          onChange: (value) {
            print('🔵 Paid Amount Field Changed: "$value"');
            final amt = double.tryParse(value ?? '') ?? 0.0;
            print('🔵 Parsed Amount: $amt');
            ref.read(salesProvider.notifier).setPaidAmount(amt);
            print('🔵 Set to salesProvider');
            ref
                .read(customerFormProvider.notifier)
                .updatePaidAmount(value ?? '');
            print('🔵 Set to customerFormProvider');
            return null;
          },
        ),
        SizedBox(height: 8.h),
        Consumer(
          builder: (context, ref, child) {
            final currentSalesState = ref.watch(salesProvider);
            final pendingAmount = PaymentCalculator.calculatePendingAmount(
              totalAmount: widget.totalAmount,
              discount: customerFormState.discount ?? widget.discount,
              paidAmount: currentSalesState.paidAmount,
            );
            final paymentPercentage = PaymentCalculator.calculatePaymentPercentage(
              totalAmount: widget.totalAmount,
              discount: customerFormState.discount ?? widget.discount,
              paidAmount: currentSalesState.paidAmount,
            );

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    mdText(
                      text: 'Pending Amount:',
                      color: Colors.grey,
                    ),
                    mdText(
                      text: 'Rs.${pendingAmount.toStringAsFixed(0)}',
                      color: pendingAmount > 0 ? Colors.red : Colors.green,
                    ),
                  ],
                ),
                if (currentSalesState.paidAmount > 0) ...[
                  SizedBox(height: 4.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      smText(
                        text: 'Payment Progress:',
                        color: Colors.grey,
                      ),
                      smText(
                        text: '${paymentPercentage.toStringAsFixed(1)}%',
                        color: paymentPercentage >= 100 ? Colors.green : Colors.orange,
                      ),
                    ],
                  ),
                ],
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _buildMobileLayout(
    CustomerFormState customerFormState,
    SalesState salesState,
    double totalAfterDiscount,
    bool isWalkIn,
    List<Customer> filteredCustomers,
    bool showSuggestions,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (customerFormState.fieldConfigs['name']!.isShow) ...[
          _buildNameField(customerFormState, isWalkIn),
          _buildSuggestions(filteredCustomers, showSuggestions, isWalkIn),
          SizedBox(height: 16.h),
        ],
        if (customerFormState.fieldConfigs['address']!.isShow) ...[
          _buildAddressField(customerFormState, isWalkIn),
          SizedBox(height: 16.h),
        ],
        if (customerFormState.fieldConfigs['phoneNumber']!.isShow) ...[
          _buildPhoneField(customerFormState, isWalkIn),
          SizedBox(height: 24.h),
        ],
        if (customerFormState.fieldConfigs['paymentStatus']!.isShow) ...[
          _buildPaymentStatusField(customerFormState, salesState),
          SizedBox(height: 24.h),
        ],
        if (customerFormState.fieldConfigs['paymentMethod']!.isShow) ...[
          _buildPaymentMethodField(customerFormState, salesState),
          SizedBox(height: 24.h),
        ],
        if (customerFormState.fieldConfigs['discount']!.isShow) ...[
          _buildDiscountField(customerFormState),
          SizedBox(height: 24.h),
        ],
        if (customerFormState.fieldConfigs['paidAmount']!.isShow &&
            !salesState.isPaid) ...[
          _buildPaidAmountField(
            customerFormState,
            salesState,
            totalAfterDiscount,
          ),
          SizedBox(height: 32.h),
        ],
        AppButton().primaryButton(
          text: "Save & Complete Sale",
          onPressed: () {
            print('========== CHECKOUT: Save & Complete Sale Button Pressed ==========');
            print('Form Validation Result: ${_formKey.currentState!.validate()}');

            if (_formKey.currentState!.validate()) {
              // READ THE CURRENT STATE HERE, NOT THE OLD ONE!
              final currentSalesState = ref.read(salesProvider);

              print('--- Payment Information ---');
              print('Total Amount: ${widget.totalAmount}');
              print('Discount: ${customerFormState.discount ?? widget.discount}');
              print('Total After Discount: $totalAfterDiscount');
              print('Payment Status (isPaid): ${currentSalesState.isPaid}');
              print('Paid Amount: ${currentSalesState.paidAmount}');
              print('Payment Method: ${currentSalesState.paymentMethod}');

              final pendingAmount = PaymentCalculator.calculatePendingAmount(
                totalAmount: widget.totalAmount,
                discount: customerFormState.discount ?? widget.discount,
                paidAmount: currentSalesState.paidAmount,
              );
              print('Pending Amount (Calculated): $pendingAmount');

              print('--- Customer Information ---');
              print('Customer Name: ${nameController.text}');
              print('Address: ${addressController.text}');
              print('Phone: ${phoneController.text}');
              print('Is Walk-in: $isWalkIn');

              if (!currentSalesState.isPaid &&
                  currentSalesState.paidAmount > totalAfterDiscount) {
                print('ERROR: Paid amount exceeds total!');
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Paid amount cannot exceed total'),
                  ),
                );
                return;
              }

              final customerData =
                  isWalkIn
                      ? {
                        'name': nameController.text, // BILL-XXXX
                        'address': null,
                        'phoneNumber': null,
                        'isWalkIn': true,
                      }
                      : {
                        'name': nameController.text,
                        'address': addressController.text,
                        'phoneNumber': phoneController.text,
                        'isWalkIn': false,
                      };

              print('--- Customer Data to Return ---');
              print('Customer Data: $customerData');
              print('========== CHECKOUT: Returning to Previous Screen ==========\n');

              Navigator.pop(context, customerData);
            } else {
              print('ERROR: Form validation failed!');
            }
          },
        ),
      ],
    );
  }

  Widget _buildTabletDesktopLayout(
    CustomerFormState customerFormState,
    SalesState salesState,
    double totalAfterDiscount,
    bool isWalkIn,
    List<Customer> filteredCustomers,
    bool showSuggestions,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (customerFormState.fieldConfigs['name']!.isShow ||
            customerFormState.fieldConfigs['phoneNumber']!.isShow)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (customerFormState.fieldConfigs['name']!.isShow)
                Expanded(
                  child: Column(
                    children: [
                      _buildNameField(customerFormState, isWalkIn),
                      _buildSuggestions(filteredCustomers, showSuggestions, isWalkIn),
                    ],
                  ),
                ),
              if (customerFormState.fieldConfigs['name']!.isShow &&
                  customerFormState.fieldConfigs['phoneNumber']!.isShow)
                SizedBox(width: 16.w),
              if (customerFormState.fieldConfigs['phoneNumber']!.isShow)
                Expanded(child: _buildPhoneField(customerFormState, isWalkIn)),
            ],
          ),
        SizedBox(height: 16.h),
        if (customerFormState.fieldConfigs['address']!.isShow) ...[
          _buildAddressField(customerFormState, isWalkIn),
          SizedBox(height: 24.h),
        ],
        if (customerFormState.fieldConfigs['paymentStatus']!.isShow ||
            customerFormState.fieldConfigs['paymentMethod']!.isShow)
          Row(
            children: [
              if (customerFormState.fieldConfigs['paymentStatus']!.isShow)
                Expanded(
                  child: _buildPaymentStatusField(
                    customerFormState,
                    salesState,
                  ),
                ),
              if (customerFormState.fieldConfigs['paymentStatus']!.isShow &&
                  customerFormState.fieldConfigs['paymentMethod']!.isShow)
                SizedBox(width: 16.w),
              if (customerFormState.fieldConfigs['paymentMethod']!.isShow)
                Expanded(
                  child: _buildPaymentMethodField(
                    customerFormState,
                    salesState,
                  ),
                ),
            ],
          ),
        SizedBox(height: 24.h),
        if (customerFormState.fieldConfigs['discount']!.isShow) ...[
          _buildDiscountField(customerFormState),
          SizedBox(height: 24.h),
        ],
        if (customerFormState.fieldConfigs['paidAmount']!.isShow &&
            !salesState.isPaid) ...[
          _buildPaidAmountField(
            customerFormState,
            salesState,
            totalAfterDiscount,
          ),
          SizedBox(height: 32.h),
        ],
        AppButton().primaryButton(
          text: "Save & Complete Sale",
          onPressed: () {
            print('========== CHECKOUT (Desktop/Tablet): Save & Complete Sale Button Pressed ==========');
            print('Form Validation Result: ${_formKey.currentState!.validate()}');

            if (_formKey.currentState!.validate()) {
              // READ THE CURRENT STATE HERE, NOT THE OLD ONE!
              final currentSalesState = ref.read(salesProvider);

              print('--- Payment Information ---');
              print('Total Amount: ${widget.totalAmount}');
              print('Discount: ${customerFormState.discount ?? widget.discount}');
              print('Total After Discount: $totalAfterDiscount');
              print('Payment Status (isPaid): ${currentSalesState.isPaid}');
              print('Paid Amount: ${currentSalesState.paidAmount}');
              print('Payment Method: ${currentSalesState.paymentMethod}');

              final pendingAmount = PaymentCalculator.calculatePendingAmount(
                totalAmount: widget.totalAmount,
                discount: customerFormState.discount ?? widget.discount,
                paidAmount: currentSalesState.paidAmount,
              );
              print('Pending Amount (Calculated): $pendingAmount');

              print('--- Customer Information ---');
              print('Customer Name: ${nameController.text}');
              print('Address: ${addressController.text}');
              print('Phone: ${phoneController.text}');
              print('Is Walk-in: $isWalkIn');

              if (!currentSalesState.isPaid &&
                  currentSalesState.paidAmount > totalAfterDiscount) {
                print('ERROR: Paid amount exceeds total!');
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Paid amount cannot exceed total'),
                  ),
                );
                return;
              }

              final customerData =
                  isWalkIn
                      ? {
                        'name': nameController.text, // BILL-XXXX
                        'address': null,
                        'phoneNumber': null,
                        'isWalkIn': true,
                      }
                      : {
                        'name': nameController.text,
                        'address': addressController.text,
                        'phoneNumber': phoneController.text,
                        'isWalkIn': false,
                      };

              print('--- Customer Data to Return ---');
              print('Customer Data: $customerData');
              print('========== CHECKOUT (Desktop/Tablet): Returning to Previous Screen ==========\n');

              Navigator.pop(context, customerData);
            } else {
              print('ERROR: Form validation failed!');
            }
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final salesState = ref.watch(salesProvider);
    final customerFormState = ref.watch(customerFormProvider);
    final checkoutState = ref.watch(checkoutProvider);
    final totalAfterDiscount =
        widget.totalAmount - (customerFormState.discount ?? widget.discount);

    return Scaffold(
      appBar: AppBarWidget.customAppBar(
        title: "Customer & Payment Info",
        context: context,
        actions: [
          SizedBox(
            width: 200.w,
            child: CheckboxListTile(
              title: smText(
                text: 'Walk-in',
                color:
                    Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
              ),
              value: checkoutState.isWalkIn,
              onChanged: _toggleWalkIn,
              controlAffinity: ListTileControlAffinity.leading,
              contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
              dense: true,
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.w),
          child: ResponsiveWrapper(
            mobile: _buildMobileLayout(
              customerFormState,
              salesState,
              totalAfterDiscount,
              checkoutState.isWalkIn,
              checkoutState.filteredCustomers,
              checkoutState.showSuggestions,
            ),
            tablet: _buildTabletDesktopLayout(
              customerFormState,
              salesState,
              totalAfterDiscount,
              checkoutState.isWalkIn,
              checkoutState.filteredCustomers,
              checkoutState.showSuggestions,
            ),
            desktop: _buildTabletDesktopLayout(
              customerFormState,
              salesState,
              totalAfterDiscount,
              checkoutState.isWalkIn,
              checkoutState.filteredCustomers,
              checkoutState.showSuggestions,
            ),
          ),
        ),
      ),
    );
  }
}
